# Large builtin hashing batch parallelism component comparison

Linux x86_64, same frozen compare harness; previous COW+CAS baseline versus builtin hashing batch parallel candidate. No RSS claim. Full engine and eight-peer goal remain unqualified.

|Case|Series|Gain %|Absolute A/A %|Positive|Pass|
|---|---|---:|---:|---:|---|
|compare/insert_bulk_10k/lin|series1|-33.890|0.656|0/6|False|
|compare/insert_bulk_10k/lin|series2|-32.935|1.402|0/6|False|
|compare/insert_bulk_1k/lin|series1|0.552|1.065|4/6|True|
|compare/insert_bulk_1k/lin|series2|-0.685|0.782|2/6|True|
|compare/point_get/lin|series1|-0.934|4.067|2/6|True|
|compare/point_get/lin|series2|-1.756|1.954|2/6|True|
|compare/filter_eq/lin|series1|3.972|4.791|4/6|True|
|compare/filter_eq/lin|series2|2.776|3.789|5/6|True|
|compare/update_1row_1k/lin|series1|0.084|1.900|3/6|True|
|compare/update_1row_1k/lin|series2|-0.382|4.267|3/6|True|
|compare/wal_scalar_full_update/lin|series1|0.021|5.195|3/6|True|
|compare/wal_scalar_full_update/lin|series2|0.382|4.095|3/6|True|
|compare/wal_scalar_normal_update/lin|series1|-0.248|0.909|3/6|True|
|compare/wal_scalar_normal_update/lin|series2|-4.876|1.462|2/6|False|
|compare/insert_bulk_10k/sqlite|series1|-0.149|0.829|2/6|True|
|compare/insert_bulk_10k/sqlite|series2|0.388|0.436|4/6|True|
|compare/filter_eq/duckdb|series1|0.436|10.824|4/6|True|
|compare/filter_eq/duckdb|series2|0.779|6.521|3/6|True|

Component gate: False. All 324 processes / 2592 wall observations retained.
