@group(0) @binding(0) var<storage, read> mask: array<u32>;
@group(0) @binding(1) var<storage, read> weight: array<u32>;
@group(0) @binding(2) var<storage, read_write> scores: array<vec2<u32>>;
@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) id: vec3<u32>) {
    if id.x >= arrayLength(&scores) { return; }
    if mask[id.x] == 0u { return; }
    let before = scores[id.x];
    let low = before.x + weight[0];
    scores[id.x] = vec2<u32>(low, before.y + select(0u, 1u, low < before.x));
}
