# Validated read API benchmark

Rows: 1000; process repetitions: 1; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.189 | 1.00× | validated |
| filter_eq | lin | 0.845 | 1.00× | validated |
| text_substr | lin | 1.768 | 1.00× | validated |
| materialize | lin | 69.526 | 1.00× | validated |
| join_inner | lin | 243.562 | 1.00× | validated |
| join_filter | lin | 97.028 | 1.00× | validated |

Versions: {"lin": "0.4.0"}

Missing/failed peers are never counted as wins.
