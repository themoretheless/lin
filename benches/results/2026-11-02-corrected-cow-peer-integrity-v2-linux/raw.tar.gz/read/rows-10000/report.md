# Validated read API benchmark

Rows: 10000; process repetitions: 3; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.216 | 1.00× | validated |
| point_get | sqlite | 3.610 | 16.74× | validated |
| point_get | duckdb | 231.392 | 1073.07× | validated |
| point_get | postgres | 205.637 | 953.63× | validated |
| point_get | mysql | 257.300 | 1193.21× | validated |
| point_get | mongo | 470.981 | 2184.14× | validated |
| point_get | pandas | 17.484 | 81.08× | validated |
| filter_eq | lin | 1.051 | 1.00× | validated |
| filter_eq | sqlite | 207.013 | 197.04× | validated |
| filter_eq | duckdb | 653.518 | 622.05× | validated |
| filter_eq | postgres | 627.173 | 596.97× | validated |
| filter_eq | mysql | 1026.116 | 976.70× | validated |
| filter_eq | mongo | 1450.541 | 1380.69× | validated |
| filter_eq | pandas | 660.116 | 628.33× | validated |
| text_substr | lin | 47.803 | 1.00× | validated |
| text_substr | sqlite | 713.253 | 14.92× | validated |
| text_substr | duckdb | 438.459 | 9.17× | validated |
| text_substr | postgres | 1069.303 | 22.37× | validated |
| text_substr | mysql | 2164.079 | 45.27× | validated |
| text_substr | mongo | 6845.525 | 143.20× | validated |
| text_substr | pandas | 1375.198 | 28.77× | validated |
| materialize | lin | 1010.379 | 1.00× | validated |
| materialize | sqlite | 5118.148 | 5.07× | validated |
| materialize | duckdb | 3507.619 | 3.47× | validated |
| materialize | postgres | 4046.065 | 4.00× | validated |
| materialize | mysql | 25165.939 | 24.91× | validated |
| materialize | mongo | 11306.828 | 11.19× | validated |
| materialize | pandas | 5290.814 | 5.24× | validated |
| join_inner | lin | 3638.985 | 1.00× | validated |
| join_inner | sqlite | 12209.627 | 3.36× | validated |
| join_inner | duckdb | 7945.217 | 2.18× | validated |
| join_inner | postgres | 9973.817 | 2.74× | validated |
| join_inner | mysql | 55852.185 | 15.35× | validated |
| join_inner | mongo | 375473.621 | 103.18× | validated |
| join_inner | pandas | 11358.053 | 3.12× | validated |
| join_filter | lin | 1825.889 | 1.00× | validated |
| join_filter | sqlite | 6363.684 | 3.49× | validated |
| join_filter | duckdb | 4524.626 | 2.48× | validated |
| join_filter | postgres | 5792.862 | 3.17× | validated |
| join_filter | mysql | 29108.289 | 15.94× | validated |
| join_filter | mongo | 190104.429 | 104.12× | validated |
| join_filter | pandas | 6781.260 | 3.71× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
