# Validated read API benchmark

Rows: 10000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | sqlite | 3.570 | 16.55× | validated |
| point_get | duckdb | 231.392 | 1073.07× | validated |
| point_get | postgres | 205.637 | 953.63× | validated |
| point_get | mysql | 249.059 | 1154.99× | validated |
| point_get | mongo | 457.153 | 2120.01× | validated |
| point_get | pandas | 17.484 | 81.08× | validated |
| point_get | lin | 0.216 | 1.00× | validated |
| filter_eq | sqlite | 210.204 | 195.10× | validated |
| filter_eq | duckdb | 648.519 | 601.92× | validated |
| filter_eq | postgres | 625.647 | 580.69× | validated |
| filter_eq | mysql | 1018.359 | 945.19× | validated |
| filter_eq | mongo | 1450.541 | 1346.31× | validated |
| filter_eq | pandas | 650.647 | 603.90× | validated |
| filter_eq | lin | 1.077 | 1.00× | validated |
| text_substr | sqlite | 713.253 | 14.95× | validated |
| text_substr | duckdb | 431.039 | 9.03× | validated |
| text_substr | postgres | 1054.778 | 22.11× | validated |
| text_substr | mysql | 2164.079 | 45.36× | validated |
| text_substr | mongo | 6811.331 | 142.76× | validated |
| text_substr | pandas | 1356.835 | 28.44× | validated |
| text_substr | lin | 47.713 | 1.00× | validated |
| materialize | sqlite | 5150.541 | 5.03× | validated |
| materialize | duckdb | 3511.671 | 3.43× | validated |
| materialize | postgres | 4085.469 | 3.99× | validated |
| materialize | mysql | 24921.260 | 24.36× | validated |
| materialize | mongo | 11306.828 | 11.05× | validated |
| materialize | pandas | 5290.814 | 5.17× | validated |
| materialize | lin | 1023.102 | 1.00× | validated |
| join_inner | sqlite | 12662.493 | 3.46× | validated |
| join_inner | duckdb | 7945.217 | 2.17× | validated |
| join_inner | postgres | 9973.817 | 2.72× | validated |
| join_inner | mysql | 55649.127 | 15.20× | validated |
| join_inner | mongo | 374776.097 | 102.34× | validated |
| join_inner | pandas | 11378.105 | 3.11× | validated |
| join_inner | lin | 3662.008 | 1.00× | validated |
| join_filter | sqlite | 6511.816 | 3.53× | validated |
| join_filter | duckdb | 4576.422 | 2.48× | validated |
| join_filter | postgres | 5792.862 | 3.14× | validated |
| join_filter | mysql | 29108.289 | 15.78× | validated |
| join_filter | mongo | 188946.734 | 102.42× | validated |
| join_filter | pandas | 6935.113 | 3.76× | validated |
| join_filter | lin | 1844.777 | 1.00× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
