# Validated read API benchmark

Rows: 10000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.212 | 1.00× | validated |
| point_get | sqlite | 3.610 | 17.02× | validated |
| point_get | duckdb | 237.695 | 1120.82× | validated |
| point_get | postgres | 201.671 | 950.95× | validated |
| point_get | mysql | 257.300 | 1213.27× | validated |
| point_get | mongo | 470.981 | 2220.86× | validated |
| point_get | pandas | 17.126 | 80.76× | validated |
| filter_eq | lin | 1.023 | 1.00× | validated |
| filter_eq | sqlite | 206.674 | 201.97× | validated |
| filter_eq | duckdb | 653.518 | 638.64× | validated |
| filter_eq | postgres | 644.854 | 630.17× | validated |
| filter_eq | mysql | 1052.138 | 1028.18× | validated |
| filter_eq | mongo | 1444.329 | 1411.44× | validated |
| filter_eq | pandas | 660.116 | 645.09× | validated |
| text_substr | lin | 48.015 | 1.00× | validated |
| text_substr | sqlite | 706.899 | 14.72× | validated |
| text_substr | duckdb | 451.287 | 9.40× | validated |
| text_substr | postgres | 1069.303 | 22.27× | validated |
| text_substr | mysql | 2248.943 | 46.84× | validated |
| text_substr | mongo | 6845.525 | 142.57× | validated |
| text_substr | pandas | 1384.896 | 28.84× | validated |
| materialize | lin | 1010.379 | 1.00× | validated |
| materialize | sqlite | 4868.114 | 4.82× | validated |
| materialize | duckdb | 3507.619 | 3.47× | validated |
| materialize | postgres | 3956.669 | 3.92× | validated |
| materialize | mysql | 25413.000 | 25.15× | validated |
| materialize | mongo | 11504.778 | 11.39× | validated |
| materialize | pandas | 5227.470 | 5.17× | validated |
| join_inner | lin | 3638.985 | 1.00× | validated |
| join_inner | sqlite | 12209.627 | 3.36× | validated |
| join_inner | duckdb | 7972.949 | 2.19× | validated |
| join_inner | postgres | 10445.592 | 2.87× | validated |
| join_inner | mysql | 56787.958 | 15.61× | validated |
| join_inner | mongo | 375473.621 | 103.18× | validated |
| join_inner | pandas | 11316.696 | 3.11× | validated |
| join_filter | lin | 1825.889 | 1.00× | validated |
| join_filter | sqlite | 6135.127 | 3.36× | validated |
| join_filter | duckdb | 4524.626 | 2.48× | validated |
| join_filter | postgres | 6087.050 | 3.33× | validated |
| join_filter | mysql | 29621.460 | 16.22× | validated |
| join_filter | mongo | 190173.098 | 104.15× | validated |
| join_filter | pandas | 6781.260 | 3.71× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
