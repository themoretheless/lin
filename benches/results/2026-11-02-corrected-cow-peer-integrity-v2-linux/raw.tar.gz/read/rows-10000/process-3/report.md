# Validated read API benchmark

Rows: 10000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | duckdb | 227.962 | 1053.50× | validated |
| point_get | postgres | 221.232 | 1022.39× | validated |
| point_get | mysql | 262.077 | 1211.15× | validated |
| point_get | mongo | 494.530 | 2285.41× | validated |
| point_get | pandas | 17.550 | 81.10× | validated |
| point_get | lin | 0.216 | 1.00× | validated |
| point_get | sqlite | 3.637 | 16.81× | validated |
| filter_eq | duckdb | 667.405 | 635.26× | validated |
| filter_eq | postgres | 627.173 | 596.97× | validated |
| filter_eq | mysql | 1026.116 | 976.70× | validated |
| filter_eq | mongo | 1455.964 | 1385.85× | validated |
| filter_eq | pandas | 669.908 | 637.65× | validated |
| filter_eq | lin | 1.051 | 1.00× | validated |
| filter_eq | sqlite | 207.013 | 197.04× | validated |
| text_substr | duckdb | 438.459 | 9.17× | validated |
| text_substr | postgres | 1079.394 | 22.58× | validated |
| text_substr | mysql | 2147.010 | 44.91× | validated |
| text_substr | mongo | 6940.537 | 145.19× | validated |
| text_substr | pandas | 1375.198 | 28.77× | validated |
| text_substr | lin | 47.803 | 1.00× | validated |
| text_substr | sqlite | 726.159 | 15.19× | validated |
| materialize | duckdb | 3418.195 | 3.40× | validated |
| materialize | postgres | 4046.065 | 4.03× | validated |
| materialize | mysql | 25165.939 | 25.04× | validated |
| materialize | mongo | 11196.835 | 11.14× | validated |
| materialize | pandas | 5321.976 | 5.30× | validated |
| materialize | lin | 1004.951 | 1.00× | validated |
| materialize | sqlite | 5118.148 | 5.09× | validated |
| join_inner | duckdb | 7930.618 | 2.19× | validated |
| join_inner | postgres | 9937.578 | 2.74× | validated |
| join_inner | mysql | 55852.185 | 15.40× | validated |
| join_inner | mongo | 376692.900 | 103.85× | validated |
| join_inner | pandas | 11358.053 | 3.13× | validated |
| join_inner | lin | 3627.336 | 1.00× | validated |
| join_inner | sqlite | 12162.320 | 3.35× | validated |
| join_filter | duckdb | 4485.075 | 2.48× | validated |
| join_filter | postgres | 5460.105 | 3.02× | validated |
| join_filter | mysql | 28666.860 | 15.85× | validated |
| join_filter | mongo | 190104.429 | 105.11× | validated |
| join_filter | pandas | 6774.432 | 3.75× | validated |
| join_filter | lin | 1808.661 | 1.00× | validated |
| join_filter | sqlite | 6363.684 | 3.52× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
