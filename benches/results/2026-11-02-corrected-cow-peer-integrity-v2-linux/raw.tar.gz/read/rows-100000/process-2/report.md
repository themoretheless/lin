# Validated read API benchmark

Rows: 100000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | sqlite | 3.599 | 17.06× | validated |
| point_get | duckdb | 232.829 | 1103.54× | validated |
| point_get | postgres | 218.252 | 1034.45× | validated |
| point_get | mysql | 255.795 | 1212.39× | validated |
| point_get | mongo | 468.701 | 2221.50× | validated |
| point_get | pandas | 17.335 | 82.16× | validated |
| point_get | lin | 0.211 | 1.00× | validated |
| filter_eq | sqlite | 2116.488 | 1001.92× | validated |
| filter_eq | duckdb | 1703.156 | 806.25× | validated |
| filter_eq | postgres | 4415.930 | 2090.44× | validated |
| filter_eq | mysql | 7767.593 | 3677.07× | validated |
| filter_eq | mongo | 8867.893 | 4197.94× | validated |
| filter_eq | pandas | 5030.352 | 2381.30× | validated |
| filter_eq | lin | 2.112 | 1.00× | validated |
| text_substr | sqlite | 7240.221 | 13.03× | validated |
| text_substr | duckdb | 1273.387 | 2.29× | validated |
| text_substr | postgres | 9162.863 | 16.49× | validated |
| text_substr | mysql | 19681.831 | 35.41× | validated |
| text_substr | mongo | 66313.039 | 119.31× | validated |
| text_substr | pandas | 12137.728 | 21.84× | validated |
| text_substr | lin | 555.822 | 1.00× | validated |
| materialize | sqlite | 59216.132 | 2.23× | validated |
| materialize | duckdb | 32756.410 | 1.23× | validated |
| materialize | postgres | 41465.114 | 1.56× | validated |
| materialize | mysql | 233177.741 | 8.79× | validated |
| materialize | mongo | 108393.804 | 4.09× | validated |
| materialize | pandas | 44966.719 | 1.70× | validated |
| materialize | lin | 26525.473 | 1.00× | validated |
| join_inner | sqlite | 144238.346 | 2.75× | validated |
| join_inner | duckdb | 90712.739 | 1.73× | validated |
| join_inner | postgres | 124082.027 | 2.37× | validated |
| join_inner | mysql | 492135.436 | 9.40× | validated |
| join_inner | mongo | 3824407.543 | 73.03× | validated |
| join_inner | pandas | 112397.222 | 2.15× | validated |
| join_inner | lin | 52369.747 | 1.00× | validated |
| join_filter | sqlite | 67715.401 | 2.64× | validated |
| join_filter | duckdb | 42279.236 | 1.65× | validated |
| join_filter | postgres | 62139.047 | 2.42× | validated |
| join_filter | mysql | 266787.431 | 10.40× | validated |
| join_filter | mongo | 1942789.404 | 75.77× | validated |
| join_filter | pandas | 55076.395 | 2.15× | validated |
| join_filter | lin | 25641.871 | 1.00× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
