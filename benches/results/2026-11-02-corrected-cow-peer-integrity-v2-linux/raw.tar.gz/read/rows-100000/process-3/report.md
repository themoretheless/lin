# Validated read API benchmark

Rows: 100000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | duckdb | 236.978 | 1121.11× | validated |
| point_get | postgres | 221.116 | 1046.07× | validated |
| point_get | mysql | 254.170 | 1202.44× | validated |
| point_get | mongo | 466.278 | 2205.89× | validated |
| point_get | pandas | 17.770 | 84.07× | validated |
| point_get | lin | 0.211 | 1.00× | validated |
| point_get | sqlite | 3.632 | 17.18× | validated |
| filter_eq | duckdb | 1751.890 | 841.08× | validated |
| filter_eq | postgres | 4410.972 | 2117.71× | validated |
| filter_eq | mysql | 7729.757 | 3711.05× | validated |
| filter_eq | mongo | 9555.514 | 4587.60× | validated |
| filter_eq | pandas | 5077.909 | 2437.90× | validated |
| filter_eq | lin | 2.083 | 1.00× | validated |
| filter_eq | sqlite | 2057.900 | 988.00× | validated |
| text_substr | duckdb | 1475.630 | 2.66× | validated |
| text_substr | postgres | 9088.597 | 16.40× | validated |
| text_substr | mysql | 19837.814 | 35.79× | validated |
| text_substr | mongo | 66305.000 | 119.61× | validated |
| text_substr | pandas | 11477.985 | 20.71× | validated |
| text_substr | lin | 554.321 | 1.00× | validated |
| text_substr | sqlite | 7201.380 | 12.99× | validated |
| materialize | duckdb | 36867.403 | 1.46× | validated |
| materialize | postgres | 41296.317 | 1.64× | validated |
| materialize | mysql | 233276.498 | 9.26× | validated |
| materialize | mongo | 108611.563 | 4.31× | validated |
| materialize | pandas | 47078.611 | 1.87× | validated |
| materialize | lin | 25204.070 | 1.00× | validated |
| materialize | sqlite | 56635.699 | 2.25× | validated |
| join_inner | duckdb | 90673.655 | 1.64× | validated |
| join_inner | postgres | 120648.090 | 2.18× | validated |
| join_inner | mysql | 494369.264 | 8.92× | validated |
| join_inner | mongo | 3857535.030 | 69.62× | validated |
| join_inner | pandas | 106267.072 | 1.92× | validated |
| join_inner | lin | 55404.582 | 1.00× | validated |
| join_inner | sqlite | 141682.508 | 2.56× | validated |
| join_filter | duckdb | 43101.091 | 1.59× | validated |
| join_filter | postgres | 61694.910 | 2.27× | validated |
| join_filter | mysql | 264153.003 | 9.74× | validated |
| join_filter | mongo | 1948675.529 | 71.84× | validated |
| join_filter | pandas | 54366.546 | 2.00× | validated |
| join_filter | lin | 27125.683 | 1.00× | validated |
| join_filter | sqlite | 72134.582 | 2.66× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
