# Validated read API benchmark

Rows: 100000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.216 | 1.00× | validated |
| point_get | sqlite | 3.653 | 16.90× | validated |
| point_get | duckdb | 232.372 | 1075.29× | validated |
| point_get | postgres | 203.530 | 941.83× | validated |
| point_get | mysql | 267.974 | 1240.04× | validated |
| point_get | mongo | 473.060 | 2189.07× | validated |
| point_get | pandas | 17.073 | 79.01× | validated |
| filter_eq | lin | 2.080 | 1.00× | validated |
| filter_eq | sqlite | 2033.980 | 977.78× | validated |
| filter_eq | duckdb | 1751.671 | 842.07× | validated |
| filter_eq | postgres | 4372.132 | 2101.79× | validated |
| filter_eq | mysql | 7777.257 | 3738.72× | validated |
| filter_eq | mongo | 8927.171 | 4291.51× | validated |
| filter_eq | pandas | 5033.725 | 2419.84× | validated |
| text_substr | lin | 556.824 | 1.00× | validated |
| text_substr | sqlite | 7345.350 | 13.19× | validated |
| text_substr | duckdb | 1308.829 | 2.35× | validated |
| text_substr | postgres | 8964.396 | 16.10× | validated |
| text_substr | mysql | 19521.446 | 35.06× | validated |
| text_substr | mongo | 65789.028 | 118.15× | validated |
| text_substr | pandas | 11491.572 | 20.64× | validated |
| materialize | lin | 18909.854 | 1.00× | validated |
| materialize | sqlite | 54477.594 | 2.88× | validated |
| materialize | duckdb | 32358.941 | 1.71× | validated |
| materialize | postgres | 40783.051 | 2.16× | validated |
| materialize | mysql | 232582.513 | 12.30× | validated |
| materialize | mongo | 107819.258 | 5.70× | validated |
| materialize | pandas | 44715.209 | 2.36× | validated |
| join_inner | lin | 52458.310 | 1.00× | validated |
| join_inner | sqlite | 140030.271 | 2.67× | validated |
| join_inner | duckdb | 90561.910 | 1.73× | validated |
| join_inner | postgres | 122559.941 | 2.34× | validated |
| join_inner | mysql | 490804.962 | 9.36× | validated |
| join_inner | mongo | 3790250.545 | 72.25× | validated |
| join_inner | pandas | 109760.343 | 2.09× | validated |
| join_filter | lin | 23534.041 | 1.00× | validated |
| join_filter | sqlite | 66807.645 | 2.84× | validated |
| join_filter | duckdb | 40588.634 | 1.72× | validated |
| join_filter | postgres | 64653.292 | 2.75× | validated |
| join_filter | mysql | 269593.213 | 11.46× | validated |
| join_filter | mongo | 1907426.937 | 81.05× | validated |
| join_filter | pandas | 53399.984 | 2.27× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
