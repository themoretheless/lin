# Validated read API benchmark

Rows: 100000; process repetitions: 3; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.211 | 1.00× | validated |
| point_get | sqlite | 3.632 | 17.18× | validated |
| point_get | duckdb | 232.829 | 1101.48× | validated |
| point_get | postgres | 218.252 | 1032.52× | validated |
| point_get | mysql | 255.795 | 1210.13× | validated |
| point_get | mongo | 468.701 | 2217.35× | validated |
| point_get | pandas | 17.335 | 82.01× | validated |
| filter_eq | lin | 2.083 | 1.00× | validated |
| filter_eq | sqlite | 2057.900 | 988.00× | validated |
| filter_eq | duckdb | 1751.671 | 840.98× | validated |
| filter_eq | postgres | 4410.972 | 2117.71× | validated |
| filter_eq | mysql | 7767.593 | 3729.22× | validated |
| filter_eq | mongo | 8927.171 | 4285.93× | validated |
| filter_eq | pandas | 5033.725 | 2416.69× | validated |
| text_substr | lin | 555.822 | 1.00× | validated |
| text_substr | sqlite | 7240.221 | 13.03× | validated |
| text_substr | duckdb | 1308.829 | 2.35× | validated |
| text_substr | postgres | 9088.597 | 16.35× | validated |
| text_substr | mysql | 19681.831 | 35.41× | validated |
| text_substr | mongo | 66305.000 | 119.29× | validated |
| text_substr | pandas | 11491.572 | 20.67× | validated |
| materialize | lin | 25204.070 | 1.00× | validated |
| materialize | sqlite | 56635.699 | 2.25× | validated |
| materialize | duckdb | 32756.410 | 1.30× | validated |
| materialize | postgres | 41296.317 | 1.64× | validated |
| materialize | mysql | 233177.741 | 9.25× | validated |
| materialize | mongo | 108393.804 | 4.30× | validated |
| materialize | pandas | 44966.719 | 1.78× | validated |
| join_inner | lin | 52458.310 | 1.00× | validated |
| join_inner | sqlite | 141682.508 | 2.70× | validated |
| join_inner | duckdb | 90673.655 | 1.73× | validated |
| join_inner | postgres | 122559.941 | 2.34× | validated |
| join_inner | mysql | 492135.436 | 9.38× | validated |
| join_inner | mongo | 3824407.543 | 72.90× | validated |
| join_inner | pandas | 109760.343 | 2.09× | validated |
| join_filter | lin | 25641.871 | 1.00× | validated |
| join_filter | sqlite | 67715.401 | 2.64× | validated |
| join_filter | duckdb | 42279.236 | 1.65× | validated |
| join_filter | postgres | 62139.047 | 2.42× | validated |
| join_filter | mysql | 266787.431 | 10.40× | validated |
| join_filter | mongo | 1942789.404 | 75.77× | validated |
| join_filter | pandas | 54366.546 | 2.12× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
