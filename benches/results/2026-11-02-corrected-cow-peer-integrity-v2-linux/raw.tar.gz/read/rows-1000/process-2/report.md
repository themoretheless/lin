# Validated read API benchmark

Rows: 1000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | sqlite | 3.499 | 16.28× | validated |
| point_get | duckdb | 234.980 | 1093.29× | validated |
| point_get | postgres | 206.204 | 959.41× | validated |
| point_get | mysql | 284.175 | 1322.18× | validated |
| point_get | mongo | 461.719 | 2148.24× | validated |
| point_get | pandas | 17.866 | 83.13× | validated |
| point_get | lin | 0.215 | 1.00× | validated |
| filter_eq | sqlite | 23.619 | 25.60× | validated |
| filter_eq | duckdb | 488.957 | 529.92× | validated |
| filter_eq | postgres | 258.353 | 280.00× | validated |
| filter_eq | mysql | 341.555 | 370.17× | validated |
| filter_eq | mongo | 659.615 | 714.88× | validated |
| filter_eq | pandas | 204.207 | 221.32× | validated |
| filter_eq | lin | 0.923 | 1.00× | validated |
| text_substr | sqlite | 74.828 | 18.77× | validated |
| text_substr | duckdb | 321.384 | 80.63× | validated |
| text_substr | postgres | 272.842 | 68.45× | validated |
| text_substr | mysql | 445.077 | 111.67× | validated |
| text_substr | mongo | 1264.206 | 317.18× | validated |
| text_substr | pandas | 267.756 | 67.18× | validated |
| text_substr | lin | 3.986 | 1.00× | validated |
| materialize | sqlite | 438.725 | 4.66× | validated |
| materialize | duckdb | 823.500 | 8.75× | validated |
| materialize | postgres | 557.544 | 5.92× | validated |
| materialize | mysql | 2605.662 | 27.69× | validated |
| materialize | mongo | 1900.822 | 20.20× | validated |
| materialize | pandas | 1262.148 | 13.41× | validated |
| materialize | lin | 94.111 | 1.00× | validated |
| join_inner | sqlite | 1030.308 | 2.90× | validated |
| join_inner | duckdb | 1322.899 | 3.73× | validated |
| join_inner | postgres | 1092.509 | 3.08× | validated |
| join_inner | mysql | 5390.414 | 15.19× | validated |
| join_inner | mongo | 38244.904 | 107.78× | validated |
| join_inner | pandas | 2462.961 | 6.94× | validated |
| join_inner | lin | 354.850 | 1.00× | validated |
| join_filter | sqlite | 534.831 | 3.02× | validated |
| join_filter | duckdb | 1005.103 | 5.68× | validated |
| join_filter | postgres | 718.549 | 4.06× | validated |
| join_filter | mysql | 2958.742 | 16.72× | validated |
| join_filter | mongo | 19815.312 | 111.98× | validated |
| join_filter | pandas | 2317.025 | 13.09× | validated |
| join_filter | lin | 176.960 | 1.00× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
