# Validated read API benchmark

Rows: 1000; process repetitions: 3; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.215 | 1.00× | validated |
| point_get | sqlite | 3.503 | 16.30× | validated |
| point_get | duckdb | 234.800 | 1092.45× | validated |
| point_get | postgres | 206.204 | 959.41× | validated |
| point_get | mysql | 248.885 | 1157.98× | validated |
| point_get | mongo | 461.719 | 2148.24× | validated |
| point_get | pandas | 17.426 | 81.08× | validated |
| filter_eq | lin | 0.923 | 1.00× | validated |
| filter_eq | sqlite | 23.619 | 25.60× | validated |
| filter_eq | duckdb | 488.201 | 529.19× | validated |
| filter_eq | postgres | 264.954 | 287.20× | validated |
| filter_eq | mysql | 341.555 | 370.23× | validated |
| filter_eq | mongo | 659.615 | 715.00× | validated |
| filter_eq | pandas | 200.649 | 217.50× | validated |
| text_substr | lin | 3.924 | 1.00× | validated |
| text_substr | sqlite | 74.828 | 19.07× | validated |
| text_substr | duckdb | 320.295 | 81.63× | validated |
| text_substr | postgres | 266.596 | 67.94× | validated |
| text_substr | mysql | 446.208 | 113.72× | validated |
| text_substr | mongo | 1238.170 | 315.55× | validated |
| text_substr | pandas | 266.811 | 68.00× | validated |
| materialize | lin | 94.293 | 1.00× | validated |
| materialize | sqlite | 449.429 | 4.77× | validated |
| materialize | duckdb | 823.500 | 8.73× | validated |
| materialize | postgres | 555.578 | 5.89× | validated |
| materialize | mysql | 2615.285 | 27.74× | validated |
| materialize | mongo | 1877.821 | 19.91× | validated |
| materialize | pandas | 1251.579 | 13.27× | validated |
| join_inner | lin | 351.598 | 1.00× | validated |
| join_inner | sqlite | 1037.485 | 2.95× | validated |
| join_inner | duckdb | 1322.899 | 3.76× | validated |
| join_inner | postgres | 1092.509 | 3.11× | validated |
| join_inner | mysql | 5421.889 | 15.42× | validated |
| join_inner | mongo | 38244.904 | 108.77× | validated |
| join_inner | pandas | 2418.618 | 6.88× | validated |
| join_filter | lin | 175.524 | 1.00× | validated |
| join_filter | sqlite | 538.736 | 3.07× | validated |
| join_filter | duckdb | 1005.103 | 5.73× | validated |
| join_filter | postgres | 713.994 | 4.07× | validated |
| join_filter | mysql | 2965.310 | 16.89× | validated |
| join_filter | mongo | 19832.936 | 112.99× | validated |
| join_filter | pandas | 2307.167 | 13.14× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
