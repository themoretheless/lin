# Validated read API benchmark

Rows: 1000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | duckdb | 234.800 | 1107.58× | validated |
| point_get | postgres | 221.537 | 1045.01× | validated |
| point_get | mysql | 242.212 | 1142.54× | validated |
| point_get | mongo | 493.757 | 2329.10× | validated |
| point_get | pandas | 17.426 | 82.20× | validated |
| point_get | lin | 0.212 | 1.00× | validated |
| point_get | sqlite | 3.503 | 16.52× | validated |
| filter_eq | duckdb | 488.201 | 535.73× | validated |
| filter_eq | postgres | 273.378 | 299.99× | validated |
| filter_eq | mysql | 327.281 | 359.14× | validated |
| filter_eq | mongo | 667.065 | 732.01× | validated |
| filter_eq | pandas | 200.649 | 220.18× | validated |
| filter_eq | lin | 0.911 | 1.00× | validated |
| filter_eq | sqlite | 23.543 | 25.83× | validated |
| text_substr | duckdb | 311.668 | 79.43× | validated |
| text_substr | postgres | 266.596 | 67.94× | validated |
| text_substr | mysql | 446.208 | 113.72× | validated |
| text_substr | mongo | 1238.170 | 315.55× | validated |
| text_substr | pandas | 264.774 | 67.48× | validated |
| text_substr | lin | 3.924 | 1.00× | validated |
| text_substr | sqlite | 75.514 | 19.25× | validated |
| materialize | duckdb | 808.332 | 8.56× | validated |
| materialize | postgres | 539.186 | 5.71× | validated |
| materialize | mysql | 2629.592 | 27.84× | validated |
| materialize | mongo | 1877.821 | 19.88× | validated |
| materialize | pandas | 1232.428 | 13.05× | validated |
| materialize | lin | 94.464 | 1.00× | validated |
| materialize | sqlite | 449.429 | 4.76× | validated |
| join_inner | duckdb | 1290.872 | 3.67× | validated |
| join_inner | postgres | 1083.646 | 3.08× | validated |
| join_inner | mysql | 5421.889 | 15.42× | validated |
| join_inner | mongo | 38676.190 | 110.00× | validated |
| join_inner | pandas | 2400.070 | 6.83× | validated |
| join_inner | lin | 351.598 | 1.00× | validated |
| join_inner | sqlite | 1049.550 | 2.99× | validated |
| join_filter | duckdb | 1002.252 | 5.86× | validated |
| join_filter | postgres | 713.994 | 4.18× | validated |
| join_filter | mysql | 2965.310 | 17.35× | validated |
| join_filter | mongo | 19836.257 | 116.05× | validated |
| join_filter | pandas | 2307.167 | 13.50× | validated |
| join_filter | lin | 170.924 | 1.00× | validated |
| join_filter | sqlite | 539.674 | 3.16× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
