# Validated read API benchmark

Rows: 1000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.215 | 1.00× | validated |
| point_get | sqlite | 3.566 | 16.59× | validated |
| point_get | duckdb | 233.298 | 1085.20× | validated |
| point_get | postgres | 203.768 | 947.84× | validated |
| point_get | mysql | 248.885 | 1157.70× | validated |
| point_get | mongo | 459.402 | 2136.93× | validated |
| point_get | pandas | 17.173 | 79.88× | validated |
| filter_eq | lin | 0.923 | 1.00× | validated |
| filter_eq | sqlite | 23.879 | 25.88× | validated |
| filter_eq | duckdb | 485.130 | 525.86× | validated |
| filter_eq | postgres | 264.954 | 287.20× | validated |
| filter_eq | mysql | 352.909 | 382.54× | validated |
| filter_eq | mongo | 658.321 | 713.60× | validated |
| filter_eq | pandas | 199.632 | 216.39× | validated |
| text_substr | lin | 3.907 | 1.00× | validated |
| text_substr | sqlite | 73.881 | 18.91× | validated |
| text_substr | duckdb | 320.295 | 81.98× | validated |
| text_substr | postgres | 261.929 | 67.04× | validated |
| text_substr | mysql | 457.331 | 117.05× | validated |
| text_substr | mongo | 1224.319 | 313.36× | validated |
| text_substr | pandas | 266.811 | 68.29× | validated |
| materialize | lin | 94.293 | 1.00× | validated |
| materialize | sqlite | 449.785 | 4.77× | validated |
| materialize | duckdb | 828.442 | 8.79× | validated |
| materialize | postgres | 555.578 | 5.89× | validated |
| materialize | mysql | 2615.285 | 27.74× | validated |
| materialize | mongo | 1869.326 | 19.82× | validated |
| materialize | pandas | 1251.579 | 13.27× | validated |
| join_inner | lin | 351.313 | 1.00× | validated |
| join_inner | sqlite | 1037.485 | 2.95× | validated |
| join_inner | duckdb | 1334.315 | 3.80× | validated |
| join_inner | postgres | 1108.238 | 3.15× | validated |
| join_inner | mysql | 5442.979 | 15.49× | validated |
| join_inner | mongo | 38131.208 | 108.54× | validated |
| join_inner | pandas | 2418.618 | 6.88× | validated |
| join_filter | lin | 175.524 | 1.00× | validated |
| join_filter | sqlite | 538.736 | 3.07× | validated |
| join_filter | duckdb | 1071.770 | 6.11× | validated |
| join_filter | postgres | 697.053 | 3.97× | validated |
| join_filter | mysql | 2968.211 | 16.91× | validated |
| join_filter | mongo | 19832.936 | 112.99× | validated |
| join_filter | pandas | 2258.158 | 12.87× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
