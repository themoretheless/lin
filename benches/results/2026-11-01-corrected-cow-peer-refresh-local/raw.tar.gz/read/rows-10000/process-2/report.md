# Validated read API benchmark

Rows: 10000; process repetitions: 1; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | sqlite | 0.923 | 7.89× | validated |
| point_get | duckdb | 33.432 | 285.83× | validated |
| point_get | postgres | 194.521 | 1663.10× | validated |
| point_get | mysql | 267.753 | 2289.22× | validated |
| point_get | mongo | 440.192 | 3763.53× | validated |
| point_get | pandas | 4.323 | 36.96× | validated |
| point_get | lin | 0.117 | 1.00× | validated |
| filter_eq | sqlite | 66.947 | 97.50× | validated |
| filter_eq | duckdb | 188.537 | 274.57× | validated |
| filter_eq | postgres | 397.215 | 578.47× | validated |
| filter_eq | mysql | 636.075 | 926.32× | validated |
| filter_eq | mongo | 981.004 | 1428.64× | validated |
| filter_eq | pandas | 258.366 | 376.26× | validated |
| filter_eq | lin | 0.687 | 1.00× | validated |
| text_substr | sqlite | 329.831 | 20.92× | validated |
| text_substr | duckdb | 99.869 | 6.34× | validated |
| text_substr | postgres | 715.233 | 45.37× | validated |
| text_substr | mysql | 1277.604 | 81.05× | validated |
| text_substr | mongo | 3319.209 | 210.56× | validated |
| text_substr | pandas | 476.052 | 30.20× | validated |
| text_substr | lin | 15.764 | 1.00× | validated |
| materialize | sqlite | 1811.906 | 4.70× | validated |
| materialize | duckdb | 1240.389 | 3.21× | validated |
| materialize | postgres | 1573.118 | 4.08× | validated |
| materialize | mysql | 9694.291 | 25.12× | validated |
| materialize | mongo | 5551.083 | 14.39× | validated |
| materialize | pandas | 1882.771 | 4.88× | validated |
| materialize | lin | 385.847 | 1.00× | validated |
| join_inner | sqlite | 4474.958 | 3.34× | validated |
| join_inner | duckdb | 2717.604 | 2.03× | validated |
| join_inner | postgres | 4407.480 | 3.29× | validated |
| join_inner | mysql | 20446.480 | 15.26× | validated |
| join_inner | mongo | 112848.479 | 84.24× | validated |
| join_inner | pandas | 4135.000 | 3.09× | validated |
| join_inner | lin | 1339.597 | 1.00× | validated |
| join_filter | sqlite | 2295.990 | 3.39× | validated |
| join_filter | duckdb | 1442.646 | 2.13× | validated |
| join_filter | postgres | 2507.208 | 3.70× | validated |
| join_filter | mysql | 10712.584 | 15.83× | validated |
| join_filter | mongo | 58465.313 | 86.38× | validated |
| join_filter | pandas | 2352.729 | 3.48× | validated |
| join_filter | lin | 676.857 | 1.00× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.11", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
