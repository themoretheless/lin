# Validated read API benchmark

Rows: 10000; process repetitions: 3; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.117 | 1.00× | validated |
| point_get | sqlite | 0.923 | 7.89× | validated |
| point_get | duckdb | 38.055 | 325.36× | validated |
| point_get | postgres | 200.630 | 1715.33× | validated |
| point_get | mysql | 322.786 | 2759.74× | validated |
| point_get | mongo | 440.192 | 3763.53× | validated |
| point_get | pandas | 4.323 | 36.96× | validated |
| filter_eq | lin | 0.680 | 1.00× | validated |
| filter_eq | sqlite | 68.208 | 100.33× | validated |
| filter_eq | duckdb | 183.603 | 270.06× | validated |
| filter_eq | postgres | 441.965 | 650.08× | validated |
| filter_eq | mysql | 643.919 | 947.13× | validated |
| filter_eq | mongo | 971.021 | 1428.26× | validated |
| filter_eq | pandas | 258.366 | 380.03× | validated |
| text_substr | lin | 15.764 | 1.00× | validated |
| text_substr | sqlite | 329.831 | 20.92× | validated |
| text_substr | duckdb | 99.869 | 6.34× | validated |
| text_substr | postgres | 715.233 | 45.37× | validated |
| text_substr | mysql | 1250.021 | 79.30× | validated |
| text_substr | mongo | 3238.729 | 205.45× | validated |
| text_substr | pandas | 476.052 | 30.20× | validated |
| materialize | lin | 380.632 | 1.00× | validated |
| materialize | sqlite | 1845.177 | 4.85× | validated |
| materialize | duckdb | 1250.292 | 3.28× | validated |
| materialize | postgres | 1581.736 | 4.16× | validated |
| materialize | mysql | 9706.229 | 25.50× | validated |
| materialize | mongo | 5386.500 | 14.15× | validated |
| materialize | pandas | 1882.771 | 4.95× | validated |
| join_inner | lin | 1341.958 | 1.00× | validated |
| join_inner | sqlite | 4486.896 | 3.34× | validated |
| join_inner | duckdb | 2719.791 | 2.03× | validated |
| join_inner | postgres | 4407.480 | 3.28× | validated |
| join_inner | mysql | 20190.917 | 15.05× | validated |
| join_inner | mongo | 112382.000 | 83.74× | validated |
| join_inner | pandas | 4033.271 | 3.01× | validated |
| join_filter | lin | 671.000 | 1.00× | validated |
| join_filter | sqlite | 2309.260 | 3.44× | validated |
| join_filter | duckdb | 1442.646 | 2.15× | validated |
| join_filter | postgres | 2500.323 | 3.73× | validated |
| join_filter | mysql | 10712.584 | 15.97× | validated |
| join_filter | mongo | 58722.209 | 87.51× | validated |
| join_filter | pandas | 2290.375 | 3.41× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.11", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
