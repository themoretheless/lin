# Validated read API benchmark

Rows: 10000; process repetitions: 1; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | duckdb | 38.055 | 327.46× | validated |
| point_get | postgres | 250.196 | 2152.91× | validated |
| point_get | mysql | 334.153 | 2875.37× | validated |
| point_get | mongo | 443.927 | 3819.96× | validated |
| point_get | pandas | 4.358 | 37.50× | validated |
| point_get | lin | 0.116 | 1.00× | validated |
| point_get | sqlite | 0.923 | 7.94× | validated |
| filter_eq | duckdb | 182.976 | 275.73× | validated |
| filter_eq | postgres | 446.267 | 672.48× | validated |
| filter_eq | mysql | 646.170 | 973.71× | validated |
| filter_eq | mongo | 971.021 | 1463.23× | validated |
| filter_eq | pandas | 260.987 | 393.28× | validated |
| filter_eq | lin | 0.664 | 1.00× | validated |
| filter_eq | sqlite | 69.445 | 104.65× | validated |
| text_substr | duckdb | 94.421 | 5.68× | validated |
| text_substr | postgres | 749.778 | 45.11× | validated |
| text_substr | mysql | 1250.021 | 75.20× | validated |
| text_substr | mongo | 3238.729 | 194.85× | validated |
| text_substr | pandas | 484.833 | 29.17× | validated |
| text_substr | lin | 16.622 | 1.00× | validated |
| text_substr | sqlite | 321.639 | 19.35× | validated |
| materialize | duckdb | 1258.417 | 3.32× | validated |
| materialize | postgres | 1797.292 | 4.75× | validated |
| materialize | mysql | 9706.229 | 25.63× | validated |
| materialize | mongo | 5386.500 | 14.22× | validated |
| materialize | pandas | 1929.385 | 5.09× | validated |
| materialize | lin | 378.753 | 1.00× | validated |
| materialize | sqlite | 1889.011 | 4.99× | validated |
| join_inner | duckdb | 2768.249 | 2.06× | validated |
| join_inner | postgres | 4526.500 | 3.37× | validated |
| join_inner | mysql | 20159.562 | 15.02× | validated |
| join_inner | mongo | 112382.000 | 83.74× | validated |
| join_inner | pandas | 4033.271 | 3.01× | validated |
| join_inner | lin | 1341.958 | 1.00× | validated |
| join_inner | sqlite | 4567.438 | 3.40× | validated |
| join_filter | duckdb | 1450.146 | 2.16× | validated |
| join_filter | postgres | 2414.823 | 3.60× | validated |
| join_filter | mysql | 10942.312 | 16.31× | validated |
| join_filter | mongo | 58722.209 | 87.51× | validated |
| join_filter | pandas | 2275.646 | 3.39× | validated |
| join_filter | lin | 671.000 | 1.00× | validated |
| join_filter | sqlite | 2345.938 | 3.50× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.11", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
