# Validated read API benchmark

Rows: 10000; process repetitions: 1; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.117 | 1.00× | validated |
| point_get | sqlite | 0.929 | 7.94× | validated |
| point_get | duckdb | 39.806 | 340.17× | validated |
| point_get | postgres | 200.630 | 1714.51× | validated |
| point_get | mysql | 322.786 | 2758.41× | validated |
| point_get | mongo | 423.690 | 3620.70× | validated |
| point_get | pandas | 4.212 | 35.99× | validated |
| filter_eq | lin | 0.680 | 1.00× | validated |
| filter_eq | sqlite | 68.208 | 100.33× | validated |
| filter_eq | duckdb | 183.603 | 270.06× | validated |
| filter_eq | postgres | 441.965 | 650.08× | validated |
| filter_eq | mysql | 643.919 | 947.13× | validated |
| filter_eq | mongo | 884.562 | 1301.09× | validated |
| filter_eq | pandas | 252.066 | 370.76× | validated |
| text_substr | lin | 15.730 | 1.00× | validated |
| text_substr | sqlite | 331.123 | 21.05× | validated |
| text_substr | duckdb | 101.192 | 6.43× | validated |
| text_substr | postgres | 713.031 | 45.33× | validated |
| text_substr | mysql | 1245.305 | 79.17× | validated |
| text_substr | mongo | 3118.396 | 198.24× | validated |
| text_substr | pandas | 464.721 | 29.54× | validated |
| materialize | lin | 380.632 | 1.00× | validated |
| materialize | sqlite | 1845.177 | 4.85× | validated |
| materialize | duckdb | 1250.292 | 3.28× | validated |
| materialize | postgres | 1581.736 | 4.16× | validated |
| materialize | mysql | 9771.916 | 25.67× | validated |
| materialize | mongo | 5281.000 | 13.87× | validated |
| materialize | pandas | 1881.448 | 4.94× | validated |
| join_inner | lin | 1358.924 | 1.00× | validated |
| join_inner | sqlite | 4486.896 | 3.30× | validated |
| join_inner | duckdb | 2719.791 | 2.00× | validated |
| join_inner | postgres | 3832.250 | 2.82× | validated |
| join_inner | mysql | 20190.917 | 14.86× | validated |
| join_inner | mongo | 112153.313 | 82.53× | validated |
| join_inner | pandas | 3934.979 | 2.90× | validated |
| join_filter | lin | 668.158 | 1.00× | validated |
| join_filter | sqlite | 2309.260 | 3.46× | validated |
| join_filter | duckdb | 1404.243 | 2.10× | validated |
| join_filter | postgres | 2500.323 | 3.74× | validated |
| join_filter | mysql | 10614.459 | 15.89× | validated |
| join_filter | mongo | 59316.187 | 88.78× | validated |
| join_filter | pandas | 2290.375 | 3.43× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.11", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
