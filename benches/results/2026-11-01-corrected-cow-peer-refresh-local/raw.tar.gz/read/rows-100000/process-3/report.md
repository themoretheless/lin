# Validated read API benchmark

Rows: 100000; process repetitions: 1; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | duckdb | 47.795 | 418.59× | validated |
| point_get | postgres | 288.817 | 2529.46× | validated |
| point_get | mysql | 1046.010 | 9160.97× | validated |
| point_get | mongo | 428.679 | 3754.38× | validated |
| point_get | pandas | 4.315 | 37.79× | validated |
| point_get | lin | 0.114 | 1.00× | validated |
| point_get | sqlite | 0.951 | 8.33× | validated |
| filter_eq | duckdb | 470.894 | 564.71× | validated |
| filter_eq | postgres | 2455.417 | 2944.62× | validated |
| filter_eq | mysql | 10132.250 | 12150.96× | validated |
| filter_eq | mongo | 5020.458 | 6020.71× | validated |
| filter_eq | pandas | 2257.969 | 2707.84× | validated |
| filter_eq | lin | 0.834 | 1.00× | validated |
| filter_eq | sqlite | 660.226 | 791.77× | validated |
| text_substr | duckdb | 550.225 | 2.70× | validated |
| text_substr | postgres | 5404.042 | 26.54× | validated |
| text_substr | mysql | 17053.145 | 83.75× | validated |
| text_substr | mongo | 26837.980 | 131.80× | validated |
| text_substr | pandas | 4474.958 | 21.98× | validated |
| text_substr | lin | 203.630 | 1.00× | validated |
| text_substr | sqlite | 3261.458 | 16.02× | validated |
| materialize | duckdb | 13273.708 | 2.70× | validated |
| materialize | postgres | 14508.897 | 2.96× | validated |
| materialize | mysql | 108055.667 | 22.02× | validated |
| materialize | mongo | 41390.855 | 8.43× | validated |
| materialize | pandas | 17333.000 | 3.53× | validated |
| materialize | lin | 4907.438 | 1.00× | validated |
| materialize | sqlite | 20097.625 | 4.10× | validated |
| join_inner | duckdb | 30359.604 | 1.85× | validated |
| join_inner | postgres | 43776.520 | 2.67× | validated |
| join_inner | mysql | 187154.271 | 11.40× | validated |
| join_inner | mongo | 1151482.646 | 70.12× | validated |
| join_inner | pandas | 36112.209 | 2.20× | validated |
| join_inner | lin | 16421.146 | 1.00× | validated |
| join_inner | sqlite | 50613.062 | 3.08× | validated |
| join_filter | duckdb | 15209.854 | 1.95× | validated |
| join_filter | postgres | 31111.875 | 3.98× | validated |
| join_filter | mysql | 89784.187 | 11.50× | validated |
| join_filter | mongo | 580720.875 | 74.38× | validated |
| join_filter | pandas | 18749.375 | 2.40× | validated |
| join_filter | lin | 7807.771 | 1.00× | validated |
| join_filter | sqlite | 25466.938 | 3.26× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.11", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
