# Validated read API benchmark

Rows: 100000; process repetitions: 1; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.113 | 1.00× | validated |
| point_get | sqlite | 0.953 | 8.42× | validated |
| point_get | duckdb | 35.285 | 311.92× | validated |
| point_get | postgres | 237.419 | 2098.77× | validated |
| point_get | mysql | 323.613 | 2860.72× | validated |
| point_get | mongo | 441.326 | 3901.30× | validated |
| point_get | pandas | 4.201 | 37.14× | validated |
| filter_eq | lin | 0.854 | 1.00× | validated |
| filter_eq | sqlite | 676.688 | 792.55× | validated |
| filter_eq | duckdb | 422.682 | 495.06× | validated |
| filter_eq | postgres | 2624.688 | 3074.10× | validated |
| filter_eq | mysql | 3320.834 | 3889.44× | validated |
| filter_eq | mongo | 5088.604 | 5959.90× | validated |
| filter_eq | pandas | 2226.979 | 2608.29× | validated |
| text_substr | lin | 207.899 | 1.00× | validated |
| text_substr | sqlite | 3383.209 | 16.27× | validated |
| text_substr | duckdb | 493.718 | 2.37× | validated |
| text_substr | postgres | 5313.688 | 25.56× | validated |
| text_substr | mysql | 9672.875 | 46.53× | validated |
| text_substr | mongo | 27246.500 | 131.06× | validated |
| text_substr | pandas | 4542.188 | 21.85× | validated |
| materialize | lin | 6311.229 | 1.00× | validated |
| materialize | sqlite | 20273.084 | 3.21× | validated |
| materialize | duckdb | 13067.375 | 2.07× | validated |
| materialize | postgres | 17662.041 | 2.80× | validated |
| materialize | mysql | 83551.145 | 13.24× | validated |
| materialize | mongo | 43408.312 | 6.88× | validated |
| materialize | pandas | 17121.729 | 2.71× | validated |
| join_inner | lin | 16667.520 | 1.00× | validated |
| join_inner | sqlite | 50930.728 | 3.06× | validated |
| join_inner | duckdb | 29182.896 | 1.75× | validated |
| join_inner | postgres | 47208.292 | 2.83× | validated |
| join_inner | mysql | 167125.812 | 10.03× | validated |
| join_inner | mongo | 1118759.604 | 67.12× | validated |
| join_inner | pandas | 36235.292 | 2.17× | validated |
| join_filter | lin | 8527.229 | 1.00× | validated |
| join_filter | sqlite | 25854.917 | 3.03× | validated |
| join_filter | duckdb | 14427.209 | 1.69× | validated |
| join_filter | postgres | 25293.708 | 2.97× | validated |
| join_filter | mysql | 89297.750 | 10.47× | validated |
| join_filter | mongo | 565499.292 | 66.32× | validated |
| join_filter | pandas | 18645.354 | 2.19× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.11", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
