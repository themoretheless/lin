# Validated read API benchmark

Rows: 100000; process repetitions: 3; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.114 | 1.00× | validated |
| point_get | sqlite | 0.953 | 8.34× | validated |
| point_get | duckdb | 39.662 | 347.36× | validated |
| point_get | postgres | 247.828 | 2170.48× | validated |
| point_get | mysql | 341.411 | 2990.08× | validated |
| point_get | mongo | 441.326 | 3865.14× | validated |
| point_get | pandas | 4.229 | 37.04× | validated |
| filter_eq | lin | 0.854 | 1.00× | validated |
| filter_eq | sqlite | 660.226 | 773.27× | validated |
| filter_eq | duckdb | 446.286 | 522.70× | validated |
| filter_eq | postgres | 2582.167 | 3024.30× | validated |
| filter_eq | mysql | 3342.604 | 3914.94× | validated |
| filter_eq | mongo | 5088.604 | 5959.90× | validated |
| filter_eq | pandas | 2226.979 | 2608.29× | validated |
| text_substr | lin | 206.853 | 1.00× | validated |
| text_substr | sqlite | 3267.583 | 15.80× | validated |
| text_substr | duckdb | 493.718 | 2.39× | validated |
| text_substr | postgres | 5330.208 | 25.77× | validated |
| text_substr | mysql | 9672.875 | 46.76× | validated |
| text_substr | mongo | 27246.500 | 131.72× | validated |
| text_substr | pandas | 4474.958 | 21.63× | validated |
| materialize | lin | 5604.437 | 1.00× | validated |
| materialize | sqlite | 20114.480 | 3.59× | validated |
| materialize | duckdb | 13067.375 | 2.33× | validated |
| materialize | postgres | 17510.041 | 3.12× | validated |
| materialize | mysql | 83551.145 | 14.91× | validated |
| materialize | mongo | 43408.312 | 7.75× | validated |
| materialize | pandas | 17121.729 | 3.06× | validated |
| join_inner | lin | 16559.042 | 1.00× | validated |
| join_inner | sqlite | 50706.750 | 3.06× | validated |
| join_inner | duckdb | 29182.896 | 1.76× | validated |
| join_inner | postgres | 43776.520 | 2.64× | validated |
| join_inner | mysql | 167125.812 | 10.09× | validated |
| join_inner | mongo | 1127863.083 | 68.11× | validated |
| join_inner | pandas | 36235.292 | 2.19× | validated |
| join_filter | lin | 7854.395 | 1.00× | validated |
| join_filter | sqlite | 25466.938 | 3.24× | validated |
| join_filter | duckdb | 14427.209 | 1.84× | validated |
| join_filter | postgres | 25293.708 | 3.22× | validated |
| join_filter | mysql | 89297.750 | 11.37× | validated |
| join_filter | mongo | 569591.938 | 72.52× | validated |
| join_filter | pandas | 18700.750 | 2.38× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.11", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
