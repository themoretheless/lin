# Validated read API benchmark

Rows: 100000; process repetitions: 1; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | sqlite | 0.962 | 8.24× | validated |
| point_get | duckdb | 39.662 | 339.53× | validated |
| point_get | postgres | 247.828 | 2121.51× | validated |
| point_get | mysql | 341.411 | 2922.62× | validated |
| point_get | mongo | 457.208 | 3913.90× | validated |
| point_get | pandas | 4.229 | 36.20× | validated |
| point_get | lin | 0.117 | 1.00× | validated |
| filter_eq | sqlite | 652.771 | 751.69× | validated |
| filter_eq | duckdb | 446.286 | 513.92× | validated |
| filter_eq | postgres | 2582.167 | 2973.46× | validated |
| filter_eq | mysql | 3342.604 | 3849.13× | validated |
| filter_eq | mongo | 5240.479 | 6034.61× | validated |
| filter_eq | pandas | 2206.083 | 2540.39× | validated |
| filter_eq | lin | 0.868 | 1.00× | validated |
| text_substr | sqlite | 3267.583 | 15.80× | validated |
| text_substr | duckdb | 461.248 | 2.23× | validated |
| text_substr | postgres | 5330.208 | 25.77× | validated |
| text_substr | mysql | 9390.500 | 45.40× | validated |
| text_substr | mongo | 27410.562 | 132.51× | validated |
| text_substr | pandas | 4440.812 | 21.47× | validated |
| text_substr | lin | 206.853 | 1.00× | validated |
| materialize | sqlite | 20114.480 | 3.59× | validated |
| materialize | duckdb | 12356.459 | 2.20× | validated |
| materialize | postgres | 17510.041 | 3.12× | validated |
| materialize | mysql | 82411.917 | 14.70× | validated |
| materialize | mongo | 43810.313 | 7.82× | validated |
| materialize | pandas | 17049.062 | 3.04× | validated |
| materialize | lin | 5604.437 | 1.00× | validated |
| join_inner | sqlite | 50706.750 | 3.06× | validated |
| join_inner | duckdb | 28327.042 | 1.71× | validated |
| join_inner | postgres | 39964.709 | 2.41× | validated |
| join_inner | mysql | 164164.959 | 9.91× | validated |
| join_inner | mongo | 1127863.083 | 68.11× | validated |
| join_inner | pandas | 37559.125 | 2.27× | validated |
| join_inner | lin | 16559.042 | 1.00× | validated |
| join_filter | sqlite | 25132.791 | 3.20× | validated |
| join_filter | duckdb | 13796.666 | 1.76× | validated |
| join_filter | postgres | 21499.125 | 2.74× | validated |
| join_filter | mysql | 88226.542 | 11.23× | validated |
| join_filter | mongo | 569591.938 | 72.52× | validated |
| join_filter | pandas | 18700.750 | 2.38× | validated |
| join_filter | lin | 7854.395 | 1.00× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.11", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
