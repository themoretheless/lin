# Validated read API benchmark

Rows: 1000; process repetitions: 1; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | duckdb | 36.725 | 311.93× | validated |
| point_get | postgres | 292.288 | 2482.62× | validated |
| point_get | mysql | 264.540 | 2246.95× | validated |
| point_get | mongo | 401.144 | 3407.22× | validated |
| point_get | pandas | 4.332 | 36.79× | validated |
| point_get | lin | 0.118 | 1.00× | validated |
| point_get | sqlite | 0.922 | 7.83× | validated |
| filter_eq | duckdb | 136.518 | 210.50× | validated |
| filter_eq | postgres | 324.163 | 499.84× | validated |
| filter_eq | mysql | 297.403 | 458.58× | validated |
| filter_eq | mongo | 492.178 | 758.91× | validated |
| filter_eq | pandas | 58.722 | 90.55× | validated |
| filter_eq | lin | 0.649 | 1.00× | validated |
| filter_eq | sqlite | 7.353 | 11.34× | validated |
| text_substr | duckdb | 56.769 | 30.35× | validated |
| text_substr | postgres | 332.523 | 177.75× | validated |
| text_substr | mysql | 335.106 | 179.13× | validated |
| text_substr | mongo | 716.286 | 382.90× | validated |
| text_substr | pandas | 76.344 | 40.81× | validated |
| text_substr | lin | 1.871 | 1.00× | validated |
| text_substr | sqlite | 31.984 | 17.10× | validated |
| materialize | duckdb | 298.897 | 7.46× | validated |
| materialize | postgres | 421.093 | 10.50× | validated |
| materialize | mysql | 1212.688 | 30.25× | validated |
| materialize | mongo | 1292.667 | 32.25× | validated |
| materialize | pandas | 376.767 | 9.40× | validated |
| materialize | lin | 40.086 | 1.00× | validated |
| materialize | sqlite | 166.889 | 4.16× | validated |
| join_inner | duckdb | 366.675 | 2.73× | validated |
| join_inner | postgres | 601.865 | 4.49× | validated |
| join_inner | mysql | 2128.385 | 15.87× | validated |
| join_inner | mongo | 12877.084 | 96.04× | validated |
| join_inner | pandas | 732.438 | 5.46× | validated |
| join_inner | lin | 134.074 | 1.00× | validated |
| join_inner | sqlite | 396.146 | 2.95× | validated |
| join_filter | duckdb | 245.355 | 3.64× | validated |
| join_filter | postgres | 454.669 | 6.74× | validated |
| join_filter | mysql | 1303.396 | 19.31× | validated |
| join_filter | mongo | 7268.292 | 107.70× | validated |
| join_filter | pandas | 643.158 | 9.53× | validated |
| join_filter | lin | 67.487 | 1.00× | validated |
| join_filter | sqlite | 212.806 | 3.15× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.11", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
