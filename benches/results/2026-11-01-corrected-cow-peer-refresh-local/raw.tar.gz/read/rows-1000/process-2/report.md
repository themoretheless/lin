# Validated read API benchmark

Rows: 1000; process repetitions: 1; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | sqlite | 0.910 | 7.61× | validated |
| point_get | duckdb | 38.852 | 325.16× | validated |
| point_get | postgres | 210.026 | 1757.76× | validated |
| point_get | mysql | 263.403 | 2204.48× | validated |
| point_get | mongo | 351.648 | 2943.02× | validated |
| point_get | pandas | 4.325 | 36.20× | validated |
| point_get | lin | 0.119 | 1.00× | validated |
| filter_eq | sqlite | 7.475 | 11.27× | validated |
| filter_eq | duckdb | 140.112 | 211.31× | validated |
| filter_eq | postgres | 206.395 | 311.28× | validated |
| filter_eq | mysql | 238.259 | 359.34× | validated |
| filter_eq | mongo | 440.178 | 663.87× | validated |
| filter_eq | pandas | 55.550 | 83.78× | validated |
| filter_eq | lin | 0.663 | 1.00× | validated |
| text_substr | sqlite | 32.147 | 17.35× | validated |
| text_substr | duckdb | 61.849 | 33.38× | validated |
| text_substr | postgres | 228.311 | 123.22× | validated |
| text_substr | mysql | 300.785 | 162.34× | validated |
| text_substr | mongo | 740.988 | 399.92× | validated |
| text_substr | pandas | 75.322 | 40.65× | validated |
| text_substr | lin | 1.853 | 1.00× | validated |
| materialize | sqlite | 165.180 | 4.13× | validated |
| materialize | duckdb | 294.753 | 7.37× | validated |
| materialize | postgres | 327.108 | 8.18× | validated |
| materialize | mysql | 1226.771 | 30.69× | validated |
| materialize | mongo | 1261.653 | 31.56× | validated |
| materialize | pandas | 388.858 | 9.73× | validated |
| materialize | lin | 39.974 | 1.00× | validated |
| join_inner | sqlite | 391.564 | 2.91× | validated |
| join_inner | duckdb | 354.654 | 2.64× | validated |
| join_inner | postgres | 578.463 | 4.30× | validated |
| join_inner | mysql | 2254.532 | 16.77× | validated |
| join_inner | mongo | 12575.084 | 93.56× | validated |
| join_inner | pandas | 735.774 | 5.47× | validated |
| join_inner | lin | 134.409 | 1.00× | validated |
| join_filter | sqlite | 202.176 | 2.99× | validated |
| join_filter | duckdb | 261.048 | 3.86× | validated |
| join_filter | postgres | 406.674 | 6.02× | validated |
| join_filter | mysql | 1331.680 | 19.70× | validated |
| join_filter | mongo | 7386.333 | 109.29× | validated |
| join_filter | pandas | 637.768 | 9.44× | validated |
| join_filter | lin | 67.586 | 1.00× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.11", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
