# Validated read API benchmark

Rows: 1000; process repetitions: 3; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.118 | 1.00× | validated |
| point_get | sqlite | 0.910 | 7.73× | validated |
| point_get | duckdb | 37.735 | 320.51× | validated |
| point_get | postgres | 287.815 | 2444.64× | validated |
| point_get | mysql | 263.403 | 2237.28× | validated |
| point_get | mongo | 381.747 | 3242.47× | validated |
| point_get | pandas | 4.325 | 36.74× | validated |
| filter_eq | lin | 0.663 | 1.00× | validated |
| filter_eq | sqlite | 7.424 | 11.20× | validated |
| filter_eq | duckdb | 138.973 | 209.60× | validated |
| filter_eq | postgres | 323.689 | 488.18× | validated |
| filter_eq | mysql | 242.506 | 365.74× | validated |
| filter_eq | mongo | 473.039 | 713.43× | validated |
| filter_eq | pandas | 58.722 | 88.56× | validated |
| text_substr | lin | 1.853 | 1.00× | validated |
| text_substr | sqlite | 32.147 | 17.35× | validated |
| text_substr | duckdb | 61.849 | 33.38× | validated |
| text_substr | postgres | 332.523 | 179.46× | validated |
| text_substr | mysql | 330.542 | 178.40× | validated |
| text_substr | mongo | 729.344 | 393.63× | validated |
| text_substr | pandas | 75.322 | 40.65× | validated |
| materialize | lin | 40.086 | 1.00× | validated |
| materialize | sqlite | 165.180 | 4.12× | validated |
| materialize | duckdb | 294.753 | 7.35× | validated |
| materialize | postgres | 421.093 | 10.50× | validated |
| materialize | mysql | 1212.688 | 30.25× | validated |
| materialize | mongo | 1261.653 | 31.47× | validated |
| materialize | pandas | 376.767 | 9.40× | validated |
| join_inner | lin | 134.196 | 1.00× | validated |
| join_inner | sqlite | 391.564 | 2.92× | validated |
| join_inner | duckdb | 354.654 | 2.64× | validated |
| join_inner | postgres | 601.865 | 4.48× | validated |
| join_inner | mysql | 2227.532 | 16.60× | validated |
| join_inner | mongo | 12877.084 | 95.96× | validated |
| join_inner | pandas | 732.438 | 5.46× | validated |
| join_filter | lin | 67.586 | 1.00× | validated |
| join_filter | sqlite | 202.176 | 2.99× | validated |
| join_filter | duckdb | 246.017 | 3.64× | validated |
| join_filter | postgres | 453.171 | 6.71× | validated |
| join_filter | mysql | 1309.604 | 19.38× | validated |
| join_filter | mongo | 7268.292 | 107.54× | validated |
| join_filter | pandas | 637.768 | 9.44× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.11", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
