# Validated read API benchmark

Rows: 1000; process repetitions: 1; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.117 | 1.00× | validated |
| point_get | sqlite | 0.900 | 7.73× | validated |
| point_get | duckdb | 37.735 | 323.83× | validated |
| point_get | postgres | 287.815 | 2469.94× | validated |
| point_get | mysql | 262.240 | 2250.46× | validated |
| point_get | mongo | 381.747 | 3276.03× | validated |
| point_get | pandas | 4.235 | 36.34× | validated |
| filter_eq | lin | 0.670 | 1.00× | validated |
| filter_eq | sqlite | 7.424 | 11.08× | validated |
| filter_eq | duckdb | 138.973 | 207.35× | validated |
| filter_eq | postgres | 323.689 | 482.95× | validated |
| filter_eq | mysql | 242.506 | 361.82× | validated |
| filter_eq | mongo | 473.039 | 705.78× | validated |
| filter_eq | pandas | 59.124 | 88.21× | validated |
| text_substr | lin | 1.835 | 1.00× | validated |
| text_substr | sqlite | 32.240 | 17.57× | validated |
| text_substr | duckdb | 64.812 | 35.32× | validated |
| text_substr | postgres | 371.708 | 202.56× | validated |
| text_substr | mysql | 330.542 | 180.13× | validated |
| text_substr | mongo | 729.344 | 397.45× | validated |
| text_substr | pandas | 74.621 | 40.66× | validated |
| materialize | lin | 40.521 | 1.00× | validated |
| materialize | sqlite | 162.836 | 4.02× | validated |
| materialize | duckdb | 291.619 | 7.20× | validated |
| materialize | postgres | 444.773 | 10.98× | validated |
| materialize | mysql | 1149.995 | 28.38× | validated |
| materialize | mongo | 1256.276 | 31.00× | validated |
| materialize | pandas | 369.882 | 9.13× | validated |
| join_inner | lin | 134.196 | 1.00× | validated |
| join_inner | sqlite | 389.543 | 2.90× | validated |
| join_inner | duckdb | 351.528 | 2.62× | validated |
| join_inner | postgres | 633.482 | 4.72× | validated |
| join_inner | mysql | 2227.532 | 16.60× | validated |
| join_inner | mongo | 13078.291 | 97.46× | validated |
| join_inner | pandas | 718.944 | 5.36× | validated |
| join_filter | lin | 68.236 | 1.00× | validated |
| join_filter | sqlite | 201.714 | 2.96× | validated |
| join_filter | duckdb | 246.017 | 3.61× | validated |
| join_filter | postgres | 453.171 | 6.64× | validated |
| join_filter | mysql | 1309.604 | 19.19× | validated |
| join_filter | mongo | 7238.000 | 106.07× | validated |
| join_filter | pandas | 634.542 | 9.30× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.11", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
