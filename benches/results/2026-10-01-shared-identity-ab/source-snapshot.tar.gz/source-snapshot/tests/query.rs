use futures_util::StreamExt;
use lin::query::pred;
use lin::{AsyncDb, Cell, Db, DurUnit, Duration, LinRow, MatchPath, Queryable, RowExt, Value};

#[derive(Debug, LinRow)]
#[lin(collection = "docs")]
struct DocTitle {
    id: String,
    title: String,
}

#[derive(Debug, LinRow)]
struct Stamp {
    hash: String,
    ts: i64,
}

#[derive(Debug, LinRow)]
#[lin(collection = "docs")]
struct DocStamp {
    id: String,
    title: String,
    #[lin(owned)]
    stamp: Stamp,
}

#[derive(Debug, LinRow)]
struct OrderLine {
    id: String,
    total: f64,
    #[lin(rename = "users.email")]
    email: String,
}

#[test]
fn fluent_filter_select_take() {
    let mut db = Db::fixture();
    let rows = db
        .from("docs")
        .filter(pred::eq("wing", "rag"))
        .select(["id", "title"])
        .take(5)
        .to_vec()
        .unwrap();
    assert!(!rows.is_empty());
    assert!(rows.len() <= 5);
    assert!(rows[0].contains_key("id"));
    assert!(rows[0].contains_key("title"));
    assert!(!rows[0].contains_key("body"));
}

#[test]
fn run_stmt_matches_string() {
    let mut db = Db::fixture();
    let via_str = db
        .run(r#"docs | wing == "rag" | { id, title } | take 3"#)
        .unwrap();
    let q = Queryable::from("docs")
        .filter(pred::eq("wing", "rag"))
        .select(["id", "title"])
        .take(3);
    let via_stmt = db.run_stmt(q.stmt()).unwrap();
    assert_eq!(via_str.done.n, via_stmt.done.n);
    assert_eq!(via_str.rows.len(), via_stmt.rows.len());
}

#[test]
fn typed_from_row() {
    let mut db = Db::fixture();
    let docs: Vec<DocTitle> = db
        .from("docs")
        .filter(pred::eq("wing", "rag"))
        .select_row::<DocTitle>()
        .take(10)
        .to_vec_typed()
        .unwrap();
    assert!(!docs.is_empty());
    assert!(!docs[0].id.is_empty());
    assert!(!docs[0].title.is_empty());
}

#[test]
fn from_typed_uses_collection() {
    let mut db = Db::fixture();
    let docs: Vec<DocTitle> = db
        .from_typed::<DocTitle>()
        .unwrap()
        .take(3)
        .to_vec_typed()
        .unwrap();
    assert!(!docs.is_empty());
}

#[test]
fn pred_and_with_ago() {
    let mut db = Db::fixture();
    let rows = db
        .from("docs")
        .filter(pred::eq("wing", "rag").and(pred::gt(
            "ts",
            Value::NowMinus(Duration {
                n: 3650,
                unit: DurUnit::Day,
            }),
        )))
        .select(["id", "title"])
        .take(5)
        .to_vec()
        .unwrap();
    assert!(!rows.is_empty());
}

#[test]
fn cell_match_via_row_ext() {
    let mut db = Db::fixture();
    let rows = db
        .from("docs")
        .filter(pred::eq("wing", "rag"))
        .select(["id", "title"])
        .take(1)
        .to_vec()
        .unwrap();
    let row = &rows[0];
    match row.cell("title") {
        Cell::Text(s) => assert!(!s.is_empty()),
        other => panic!("expected Text, got {other:?}"),
    }
    assert!(matches!(row.cell("missing_col"), Cell::Null));
    assert!(row.cell("missing_col").is_null());
}

#[test]
fn first_not_implicit_take() {
    let mut db = Db::fixture();
    let row = db.from("docs").select(["id"]).first().unwrap();
    assert!(row.contains_key("id"));

    let missing = db
        .from("docs")
        .filter(pred::eq("id", "__no_such_doc__"))
        .first_or()
        .unwrap();
    assert!(missing.is_none());

    let err = db
        .from("docs")
        .filter(pred::eq("id", "__no_such_doc__"))
        .first()
        .unwrap_err();
    assert!(err.to_string().contains("no rows"));

    let extra = db.from("docs").select(["id"]).single().unwrap_err();
    assert!(extra.to_string().contains("expected one row"));
}

#[test]
fn scalar_and_execute() {
    let mut db = Db::fixture();
    let hits: i64 = db.from("docs").count().scalar_as().unwrap();
    assert!(hits > 0);
    assert_eq!(db.scalar("docs | count").unwrap(), Cell::Int(hits));

    let done = db
        .execute(r#"insert docs { uri: "raw://n/ado", title: "ado", layer: "raw", body: "x" }"#)
        .unwrap();
    assert_eq!(done.n, 1);
    assert!(done.r#gen >= 1);
}

#[test]
fn typed_cursor_join_and_first_or() {
    let mut db = Db::fixture();
    let doc: DocTitle = db.from_typed::<DocTitle>().unwrap().first_typed().unwrap();
    assert!(!doc.id.is_empty());

    let none = db
        .from_typed::<DocTitle>()
        .unwrap()
        .filter(|d| d.id.eq("__no_such_doc__"))
        .first_or_typed::<DocTitle>()
        .unwrap();
    assert!(none.is_none());

    let mut cur = db
        .from_typed::<DocTitle>()
        .unwrap()
        .take(3)
        .cursor()
        .unwrap();
    let row = cur.next_typed::<DocTitle>().unwrap().unwrap();
    assert!(!row.title.is_empty() || !row.id.is_empty());

    let lines: Vec<OrderLine> = db
        .from("orders")
        .join("users", "user_id")
        .select_row::<OrderLine>()
        .take(5)
        .to_vec_typed()
        .unwrap();
    assert!(!lines.is_empty());
    assert!(lines[0].email.contains('@'));
    assert!(!lines[0].id.is_empty());
    assert!(lines[0].total > 0.0);
}

#[test]
fn filter_by_closure_is_pred() {
    let mut db = Db::fixture();
    let via_pred = db
        .from_typed::<DocTitle>()
        .unwrap()
        .filter(|d| d.title.has("WAL"))
        .take(5)
        .to_vec_typed::<DocTitle>()
        .unwrap();
    let via_fn = db
        .from_typed::<DocTitle>()
        .unwrap()
        .filter_by::<DocTitle>(|d| d.title.has("WAL"))
        .take(5)
        .to_vec_typed::<DocTitle>()
        .unwrap();
    assert_eq!(via_pred.len(), via_fn.len());

    let owned = db
        .from("docs")
        .select(["id", "title", "hash", "ts"])
        .take(3)
        .to_vec_typed::<DocStamp>()
        .unwrap();
    assert!(!owned.is_empty());
}

#[test]
fn filter_dialect_gt() {
    let mut db = Db::fixture();
    let via_pred = db
        .from("orders")
        .filter(pred::gt("total", 100.0))
        .take_all()
        .to_vec()
        .unwrap();
    let via_src = db
        .from("orders")
        .filter("total > 100")
        .take_all()
        .to_vec()
        .unwrap();
    let via_macro = db
        .from("orders")
        .filter(lin::p!(total > 100.0))
        .take_all()
        .to_vec()
        .unwrap();
    assert_eq!(via_pred.len(), via_src.len());
    assert_eq!(via_pred.len(), via_macro.len());
}

#[test]
fn filter_typed_lambda() {
    let mut db = Db::fixture();
    let via_fn = db
        .from_typed::<DocTitle>()
        .unwrap()
        .filter(|d| d.title.has("WAL"))
        .take(5)
        .to_vec_typed::<DocTitle>()
        .unwrap();
    let via_src = db
        .from("docs")
        .select_row::<DocTitle>()
        .filter("title has \"WAL\"")
        .take(5)
        .to_vec_typed::<DocTitle>()
        .unwrap();
    assert_eq!(via_src.len(), via_fn.len());
}

#[test]
fn skip_offset_paging() {
    let mut db = Db::fixture();
    let all = db
        .from("docs")
        .filter(pred::eq("wing", "rag"))
        .select(["id", "title"])
        .take(10)
        .to_vec()
        .unwrap();
    assert!(all.len() >= 2);

    let page = db
        .from("docs")
        .filter(pred::eq("wing", "rag"))
        .select(["id", "title"])
        .skip(1)
        .take(1)
        .to_vec()
        .unwrap();
    assert_eq!(page.len(), 1);
    assert_eq!(page[0].get("id"), all[1].get("id"));

    let via_offset = db
        .run(r#"docs | wing == "rag" | { id, title } | offset 1 | take 1"#)
        .unwrap();
    assert_eq!(via_offset.rows.len(), 1);
    assert_eq!(via_offset.rows[0].get("id"), page[0].get("id"));
}

#[test]
fn lazy_cursor_matches_to_vec() {
    let mut db = Db::fixture();
    let q = Queryable::from("docs")
        .filter(pred::eq("wing", "rag"))
        .select(["id", "title"])
        .take(5);
    let via_vec = q.to_vec(&mut db).unwrap();
    let cur = q.cursor(&db).unwrap();
    assert!(cur.is_lazy());
    let via_cur: Vec<_> = cur.map(|r| r.unwrap()).collect();
    assert_eq!(via_cur, via_vec);

    let mut projected = q.cursor(&db).unwrap();
    let via_projected: Vec<_> = std::iter::from_fn(|| projected.next_projected())
        .map(|row| row.unwrap())
        .collect();
    assert_eq!(via_projected[0].fields(), ["id", "title"]);
    assert!(via_projected[0].get("id").is_some());
    assert_eq!(
        via_projected
            .into_iter()
            .map(lin::ProjectedRow::into_row)
            .collect::<Vec<_>>(),
        via_vec
    );
}

#[test]
fn explain_and_after_keyset() {
    let mut db = Db::fixture();
    let q = Queryable::from("docs")
        .filter(pred::eq("wing", "rag"))
        .select(["id", "title"])
        .skip(1)
        .take(2);
    let plan = q.explain(&mut db).unwrap();
    assert!(
        plan.contains("Take") || plan.contains("Skip") || plan.contains("Filter"),
        "{plan}"
    );

    // Keyset on numeric field (text/id columns disallow `>` in check).
    let page1 = db
        .from("orders")
        .select(["id", "total"])
        .sort("total", false)
        .take(1)
        .to_vec()
        .unwrap();
    assert_eq!(page1.len(), 1);
    let total = page1[0].get("total").and_then(|c| c.as_f64()).unwrap();
    let page2 = db
        .from("orders")
        .after("total", total)
        .select(["id", "total"])
        .sort("total", false)
        .take(1)
        .to_vec()
        .unwrap();
    assert_eq!(page2.len(), 1);
    let total2 = page2[0].get("total").and_then(|c| c.as_f64()).unwrap();
    assert!(total2 > total);
}

#[test]
fn lazy_join_cursor() {
    let mut db = Db::fixture();
    let q = Queryable::from("orders")
        .filter(pred::gt("total", 100))
        .join("users", "user_id")
        .select(["id", "users.email", "total"])
        .take(10);
    let via_vec = q.to_vec(&mut db).unwrap();
    assert_eq!(via_vec.len(), 1);
    let cur = q.cursor(&db).unwrap();
    assert!(cur.is_lazy(), "FK join should be lazy");
    let via_cur: Vec<_> = cur.map(|r| r.unwrap()).collect();
    assert_eq!(via_cur, via_vec);

    let mut projected = q.cursor(&db).unwrap();
    let via_projected: Vec<_> = std::iter::from_fn(|| projected.next_projected())
        .map(|row| row.unwrap().into_row())
        .collect();
    assert_eq!(via_projected, via_vec);
}

#[test]
fn join_run_batch_matches_rows() {
    let mut db = Db::fixture();
    let src =
        r#"orders | total > 100 | join users on user_id | { id, users.email, total } | take all"#;
    let rows = db.run(src).unwrap();
    let batch = db.run_batch(src).unwrap();
    assert_eq!(batch.n(), rows.done.n);
    assert_eq!(batch.to_rows(), rows.rows);
}

#[test]
fn filter_project_run_batch_matches_rows() {
    let mut db = Db::fixture();
    let src = r#"docs | wing == "rag" | { id, title, wing } | take 10"#;
    let rows = db.run(src).unwrap();
    let batch = db.run_batch(src).unwrap();
    assert_eq!(batch.n(), rows.done.n);
    assert_eq!(batch.to_rows(), rows.rows);
    assert!(batch.n() > 0);
    assert_eq!(
        batch.names.as_ref(),
        &["id".to_string(), "title".to_string(), "wing".to_string()][..]
    );
}

#[test]
fn fluent_hop_and_match() {
    let mut db = Db::fixture();
    let ins = db
        .run(
            r#"insert docs { uri: "raw://n/fluent-hop", title: "fluent hop", layer: "raw" } with edge wikilink -> page "wiki://rag-overview""#,
        )
        .unwrap();
    let id = ins.rows[0].get("id").and_then(|c| c.text()).unwrap();

    let via_str = db
        .run(&format!(
            r#"docs | id == "{id}" | hop wikilink | {{ id, title }}"#
        ))
        .unwrap();
    let via_fluent = Queryable::from("docs")
        .filter(pred::eq("id", id))
        .hop("wikilink")
        .select(["id", "title"])
        .to_vec(&mut db)
        .unwrap();
    assert_eq!(via_fluent.len(), via_str.rows.len());

    let via_match_str = db
        .run(&format!(
            r#"docs | id == "{id}" | match -wikilink-> b | {{ id, b.title }}"#
        ))
        .unwrap();
    let via_match = Queryable::from("docs")
        .filter(pred::eq("id", id))
        .match_path(MatchPath::fwd("wikilink", "b"))
        .select(["id", "b.title"])
        .to_vec(&mut db)
        .unwrap();
    assert_eq!(via_match.len(), via_match_str.rows.len());

    let cur = Queryable::from("docs")
        .filter(pred::eq("id", id))
        .hop("wikilink")
        .select(["id", "title"])
        .cursor(&db)
        .unwrap();
    assert!(cur.is_lazy(), "hop depth=1 should be lazy");
    let via_cur: Vec<_> = cur.filter_map(Result::ok).collect();
    assert_eq!(via_cur.len(), via_fluent.len());
}

#[test]
fn lazy_search_lex_cursor() {
    let mut db = Db::fixture();
    let via_vec = Queryable::from("docs")
        .search_lex("wal")
        .take(5)
        .to_vec(&mut db)
        .unwrap();
    let cur = Queryable::from("docs")
        .search_lex("wal")
        .take(5)
        .cursor(&db)
        .unwrap();
    assert!(cur.is_lazy(), "search lex|take should be lazy");
    let via_cur: Vec<_> = cur.filter_map(Result::ok).collect();
    assert_eq!(via_cur.len(), via_vec.len());
}

#[test]
fn fluent_search_vec() {
    let mut db = Db::fixture();
    let via_dsl = db
        .run(r#"docs | search vec "wal shipping" | take 5"#)
        .unwrap();
    let via_fluent = Queryable::from("docs")
        .search_vec("wal shipping")
        .take(5)
        .to_vec(&mut db)
        .unwrap();
    assert_eq!(via_fluent.len(), via_dsl.rows.len());
    assert!(!via_fluent.is_empty());
}

#[tokio::test]
async fn async_offload_to_vec() {
    let db = AsyncDb::new(Db::fixture());
    let q = Queryable::from("docs")
        .filter(pred::eq("wing", "rag"))
        .select(["id", "title"])
        .take(5);
    let rows = q.clone().to_vec_async(&db).await.unwrap();
    assert!(!rows.is_empty());
    assert!(rows.len() <= 5);

    let typed: Vec<DocTitle> = Queryable::from("docs")
        .filter(pred::eq("wing", "rag"))
        .select_row::<DocTitle>()
        .take(5)
        .to_vec_typed_async(&db)
        .await
        .unwrap();
    assert_eq!(typed.len(), rows.len());
}

#[tokio::test]
async fn async_stream_matches_to_vec() {
    let db = AsyncDb::new(Db::fixture());
    let q = Queryable::from("docs")
        .filter(pred::eq("wing", "rag"))
        .select(["id", "title"])
        .take(5);
    let via_vec = q.clone().to_vec_async(&db).await.unwrap();
    let mut stream = q.to_stream_async(&db).await;
    let mut via_stream = Vec::new();
    while let Some(item) = stream.next().await {
        via_stream.push(item.unwrap());
    }
    assert_eq!(via_stream.len(), via_vec.len());
    assert_eq!(via_stream, via_vec);

    let mut typed_stream = Queryable::from("docs")
        .filter(pred::eq("wing", "rag"))
        .select_row::<DocTitle>()
        .take(5)
        .to_stream_typed_async::<DocTitle>(&db)
        .await;
    let mut typed = Vec::new();
    while let Some(item) = typed_stream.next().await {
        typed.push(item.unwrap());
    }
    assert_eq!(typed.len(), via_vec.len());
}

#[test]
fn fluent_prepare_and_ignore_filters() {
    let mut db = Db::empty();
    db.run(
        r#"insert docs [
      { uri: "raw://a", title: "A", layer: "wiki", wing: "rag" },
      { uri: "raw://b", title: "B", layer: "raw", wing: "sys" }
    ]"#,
    )
    .unwrap();
    db.run(r#"filter docs wing == "rag""#).unwrap();
    let prep = Queryable::from("docs").take_all().prepare(&mut db).unwrap();
    assert_eq!(prep.run(&mut db).unwrap().done.n, 1);
    let all = Queryable::from("docs")
        .ignore_filters()
        .take_all()
        .to_vec(&mut db)
        .unwrap();
    assert_eq!(all.len(), 2);
}

#[test]
fn prepare_query_cache_hits() {
    let mut db = Db::empty();
    let q = Queryable::from("docs").take(3);
    let a = q.prepare(&mut db).unwrap();
    let b = q.prepare(&mut db).unwrap();
    assert!(std::sync::Arc::ptr_eq(&a.plan, &b.plan));
}

#[test]
fn owned_linrow_and_to_cell() {
    use lin::ToCell;
    let mut db = Db::fixture();
    let rows: Vec<DocStamp> = Queryable::from("docs")
        .select(["id", "title", "hash", "ts"])
        .take(3)
        .to_vec_typed(&mut db)
        .unwrap();
    assert!(!rows[0].id.is_empty());
    assert!(!rows[0].title.is_empty() || !rows[0].stamp.hash.is_empty() || rows[0].stamp.ts >= 0);
    let _ = "x".to_cell();
}
