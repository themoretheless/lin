#![cfg(feature = "gpu")]
#[path = "../examples/gpu_check.rs"]
mod verification;

#[test]
#[ignore = "requires a hardware GPU; run with --features gpu --test gpu -- --ignored"]
fn hardware_cosine_and_search_match_cpu() {
    verification::main().unwrap();
}

#[test]
#[ignore = "requires a hardware GPU"]
fn arbitrary_wgsl_resident_dispatch_and_errors() {
    use lin::gpu::{GpuCompute, native as wgpu};
    let gpu = GpuCompute::new().unwrap();
    let source = r#"
        @group(0) @binding(0) var<storage, read_write> values: array<u32>;
        @compute @workgroup_size(4, 2, 1)
        fn increment(@builtin(global_invocation_id) id: vec3<u32>) {
            let i = id.x + id.y * 8u + id.z * 32u;
            if i < arrayLength(&values) { values[i] += 3u; }
        }
        @compute @workgroup_size(64)
        fn double(@builtin(global_invocation_id) id: vec3<u32>) {
            if id.x < arrayLength(&values) { values[id.x] *= 2u; }
        }
    "#;
    let first = gpu.compile_wgsl(source, "increment").unwrap();
    let second = gpu.compile_wgsl(source, "double").unwrap();
    let buffer = gpu
        .storage_buffer(bytemuck::cast_slice(&vec![1u32; 64]))
        .unwrap();
    let group = |kernel: &lin::gpu::ComputeKernel| {
        gpu.checked(|device, _| {
            device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: None,
                layout: &kernel.bind_group_layout(0),
                entries: &[wgpu::BindGroupEntry {
                    binding: 0,
                    resource: buffer.as_entire_binding(),
                }],
            })
        })
        .unwrap()
    };
    let g1 = group(&first);
    let g2 = group(&second);
    gpu.dispatch(&first, &[&g1], [2, 2, 2]).unwrap();
    gpu.dispatch(&second, &[&g2], [1, 1, 1]).unwrap();
    let bytes = gpu.read_buffer(&buffer).unwrap();
    assert_eq!(bytemuck::cast_slice::<u8, u32>(&bytes), &[8u32; 64]);
    gpu.checked(|_, queue| queue.write_buffer(&buffer, 0, bytemuck::cast_slice(&[7u32])))
        .unwrap();
    gpu.dispatch(&second, &[&g2], [1, 1, 1]).unwrap();
    let bytes = gpu.read_buffer(&buffer).unwrap();
    assert_eq!(bytemuck::cast_slice::<u8, u32>(&bytes)[0], 14);
    assert!(gpu.compile_wgsl("invalid WGSL", "main").is_err());
    assert!(gpu.compile_wgsl(source, "missing").is_err());
    assert!(gpu.dispatch(&first, &[], [1, 1, 1]).is_err());
    assert!(gpu.dispatch(&first, &[&g1], [u32::MAX, 1, 1]).is_err());
    assert!(gpu.storage_buffer(&[]).is_err());
    assert!(gpu.storage_buffer(&[1, 2, 3]).is_err());
    // An error must not poison subsequent submissions/scopes.
    gpu.dispatch(&second, &[&g2], [1, 1, 1]).unwrap();
    assert_eq!(
        bytemuck::cast_slice::<u8, u32>(&gpu.read_buffer(&buffer).unwrap())[0],
        28
    );
}

#[test]
#[ignore = "requires a hardware GPU"]
fn storage_texture_uniform_and_multiple_groups() {
    use lin::gpu::{GpuCompute, native as wgpu};
    use wgpu::util::DeviceExt;
    let gpu = GpuCompute::new().unwrap();
    let kernel = gpu
        .compile_wgsl(
            r#"
        @group(0) @binding(0) var image: texture_storage_2d<rgba8unorm, write>;
        @group(1) @binding(0) var<uniform> color: vec4<f32>;
        @compute @workgroup_size(1)
        fn paint(@builtin(global_invocation_id) id: vec3<u32>) {
            textureStore(image, vec2<i32>(id.xy), color);
        }
    "#,
            "paint",
        )
        .unwrap();
    let (texture, uniform) = gpu
        .checked(|device, _| {
            let texture = device.create_texture(&wgpu::TextureDescriptor {
                label: None,
                size: wgpu::Extent3d {
                    width: 2,
                    height: 2,
                    depth_or_array_layers: 1,
                },
                mip_level_count: 1,
                sample_count: 1,
                dimension: wgpu::TextureDimension::D2,
                format: wgpu::TextureFormat::Rgba8Unorm,
                usage: wgpu::TextureUsages::STORAGE_BINDING | wgpu::TextureUsages::COPY_SRC,
                view_formats: &[],
            });
            let uniform = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: None,
                contents: bytemuck::cast_slice(&[1f32, 0.0, 0.0, 1.0]),
                usage: wgpu::BufferUsages::UNIFORM,
            });
            (texture, uniform)
        })
        .unwrap();
    let view = texture.create_view(&Default::default());
    let g0 = gpu
        .checked(|device, _| {
            device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: None,
                layout: &kernel.bind_group_layout(0),
                entries: &[wgpu::BindGroupEntry {
                    binding: 0,
                    resource: wgpu::BindingResource::TextureView(&view),
                }],
            })
        })
        .unwrap();
    let g1 = gpu
        .checked(|device, _| {
            device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: None,
                layout: &kernel.bind_group_layout(1),
                entries: &[wgpu::BindGroupEntry {
                    binding: 0,
                    resource: uniform.as_entire_binding(),
                }],
            })
        })
        .unwrap();
    gpu.dispatch(&kernel, &[&g0, &g1], [2, 2, 1]).unwrap();
    let output = gpu
        .checked(|device, queue| {
            let output = device.create_buffer(&wgpu::BufferDescriptor {
                label: None,
                size: 512,
                mapped_at_creation: false,
                usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::COPY_SRC,
            });
            let mut encoder = device.create_command_encoder(&Default::default());
            encoder.copy_texture_to_buffer(
                wgpu::TexelCopyTextureInfo {
                    texture: &texture,
                    mip_level: 0,
                    origin: wgpu::Origin3d::ZERO,
                    aspect: wgpu::TextureAspect::All,
                },
                wgpu::TexelCopyBufferInfo {
                    buffer: &output,
                    layout: wgpu::TexelCopyBufferLayout {
                        offset: 0,
                        bytes_per_row: Some(256),
                        rows_per_image: Some(2),
                    },
                },
                wgpu::Extent3d {
                    width: 2,
                    height: 2,
                    depth_or_array_layers: 1,
                },
            );
            queue.submit([encoder.finish()]);
            output
        })
        .unwrap();
    let bytes = gpu.read_buffer(&output).unwrap();
    for offset in [0, 4, 256, 260] {
        assert_eq!(&bytes[offset..offset + 4], &[255, 0, 0, 255]);
    }
}

#[test]
#[ignore = "requires a hardware GPU"]
fn executor_resident_cache_tracks_mutations_rollback_and_snapshot() {
    use lin::{Cell, Db};
    use std::sync::Arc;
    let gpu = Arc::new(lin::gpu::GpuCompute::new().unwrap());
    let mut db = Db::fixture().with_gpu(gpu);
    let q = r#"docs | search vec "wal" | take all"#;
    let check = |db: &mut Db| {
        let mut cpu = Db::empty();
        cpu.catalog = db.catalog.clone();
        cpu.store = db.store.clone_mem();
        assert_eq!(cpu.run(q).unwrap().rows, db.run(q).unwrap().rows);
        let hybrid = r#"docs | search "wal" | take all"#;
        assert_eq!(cpu.run(hybrid).unwrap().rows, db.run(hybrid).unwrap().rows);
    };
    check(&mut db);
    assert_eq!(db.gpu_cache_stats().unwrap().uploads, 1);
    assert_eq!(db.gpu_cache_stats().unwrap().hits, 1);
    let snapshot = db.reader();
    let snapshot_rows = snapshot.run(q).unwrap().rows;
    std::thread::scope(|scope| {
        let handles: Vec<_> = (0..4)
            .map(|_| {
                let read = snapshot.clone();
                scope.spawn(move || read.run(q).unwrap().rows)
            })
            .collect();
        for handle in handles {
            assert_eq!(handle.join().unwrap(), snapshot_rows);
        }
    });
    assert_eq!(snapshot.gpu_cache_stats().unwrap().uploads, 1);
    assert_eq!(snapshot.gpu_cache_stats().unwrap().hits, 4);

    db.run(r#"insert docs { uri: "raw://gpu-cache", title: "wal", layer: "wiki" }"#)
        .unwrap();
    check(&mut db);
    assert_eq!(db.gpu_cache_stats().unwrap().uploads, 2);
    db.run(r#"update docs[uri == "raw://gpu-cache"] cas each { title: "cats" }"#)
        .unwrap();
    check(&mut db);
    assert_eq!(snapshot.run(q).unwrap().rows, snapshot_rows);
    db.run(r#"delete docs[uri == "raw://gpu-cache"] cas each"#)
        .unwrap();
    check(&mut db);
    // Warm a cache with uncommitted inserted data; failure must restore old results.
    assert!(
        db.run(
            r#"insert docs { uri: "raw://gpu-rollback", title: "wal", layer: "wiki" }
        docs | search vec "wal"
        update docs[id == "missing"] cas "x" { room: "inbox" }"#
        )
        .is_err()
    );
    check(&mut db);
    assert_eq!(snapshot.run(q).unwrap().rows, snapshot_rows);
    // Public Store mutation and Arc::make_mut must invalidate even without a gen change.
    let old_uploads = db.gpu_cache_stats().unwrap().uploads;
    if let Some(Cell::Vec(v)) =
        db.store.collections.get_mut("docs").unwrap()[0].get_mut("embedding")
    {
        Arc::make_mut(v).fill(0.0);
    }
    check(&mut db);
    assert_eq!(db.gpu_cache_stats().unwrap().uploads, old_uploads + 1);
    db.reembed_collection("docs").unwrap();
    check(&mut db);
    assert_eq!(db.gpu_cache_stats().unwrap().uploads, old_uploads + 2);
    let backend = db.gpu().unwrap().clone();
    db.disable_gpu();
    assert!(db.gpu().is_none());
    assert_eq!(db.gpu_cache_stats().unwrap(), Default::default());
    check(&mut db);
    db.enable_gpu(backend);
    check(&mut db);
    assert_eq!(db.gpu_cache_stats().unwrap().uploads, 1);
}

#[test]
#[ignore = "requires a hardware GPU"]
fn numeric_filters_preserve_f64_i64_special_values_and_batch() {
    use lin::{Cell, CmpOp, Db, Field, Pred, Queryable, Value};
    use std::sync::Arc;
    let gpu = Arc::new(lin::gpu::GpuCompute::new().unwrap());
    let mut cpu = Db::empty();
    cpu.run("col metrics { value: f64 }").unwrap();
    let values = [
        Cell::Float(f64::NAN),
        Cell::Float(f64::INFINITY),
        Cell::Float(f64::NEG_INFINITY),
        Cell::Float(-0.0),
        Cell::Float(0.0),
        Cell::Float(f64::from_bits(1)),
        Cell::Float(-f64::from_bits(1)),
        Cell::Float(1.0000000000000002),
        Cell::Int(9_007_199_254_740_993),
        Cell::Int(9_007_199_254_740_992),
        Cell::Int(i64::MIN),
        Cell::Int(i64::MAX),
        Cell::Null,
    ];
    for _ in &values {
        cpu.run("insert metrics { value: 1.0 }").unwrap();
    }
    for (row, value) in cpu
        .store
        .collections
        .get_mut("metrics")
        .unwrap()
        .iter_mut()
        .zip(values)
    {
        row.insert("value".into(), value);
    }
    let mut accelerated = Db::empty().with_gpu(gpu.clone());
    accelerated.catalog = cpu.catalog.clone();
    accelerated.store = cpu.store.clone_mem();
    for op in [
        CmpOp::Eq,
        CmpOp::Ne,
        CmpOp::Gt,
        CmpOp::Lt,
        CmpOp::Ge,
        CmpOp::Le,
    ] {
        for value in [
            Value::Int(9_007_199_254_740_993),
            Value::Int(i64::MIN),
            Value::Int(i64::MAX),
            Value::Float(-0.0),
            Value::Float(f64::from_bits(1)),
            Value::Float(1.0000000000000002),
            Value::Float(f64::NAN),
            Value::Float(f64::INFINITY),
        ] {
            let pred = Pred::Cmp {
                field: Field::name("value"),
                op,
                value,
            };
            let query = Queryable::from("metrics")
                .filter(pred.clone())
                .select(["id"])
                .take_all();
            assert_eq!(
                query.to_vec(&mut cpu).unwrap(),
                query.to_vec(&mut accelerated).unwrap(),
                "{pred:?}"
            );
            let query = Queryable::from("metrics").filter(pred).count();
            assert_eq!(
                query.to_vec(&mut cpu).unwrap(),
                query.to_vec(&mut accelerated).unwrap()
            );
        }
    }
    for q in [
        "metrics | value > 0 and value < 2 | { id } | take all",
        "metrics | value < 0 or value > 2 | { id } | take all",
        "metrics | value >= 0 | { id } | skip 1 | take 2",
        "metrics | value >= 0 | { id } | take all",
    ] {
        assert_eq!(cpu.run(q).unwrap().rows, accelerated.run(q).unwrap().rows);
        assert_eq!(cpu.run_batch(q).unwrap(), accelerated.run_batch(q).unwrap());
        assert_eq!(
            cpu.run_batch(q).unwrap(),
            accelerated.reader().run_batch(q).unwrap()
        );
    }
    assert!(
        gpu.comparison_dispatches() >= 100,
        "executor must submit actual GPU comparisons"
    );
}

#[test]
#[ignore = "requires a hardware GPU"]
fn insufficient_comparison_buffer_limit_returns_error() {
    use lin::gpu::{GpuCompute, GpuOptions};
    use std::sync::Arc;
    let mut options = GpuOptions::default();
    options.limits.max_storage_buffer_binding_size = 16;
    let gpu = Arc::new(GpuCompute::with_options(options).unwrap());
    let mut db = lin::Db::fixture().with_gpu(gpu);
    let error = db.run("orders | total > 1 | count").unwrap_err();
    assert!(error.to_string().contains("comparison record"), "{error}");
    let mut options = GpuOptions::default();
    options.limits.max_compute_workgroups_per_dimension = u32::MAX;
    assert!(GpuCompute::with_options(options).is_err());
}

#[test]
#[ignore = "requires a hardware GPU"]
fn text_filters_match_cpu_unicode_empty_null_and_mixed_predicates() {
    use lin::{Cell, CmpOp, Db, Field, Pred, Queryable, Value};
    use std::sync::Arc;
    let gpu = Arc::new(lin::gpu::GpuCompute::new().unwrap());
    let mut cpu = Db::empty();
    cpu.run("col samples { text: text, n: i64, active: bool }")
        .unwrap();
    let values = [
        Some(""),
        Some("foo bar"),
        Some("foobar"),
        Some("foo_bar"),
        Some("Привет МИР"),
        Some("İstanbul Σσς"),
        Some("café cafe\u{301}"),
        Some("ＡＢＣ 😀 foo"),
        Some("nul\0byte"),
        Some("foo-bar foo"),
        None,
    ];
    for (i, _) in values.iter().enumerate() {
        cpu.run(&format!(
            "insert samples {{ text: \"placeholder\", n: {i}, active: true }}"
        ))
        .unwrap();
    }
    for (row, value) in cpu
        .store
        .collections
        .get_mut("samples")
        .unwrap()
        .iter_mut()
        .zip(values)
    {
        row.insert(
            "text".into(),
            value.map(Cell::text_arc).unwrap_or(Cell::Null),
        );
    }
    let mut db = Db::empty().with_gpu(gpu);
    db.catalog = cpu.catalog.clone();
    db.store = cpu.store.clone_mem();
    for needle in [
        "",
        "foo",
        "bar",
        "foo bar",
        "foo_bar",
        "ПРИВЕТ",
        "привет",
        "мир",
        "i\u{307}stanbul",
        "Σ",
        "σ",
        "ς",
        "café",
        "cafe",
        "😀",
        "\0",
    ] {
        for pred in [
            Pred::Contains {
                field: Field::name("text"),
                needle: needle.into(),
            },
            Pred::Has {
                field: Field::name("text"),
                ci: false,
                needle: needle.into(),
            },
            Pred::Has {
                field: Field::name("text"),
                ci: true,
                needle: needle.into(),
            },
            Pred::Cmp {
                field: Field::name("text"),
                op: CmpOp::Eq,
                value: Value::String(needle.into()),
            },
            Pred::Cmp {
                field: Field::name("text"),
                op: CmpOp::Ne,
                value: Value::String(needle.into()),
            },
        ] {
            let q = Queryable::from("samples")
                .filter(pred.clone())
                .select(["id"])
                .take_all();
            assert_eq!(
                q.to_vec(&mut cpu).unwrap(),
                q.to_vec(&mut db).unwrap(),
                "{pred:?}"
            );
        }
    }
    for program in [
        r#"samples | text ~ "foo" and n > 1 | { id } | take all"#,
        r#"samples | text has "foo" or n == 0 | { id } | take all"#,
        r#"samples | text ~ /foo.*/ and n >= 2 | { id } | take all"#,
        r#"samples | active == true and text != "" | { id } | take all"#,
        r#"samples | active != false | count"#,
        r#"samples | text ~ "" | { id } | skip 2 | take 5"#,
    ] {
        assert_eq!(
            cpu.run(program).unwrap().rows,
            db.run(program).unwrap().rows,
            "{program}"
        );
        assert_eq!(
            cpu.run_batch(program).unwrap(),
            db.run_batch(program).unwrap(),
            "batch {program}"
        );
        assert_eq!(
            cpu.run_batch(program).unwrap(),
            db.reader().run_batch(program).unwrap(),
            "reader {program}"
        );
    }
}
