# Large builtin hashing batch parallelism component comparison

Linux x86_64, same frozen compare harness; previous COW+CAS baseline versus builtin hashing batch parallel candidate. No RSS claim. Full engine and eight-peer goal remain unqualified.

|Case|Series|Gain %|Absolute A/A %|Positive|Pass|
|---|---|---:|---:|---:|---|
|compare/insert_bulk_10k/lin|series1|0.821|1.009|4/6|False|
|compare/insert_bulk_10k/lin|series2|0.084|2.037|3/6|False|
|compare/insert_bulk_1k/lin|series1|-1.548|1.007|0/6|True|
|compare/insert_bulk_1k/lin|series2|-1.020|0.600|1/6|True|
|compare/point_get/lin|series1|3.068|9.543|5/6|True|
|compare/point_get/lin|series2|2.992|3.975|5/6|True|
|compare/filter_eq/lin|series1|1.739|2.957|6/6|True|
|compare/filter_eq/lin|series2|2.133|1.456|5/6|True|
|compare/update_1row_1k/lin|series1|-0.070|2.572|3/6|True|
|compare/update_1row_1k/lin|series2|0.788|2.070|4/6|True|
|compare/wal_scalar_full_update/lin|series1|1.577|3.146|4/6|True|
|compare/wal_scalar_full_update/lin|series2|2.782|3.779|5/6|True|
|compare/wal_scalar_normal_update/lin|series1|0.477|1.863|4/6|True|
|compare/wal_scalar_normal_update/lin|series2|-0.862|1.289|2/6|True|
|compare/insert_bulk_10k/sqlite|series1|-1.524|0.514|0/6|True|
|compare/insert_bulk_10k/sqlite|series2|-0.482|0.954|2/6|True|
|compare/filter_eq/duckdb|series1|-3.678|3.129|2/6|False|
|compare/filter_eq/duckdb|series2|5.099|5.560|5/6|True|

Component gate: False. All 324 processes / 2592 wall observations retained.
