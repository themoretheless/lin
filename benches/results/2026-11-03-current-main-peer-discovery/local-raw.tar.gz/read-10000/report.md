# Validated read API benchmark

Rows: 10000; process repetitions: 3; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.133 | 1.00× | validated |
| point_get | sqlite | 0.930 | 6.97× | validated |
| point_get | duckdb | 130.187 | 976.78× | validated |
| point_get | pandas | 4.388 | 32.92× | validated |
| filter_eq | lin | 0.698 | 1.00× | validated |
| filter_eq | sqlite | 67.302 | 96.42× | validated |
| filter_eq | duckdb | 263.615 | 377.68× | validated |
| filter_eq | pandas | 279.691 | 400.71× | validated |
| text_substr | lin | 16.501 | 1.00× | validated |
| text_substr | sqlite | 330.589 | 20.04× | validated |
| text_substr | duckdb | 241.198 | 14.62× | validated |
| text_substr | pandas | 520.913 | 31.57× | validated |
| materialize | lin | 457.977 | 1.00× | validated |
| materialize | sqlite | 1895.917 | 4.14× | validated |
| materialize | duckdb | 1576.507 | 3.44× | validated |
| materialize | pandas | 2173.083 | 4.74× | validated |
| join_inner | lin | 1073.922 | 1.00× | validated |
| join_inner | sqlite | 4542.875 | 4.23× | validated |
| join_inner | duckdb | 3261.396 | 3.04× | validated |
| join_inner | pandas | 4308.750 | 4.01× | validated |
| join_filter | lin | 628.476 | 1.00× | validated |
| join_filter | sqlite | 2364.292 | 3.76× | validated |
| join_filter | duckdb | 1879.333 | 2.99× | validated |
| join_filter | pandas | 2632.688 | 4.19× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "pandas": "3.0.6", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
