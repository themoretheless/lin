# Validated read API benchmark

Rows: 10000; process repetitions: 1; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | duckdb | 130.187 | 1021.63× | validated |
| point_get | pandas | 4.388 | 34.43× | validated |
| point_get | lin | 0.127 | 1.00× | validated |
| point_get | sqlite | 0.930 | 7.29× | validated |
| filter_eq | duckdb | 262.885 | 373.56× | validated |
| filter_eq | pandas | 279.691 | 397.44× | validated |
| filter_eq | lin | 0.704 | 1.00× | validated |
| filter_eq | sqlite | 67.302 | 95.64× | validated |
| text_substr | duckdb | 238.316 | 13.72× | validated |
| text_substr | pandas | 520.913 | 30.00× | validated |
| text_substr | lin | 17.364 | 1.00× | validated |
| text_substr | sqlite | 333.002 | 19.18× | validated |
| materialize | duckdb | 1566.021 | 3.58× | validated |
| materialize | pandas | 2173.083 | 4.96× | validated |
| materialize | lin | 437.830 | 1.00× | validated |
| materialize | sqlite | 1895.917 | 4.33× | validated |
| join_inner | duckdb | 3246.459 | 3.16× | validated |
| join_inner | pandas | 4308.750 | 4.19× | validated |
| join_inner | lin | 1027.276 | 1.00× | validated |
| join_inner | sqlite | 4646.770 | 4.52× | validated |
| join_filter | duckdb | 1879.333 | 2.99× | validated |
| join_filter | pandas | 2645.459 | 4.21× | validated |
| join_filter | lin | 628.476 | 1.00× | validated |
| join_filter | sqlite | 2403.740 | 3.82× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "pandas": "3.0.6", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
