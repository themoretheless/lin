# Validated read API benchmark

Rows: 10000; process repetitions: 1; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | sqlite | 0.907 | 6.81× | validated |
| point_get | duckdb | 123.950 | 929.99× | validated |
| point_get | pandas | 4.558 | 34.20× | validated |
| point_get | lin | 0.133 | 1.00× | validated |
| filter_eq | sqlite | 67.074 | 96.68× | validated |
| filter_eq | duckdb | 283.968 | 409.32× | validated |
| filter_eq | pandas | 269.411 | 388.34× | validated |
| filter_eq | lin | 0.694 | 1.00× | validated |
| text_substr | sqlite | 330.589 | 20.11× | validated |
| text_substr | duckdb | 263.376 | 16.02× | validated |
| text_substr | pandas | 480.554 | 29.23× | validated |
| text_substr | lin | 16.442 | 1.00× | validated |
| materialize | sqlite | 1871.782 | 3.99× | validated |
| materialize | duckdb | 1697.917 | 3.62× | validated |
| materialize | pandas | 2021.479 | 4.31× | validated |
| materialize | lin | 469.512 | 1.00× | validated |
| join_inner | sqlite | 4526.542 | 4.17× | validated |
| join_inner | duckdb | 3283.292 | 3.03× | validated |
| join_inner | pandas | 4399.605 | 4.06× | validated |
| join_inner | lin | 1084.203 | 1.00× | validated |
| join_filter | sqlite | 2346.083 | 3.99× | validated |
| join_filter | duckdb | 2002.844 | 3.41× | validated |
| join_filter | pandas | 2632.688 | 4.48× | validated |
| join_filter | lin | 587.670 | 1.00× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "pandas": "3.0.6", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
