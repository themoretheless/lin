# Validated read API benchmark

Rows: 10000; process repetitions: 1; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.136 | 1.00× | validated |
| point_get | sqlite | 0.961 | 7.08× | validated |
| point_get | duckdb | 132.830 | 979.15× | validated |
| point_get | pandas | 4.368 | 32.20× | validated |
| filter_eq | lin | 0.698 | 1.00× | validated |
| filter_eq | sqlite | 70.502 | 101.01× | validated |
| filter_eq | duckdb | 263.615 | 377.68× | validated |
| filter_eq | pandas | 281.239 | 402.93× | validated |
| text_substr | lin | 16.501 | 1.00× | validated |
| text_substr | sqlite | 328.376 | 19.90× | validated |
| text_substr | duckdb | 241.198 | 14.62× | validated |
| text_substr | pandas | 619.456 | 37.54× | validated |
| materialize | lin | 457.977 | 1.00× | validated |
| materialize | sqlite | 1930.552 | 4.22× | validated |
| materialize | duckdb | 1576.507 | 3.44× | validated |
| materialize | pandas | 2416.229 | 5.28× | validated |
| join_inner | lin | 1073.922 | 1.00× | validated |
| join_inner | sqlite | 4542.875 | 4.23× | validated |
| join_inner | duckdb | 3261.396 | 3.04× | validated |
| join_inner | pandas | 3910.251 | 3.64× | validated |
| join_filter | lin | 650.057 | 1.00× | validated |
| join_filter | sqlite | 2364.292 | 3.64× | validated |
| join_filter | duckdb | 1844.417 | 2.84× | validated |
| join_filter | pandas | 2492.021 | 3.83× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "pandas": "3.0.6", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
