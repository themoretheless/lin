# Validated read API benchmark

Rows: 100000; process repetitions: 1; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | sqlite | 0.983 | 7.59× | validated |
| point_get | duckdb | 148.759 | 1149.13× | validated |
| point_get | pandas | 4.482 | 34.63× | validated |
| point_get | lin | 0.129 | 1.00× | validated |
| filter_eq | sqlite | 698.848 | 802.31× | validated |
| filter_eq | duckdb | 360.809 | 414.23× | validated |
| filter_eq | pandas | 2406.198 | 2762.44× | validated |
| filter_eq | lin | 0.871 | 1.00× | validated |
| text_substr | sqlite | 3540.959 | 16.88× | validated |
| text_substr | duckdb | 1570.906 | 7.49× | validated |
| text_substr | pandas | 5261.770 | 25.08× | validated |
| text_substr | lin | 209.764 | 1.00× | validated |
| materialize | sqlite | 20703.375 | 3.88× | validated |
| materialize | duckdb | 15560.750 | 2.92× | validated |
| materialize | pandas | 19831.417 | 3.72× | validated |
| materialize | lin | 5330.667 | 1.00× | validated |
| join_inner | sqlite | 52970.688 | 4.41× | validated |
| join_inner | duckdb | 33573.209 | 2.79× | validated |
| join_inner | pandas | 38993.542 | 3.24× | validated |
| join_inner | lin | 12022.729 | 1.00× | validated |
| join_filter | sqlite | 26438.459 | 4.45× | validated |
| join_filter | duckdb | 17510.959 | 2.95× | validated |
| join_filter | pandas | 20479.895 | 3.45× | validated |
| join_filter | lin | 5937.167 | 1.00× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "pandas": "3.0.6", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
