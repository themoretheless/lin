# Validated read API benchmark

Rows: 100000; process repetitions: 3; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.127 | 1.00× | validated |
| point_get | sqlite | 0.983 | 7.74× | validated |
| point_get | duckdb | 148.759 | 1172.24× | validated |
| point_get | pandas | 4.517 | 35.60× | validated |
| filter_eq | lin | 0.871 | 1.00× | validated |
| filter_eq | sqlite | 698.848 | 802.31× | validated |
| filter_eq | duckdb | 360.809 | 414.23× | validated |
| filter_eq | pandas | 2479.782 | 2846.92× | validated |
| text_substr | lin | 209.764 | 1.00× | validated |
| text_substr | sqlite | 3544.500 | 16.90× | validated |
| text_substr | duckdb | 1570.906 | 7.49× | validated |
| text_substr | pandas | 5261.770 | 25.08× | validated |
| materialize | lin | 5697.458 | 1.00× | validated |
| materialize | sqlite | 21062.916 | 3.70× | validated |
| materialize | duckdb | 15560.750 | 2.73× | validated |
| materialize | pandas | 19947.312 | 3.50× | validated |
| join_inner | lin | 12043.834 | 1.00× | validated |
| join_inner | sqlite | 52970.688 | 4.40× | validated |
| join_inner | duckdb | 33724.958 | 2.80× | validated |
| join_inner | pandas | 38993.542 | 3.24× | validated |
| join_filter | lin | 6006.854 | 1.00× | validated |
| join_filter | sqlite | 27010.167 | 4.50× | validated |
| join_filter | duckdb | 17510.959 | 2.92× | validated |
| join_filter | pandas | 20297.980 | 3.38× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "pandas": "3.0.6", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
