# Validated read API benchmark

Rows: 100000; process repetitions: 1; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | duckdb | 213.132 | 1682.82× | validated |
| point_get | pandas | 4.526 | 35.74× | validated |
| point_get | lin | 0.127 | 1.00× | validated |
| point_get | sqlite | 0.979 | 7.73× | validated |
| filter_eq | duckdb | 409.560 | 459.84× | validated |
| filter_eq | pandas | 2479.782 | 2784.24× | validated |
| filter_eq | lin | 0.891 | 1.00× | validated |
| filter_eq | sqlite | 706.506 | 793.25× | validated |
| text_substr | duckdb | 1606.187 | 7.63× | validated |
| text_substr | pandas | 5940.605 | 28.22× | validated |
| text_substr | lin | 210.528 | 1.00× | validated |
| text_substr | sqlite | 3544.500 | 16.84× | validated |
| materialize | duckdb | 15985.188 | 2.44× | validated |
| materialize | pandas | 20201.688 | 3.09× | validated |
| materialize | lin | 6538.500 | 1.00× | validated |
| materialize | sqlite | 21655.667 | 3.31× | validated |
| join_inner | duckdb | 33724.958 | 2.44× | validated |
| join_inner | pandas | 50674.874 | 3.67× | validated |
| join_inner | lin | 13797.833 | 1.00× | validated |
| join_inner | sqlite | 52359.688 | 3.79× | validated |
| join_filter | duckdb | 24855.959 | 2.56× | validated |
| join_filter | pandas | 19625.896 | 2.02× | validated |
| join_filter | lin | 9696.791 | 1.00× | validated |
| join_filter | sqlite | 27037.855 | 2.79× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "pandas": "3.0.6", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
