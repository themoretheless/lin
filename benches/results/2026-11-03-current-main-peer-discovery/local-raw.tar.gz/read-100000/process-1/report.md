# Validated read API benchmark

Rows: 100000; process repetitions: 1; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.127 | 1.00× | validated |
| point_get | sqlite | 1.005 | 7.92× | validated |
| point_get | duckdb | 141.442 | 1114.58× | validated |
| point_get | pandas | 4.517 | 35.60× | validated |
| filter_eq | lin | 0.855 | 1.00× | validated |
| filter_eq | sqlite | 693.068 | 810.41× | validated |
| filter_eq | duckdb | 358.933 | 419.70× | validated |
| filter_eq | pandas | 2524.062 | 2951.41× | validated |
| text_substr | lin | 208.914 | 1.00× | validated |
| text_substr | sqlite | 3583.292 | 17.15× | validated |
| text_substr | duckdb | 1547.576 | 7.41× | validated |
| text_substr | pandas | 5108.126 | 24.45× | validated |
| materialize | lin | 5697.458 | 1.00× | validated |
| materialize | sqlite | 21062.916 | 3.70× | validated |
| materialize | duckdb | 15544.271 | 2.73× | validated |
| materialize | pandas | 19947.312 | 3.50× | validated |
| join_inner | lin | 12043.834 | 1.00× | validated |
| join_inner | sqlite | 53715.521 | 4.46× | validated |
| join_inner | duckdb | 34228.688 | 2.84× | validated |
| join_inner | pandas | 38277.500 | 3.18× | validated |
| join_filter | lin | 6006.854 | 1.00× | validated |
| join_filter | sqlite | 27010.167 | 4.50× | validated |
| join_filter | duckdb | 16574.229 | 2.76× | validated |
| join_filter | pandas | 20297.980 | 3.38× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "pandas": "3.0.6", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
