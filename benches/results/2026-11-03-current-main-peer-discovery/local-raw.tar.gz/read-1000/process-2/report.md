# Validated read API benchmark

Rows: 1000; process repetitions: 1; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | sqlite | 0.927 | 6.83× | validated |
| point_get | duckdb | 121.153 | 892.40× | validated |
| point_get | pandas | 4.456 | 32.82× | validated |
| point_get | lin | 0.136 | 1.00× | validated |
| filter_eq | sqlite | 7.451 | 11.38× | validated |
| filter_eq | duckdb | 224.361 | 342.72× | validated |
| filter_eq | pandas | 58.625 | 89.55× | validated |
| filter_eq | lin | 0.655 | 1.00× | validated |
| text_substr | sqlite | 32.186 | 17.59× | validated |
| text_substr | duckdb | 149.100 | 81.49× | validated |
| text_substr | pandas | 79.589 | 43.50× | validated |
| text_substr | lin | 1.830 | 1.00× | validated |
| materialize | sqlite | 167.606 | 3.66× | validated |
| materialize | duckdb | 712.385 | 15.56× | validated |
| materialize | pandas | 403.540 | 8.81× | validated |
| materialize | lin | 45.791 | 1.00× | validated |
| join_inner | sqlite | 396.425 | 3.06× | validated |
| join_inner | duckdb | 511.924 | 3.95× | validated |
| join_inner | pandas | 768.243 | 5.92× | validated |
| join_inner | lin | 129.719 | 1.00× | validated |
| join_filter | sqlite | 204.099 | 3.16× | validated |
| join_filter | duckdb | 395.269 | 6.12× | validated |
| join_filter | pandas | 673.030 | 10.41× | validated |
| join_filter | lin | 64.624 | 1.00× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "pandas": "3.0.6", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
