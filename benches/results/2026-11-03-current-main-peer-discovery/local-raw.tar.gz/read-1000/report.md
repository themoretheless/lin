# Validated read API benchmark

Rows: 1000; process repetitions: 3; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.128 | 1.00× | validated |
| point_get | sqlite | 0.917 | 7.18× | validated |
| point_get | duckdb | 121.153 | 948.03× | validated |
| point_get | pandas | 4.474 | 35.01× | validated |
| filter_eq | lin | 0.687 | 1.00× | validated |
| filter_eq | sqlite | 7.513 | 10.93× | validated |
| filter_eq | duckdb | 230.861 | 335.95× | validated |
| filter_eq | pandas | 59.813 | 87.04× | validated |
| text_substr | lin | 1.628 | 1.00× | validated |
| text_substr | sqlite | 32.188 | 19.77× | validated |
| text_substr | duckdb | 149.100 | 91.57× | validated |
| text_substr | pandas | 77.888 | 47.83× | validated |
| materialize | lin | 45.102 | 1.00× | validated |
| materialize | sqlite | 167.606 | 3.72× | validated |
| materialize | duckdb | 712.385 | 15.80× | validated |
| materialize | pandas | 393.708 | 8.73× | validated |
| join_inner | lin | 127.597 | 1.00× | validated |
| join_inner | sqlite | 396.425 | 3.11× | validated |
| join_inner | duckdb | 523.113 | 4.10× | validated |
| join_inner | pandas | 774.264 | 6.07× | validated |
| join_filter | lin | 65.649 | 1.00× | validated |
| join_filter | sqlite | 211.200 | 3.22× | validated |
| join_filter | duckdb | 418.625 | 6.38× | validated |
| join_filter | pandas | 671.143 | 10.22× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "pandas": "3.0.6", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
