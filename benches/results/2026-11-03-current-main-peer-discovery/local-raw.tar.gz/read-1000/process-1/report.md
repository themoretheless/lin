# Validated read API benchmark

Rows: 1000; process repetitions: 1; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.128 | 1.00× | validated |
| point_get | sqlite | 0.905 | 7.08× | validated |
| point_get | duckdb | 114.927 | 899.32× | validated |
| point_get | pandas | 4.474 | 35.01× | validated |
| filter_eq | lin | 0.694 | 1.00× | validated |
| filter_eq | sqlite | 7.513 | 10.83× | validated |
| filter_eq | duckdb | 238.090 | 343.15× | validated |
| filter_eq | pandas | 59.813 | 86.21× | validated |
| text_substr | lin | 1.628 | 1.00× | validated |
| text_substr | sqlite | 32.188 | 19.77× | validated |
| text_substr | duckdb | 147.682 | 90.70× | validated |
| text_substr | pandas | 77.888 | 47.83× | validated |
| materialize | lin | 45.102 | 1.00× | validated |
| materialize | sqlite | 167.561 | 3.72× | validated |
| materialize | duckdb | 708.962 | 15.72× | validated |
| materialize | pandas | 393.708 | 8.73× | validated |
| join_inner | lin | 126.872 | 1.00× | validated |
| join_inner | sqlite | 392.394 | 3.09× | validated |
| join_inner | duckdb | 523.113 | 4.12× | validated |
| join_inner | pandas | 787.170 | 6.20× | validated |
| join_filter | lin | 65.649 | 1.00× | validated |
| join_filter | sqlite | 212.213 | 3.23× | validated |
| join_filter | duckdb | 418.625 | 6.38× | validated |
| join_filter | pandas | 671.143 | 10.22× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "pandas": "3.0.6", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
