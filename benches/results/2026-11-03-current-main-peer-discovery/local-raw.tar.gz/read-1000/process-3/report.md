# Validated read API benchmark

Rows: 1000; process repetitions: 1; host: macOS-26.7.2-arm64-arm-64bit-Mach-O

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | duckdb | 121.973 | 982.41× | validated |
| point_get | pandas | 4.484 | 36.11× | validated |
| point_get | lin | 0.124 | 1.00× | validated |
| point_get | sqlite | 0.917 | 7.39× | validated |
| filter_eq | duckdb | 230.861 | 335.95× | validated |
| filter_eq | pandas | 60.766 | 88.43× | validated |
| filter_eq | lin | 0.687 | 1.00× | validated |
| filter_eq | sqlite | 7.578 | 11.03× | validated |
| text_substr | duckdb | 322.312 | 204.20× | validated |
| text_substr | pandas | 75.530 | 47.85× | validated |
| text_substr | lin | 1.578 | 1.00× | validated |
| text_substr | sqlite | 33.112 | 20.98× | validated |
| materialize | duckdb | 780.230 | 17.68× | validated |
| materialize | pandas | 380.016 | 8.61× | validated |
| materialize | lin | 44.129 | 1.00× | validated |
| materialize | sqlite | 167.936 | 3.81× | validated |
| join_inner | duckdb | 715.944 | 5.61× | validated |
| join_inner | pandas | 774.264 | 6.07× | validated |
| join_inner | lin | 127.597 | 1.00× | validated |
| join_inner | sqlite | 401.250 | 3.14× | validated |
| join_filter | duckdb | 544.373 | 8.15× | validated |
| join_filter | pandas | 668.036 | 10.00× | validated |
| join_filter | lin | 66.826 | 1.00× | validated |
| join_filter | sqlite | 211.200 | 3.16× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "pandas": "3.0.6", "sqlite": "3.54.1"}

Missing/failed peers are never counted as wins.
