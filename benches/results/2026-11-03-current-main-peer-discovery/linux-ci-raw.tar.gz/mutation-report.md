# bench 1793652463110599003-4239

Status: Complete

| Case | Metric | Median | Unit | Scope / statistic | Observations | Processes |
|---|---|---:|---|---|---:|---:|
| compare/update_1row_1k/lin [candidate] | wall | 7776.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/update_1row_1k/sqlite [candidate] | wall | 5227.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/delete_1row_1k/lin [candidate] | wall | 11662.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/delete_1row_1k/sqlite [candidate] | wall | 5553.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/update_1row_10k/lin [candidate] | wall | 16349.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/update_1row_10k/sqlite [candidate] | wall | 10791.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/delete_1row_10k/lin [candidate] | wall | 23054.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/delete_1row_10k/sqlite [candidate] | wall | 11421.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/update_1row_100k/lin [candidate] | wall | 60925.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/update_1row_100k/sqlite [candidate] | wall | 21306.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/delete_1row_100k/lin [candidate] | wall | 77510.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/delete_1row_100k/sqlite [candidate] | wall | 24621.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/tx_commit_1row_1k/lin [candidate] | wall | 7205.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/tx_commit_1row_1k/sqlite [candidate] | wall | 7396.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/tx_rollback_1row_1k/lin [candidate] | wall | 13144.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/tx_rollback_1row_1k/sqlite [candidate] | wall | 8227.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/tx_commit_1row_10k/lin [candidate] | wall | 25743.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/tx_commit_1row_10k/sqlite [candidate] | wall | 13374.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/tx_rollback_1row_10k/lin [candidate] | wall | 31657.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/tx_rollback_1row_10k/sqlite [candidate] | wall | 15087.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |

# Useful work throughput

| Case | Median batch throughput | Unit |
|---|---:|---|
| compare/update_1row_1k/lin [candidate] | 128595.2344 | stmts/s |
| compare/update_1row_1k/sqlite [candidate] | 191302.5429 | stmts/s |
| compare/delete_1row_1k/lin [candidate] | 85803.4890 | stmts/s |
| compare/delete_1row_1k/sqlite [candidate] | 180089.9925 | stmts/s |
| compare/update_1row_10k/lin [candidate] | 61166.1009 | stmts/s |
| compare/update_1row_10k/sqlite [candidate] | 92680.3434 | stmts/s |
| compare/delete_1row_10k/lin [candidate] | 43379.4480 | stmts/s |
| compare/delete_1row_10k/sqlite [candidate] | 87648.9113 | stmts/s |
| compare/update_1row_100k/lin [candidate] | 16421.3908 | stmts/s |
| compare/update_1row_100k/sqlite [candidate] | 46947.8497 | stmts/s |
| compare/delete_1row_100k/lin [candidate] | 12928.9885 | stmts/s |
| compare/delete_1row_100k/sqlite [candidate] | 40653.0561 | stmts/s |
| compare/tx_commit_1row_1k/lin [candidate] | 138786.2430 | tx/s |
| compare/tx_commit_1row_1k/sqlite [candidate] | 135209.7655 | tx/s |
| compare/tx_rollback_1row_1k/lin [candidate] | 76086.1652 | tx/s |
| compare/tx_rollback_1row_1k/sqlite [candidate] | 121552.1131 | tx/s |
| compare/tx_commit_1row_10k/lin [candidate] | 41024.1009 | tx/s |
| compare/tx_commit_1row_10k/sqlite [candidate] | 74996.5719 | tx/s |
| compare/tx_rollback_1row_10k/lin [candidate] | 31588.7037 | tx/s |
| compare/tx_rollback_1row_10k/sqlite [candidate] | 66288.3528 | tx/s |

Derived from positive wall batches and declared units per operation; zero/unavailable durations omitted.

Medians above summarize observations, not pooled operation-latency percentiles. Comparisons aggregate within each process first.

- Raw batches are not independent process replications. Batch averages are not individual-operation latency. CPU frequency and background load are uncontrolled.

- compare/update_1row_1k/lin: some samples below half the requested duration; iteration cap or workload drift may limit precision

- compare/update_1row_1k/sqlite: some samples below half the requested duration; iteration cap or workload drift may limit precision

- compare/delete_1row_1k/lin: some samples below half the requested duration; iteration cap or workload drift may limit precision

- compare/delete_1row_1k/sqlite: some samples below half the requested duration; iteration cap or workload drift may limit precision

- compare/update_1row_10k/lin: some samples below half the requested duration; iteration cap or workload drift may limit precision

- compare/update_1row_10k/sqlite: some samples below half the requested duration; iteration cap or workload drift may limit precision

- compare/delete_1row_10k/lin: some samples below half the requested duration; iteration cap or workload drift may limit precision

- compare/delete_1row_10k/sqlite: some samples below half the requested duration; iteration cap or workload drift may limit precision

- compare/update_1row_100k/lin: some samples below half the requested duration; iteration cap or workload drift may limit precision

- compare/update_1row_100k/sqlite: some samples below half the requested duration; iteration cap or workload drift may limit precision

- compare/delete_1row_100k/lin: some samples below half the requested duration; iteration cap or workload drift may limit precision

- compare/delete_1row_100k/sqlite: some samples below half the requested duration; iteration cap or workload drift may limit precision

- compare/tx_commit_1row_1k/lin: some samples below half the requested duration; iteration cap or workload drift may limit precision

- compare/tx_commit_1row_1k/sqlite: some samples below half the requested duration; iteration cap or workload drift may limit precision

- compare/tx_rollback_1row_1k/lin: some samples below half the requested duration; iteration cap or workload drift may limit precision

- compare/tx_rollback_1row_1k/sqlite: some samples below half the requested duration; iteration cap or workload drift may limit precision

- compare/tx_commit_1row_10k/lin: some samples below half the requested duration; iteration cap or workload drift may limit precision

- compare/tx_commit_1row_10k/sqlite: some samples below half the requested duration; iteration cap or workload drift may limit precision

- compare/tx_rollback_1row_10k/lin: some samples below half the requested duration; iteration cap or workload drift may limit precision

- compare/tx_rollback_1row_10k/sqlite: some samples below half the requested duration; iteration cap or workload drift may limit precision

