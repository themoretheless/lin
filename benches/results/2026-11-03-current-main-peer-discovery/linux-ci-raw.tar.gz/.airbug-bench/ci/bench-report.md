# bench 1793652425930243659-2487

Status: Complete

| Case | Metric | Median | Unit | Scope / statistic | Observations | Processes |
|---|---|---:|---|---|---:|---:|
| compare/point_get/lin [candidate] | wall | 183.8921 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/point_get/sqlite [candidate] | wall | 464.1306 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/point_get/duckdb [candidate] | wall | 235055.4375 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/point_get/hashmap [candidate] | wall | 14.2309 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/filter_eq/lin [candidate] | wall | 930.3198 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/filter_eq/sqlite [candidate] | wall | 117242.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/filter_eq/duckdb [candidate] | wall | 174115.8125 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/filter_range/lin [candidate] | wall | 1588.6060 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/filter_range/sqlite [candidate] | wall | 119408.2812 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/filter_range/duckdb [candidate] | wall | 341714.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/text_substr/lin [candidate] | wall | 41364.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/fts_lex_selective/lin [candidate] | wall | 942.7578 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/fts_lex_common/lin [candidate] | wall | 200485.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/fts_lex_miss/lin [candidate] | wall | 488.3865 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/fts_hybrid_common/lin [candidate] | wall | 6089909.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/text_substr/sqlite [candidate] | wall | 440134.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/text_substr/duckdb [candidate] | wall | 171741.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/materialize/lin [candidate] | wall | 826643.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/materialize/sqlite [candidate] | wall | 1270019.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/materialize/duckdb [candidate] | wall | 1109733.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/join_inner/lin [candidate] | wall | 395229.7500 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/join_inner/lin_cursor [candidate] | wall | 1627874.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/join_inner/lin_cursor_projected [candidate] | wall | 488575.6250 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/join_phase/lin_cursor_open [candidate] | wall | 15083.1055 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/join_phase/lin_cursor_scan_project [candidate] | wall | 2019619.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/join_phase/lin_cursor_scan_projected_row [candidate] | wall | 1039223.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/join_inner/sqlite [candidate] | wall | 3168064.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/join_inner/duckdb [candidate] | wall | 2249213.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/join_filter/lin [candidate] | wall | 337682.3750 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/join_filter/lin_cursor [candidate] | wall | 834450.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/join_filter/sqlite [candidate] | wall | 1675490.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/join_filter/duckdb [candidate] | wall | 1561536.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/agg_sum/lin [candidate] | wall | 8370.7500 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/agg_sum/sqlite [candidate] | wall | 312818.1250 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/agg_sum/duckdb [candidate] | wall | 67148.4375 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/agg_sum_by/lin [candidate] | wall | 579422.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/agg_sum_by/sqlite [candidate] | wall | 2202389.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/agg_sum_by/duckdb [candidate] | wall | 572402.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/agg_count_by/lin [candidate] | wall | 233515.6250 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/agg_count_by/sqlite [candidate] | wall | 636542.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/agg_count_by/duckdb [candidate] | wall | 437302.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/insert_bulk_1k/lin [candidate] | wall | 1786484.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/insert_bulk_1k/sqlite [candidate] | wall | 1192084.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/insert_bulk_1k/duckdb [candidate] | wall | 243711211.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/insert_bulk_10k/lin [candidate] | wall | 18884580.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/insert_bulk_10k/sqlite [candidate] | wall | 15157990.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/insert_bulk_10k/duckdb [candidate] | wall | 2408186163.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/insert_native_1k/duckdb_appender [candidate] | wall | 2740516.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/insert_native_10k/duckdb_appender [candidate] | wall | 18671238.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/insert_phase_10k/lin_full [candidate] | wall | 19225062.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/insert_phase_10k/lin_no_embed [candidate] | wall | 9082232.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/insert_phase_10k/lin_no_embed_no_scalar_index [candidate] | wall | 6503855.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/insert_phase_10k/lin_no_embed_no_scalar_no_fts [candidate] | wall | 4313964.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/append_log_1k/lin [candidate] | wall | 185310.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/append_log_1k/sqlite [candidate] | wall | 606768.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/append_log_1k/duckdb [candidate] | wall | 1442059.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/append_log_10k/lin [candidate] | wall | 1874104.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/append_log_10k/sqlite [candidate] | wall | 7334340.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/append_log_10k/duckdb [candidate] | wall | 9233560.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/group_commit_16/lin_sequential_full [candidate] | wall | 2693045.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/group_commit_16/lin_grouped_full [candidate] | wall | 275960.8750 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/reopen_phase_5k/rebuild_row_maps [candidate] | wall | 748099.7500 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/reopen_phase_5k/rebuild_scalar_indexes [candidate] | wall | 867504.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/reopen_phase_5k/rebuild_fts [candidate] | wall | 1135150.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/plan_dnf_6/lin [candidate] | wall | 129746.3750 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/plan_dnf_10/lin [candidate] | wall | 574054.5000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/plan_dnf_14/lin [candidate] | wall | 603029.7500 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/graph_depth_1/lin [candidate] | wall | 170972.4375 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/graph_depth_2/lin [candidate] | wall | 207891.4375 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/graph_depth_3/lin [candidate] | wall | 242319.3125 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |
| compare/reader_snapshot/lin [candidate] | wall | 10262959.0000 | ns | current thread wall clock; scheduler included / batch_total | 8 | 1 |

# Useful work throughput

| Case | Median batch throughput | Unit |
|---|---:|---|
| compare/join_inner/lin [candidate] | 25302375.8443 | rows/s |
| compare/join_inner/lin_cursor [candidate] | 6142979.7257 | rows/s |
| compare/join_inner/lin_cursor_projected [candidate] | 20467779.1658 | rows/s |
| compare/join_phase/lin_cursor_scan_project [candidate] | 4951442.2174 | rows/s |
| compare/join_phase/lin_cursor_scan_projected_row [candidate] | 9622680.2168 | rows/s |
| compare/join_inner/sqlite [candidate] | 3156502.7420 | rows/s |
| compare/join_inner/duckdb [candidate] | 4446068.7852 | rows/s |
| compare/join_filter/lin [candidate] | 14807064.4052 | rows/s |
| compare/join_filter/lin_cursor [candidate] | 5991987.1948 | rows/s |
| compare/join_filter/sqlite [candidate] | 2984202.3017 | rows/s |
| compare/join_filter/duckdb [candidate] | 3202022.9208 | rows/s |
| compare/agg_sum/lin [candidate] | 1194636447.4475 | rows/s |
| compare/agg_sum/sqlite [candidate] | 31967459.2259 | rows/s |
| compare/agg_sum/duckdb [candidate] | 149751675.2729 | rows/s |
| compare/agg_sum_by/lin [candidate] | 17258828.0276 | rows/s |
| compare/agg_sum_by/sqlite [candidate] | 4540523.0539 | rows/s |
| compare/agg_sum_by/duckdb [candidate] | 17470480.9074 | rows/s |
| compare/agg_count_by/lin [candidate] | 42841195.4628 | rows/s |
| compare/agg_count_by/sqlite [candidate] | 15709882.6768 | rows/s |
| compare/agg_count_by/duckdb [candidate] | 22869910.8100 | rows/s |
| compare/insert_bulk_1k/lin [candidate] | 566965.7313 | rows/s |
| compare/insert_bulk_1k/sqlite [candidate] | 838866.7479 | rows/s |
| compare/insert_bulk_1k/duckdb [candidate] | 4103.2192 | rows/s |
| compare/insert_bulk_10k/lin [candidate] | 529616.1661 | rows/s |
| compare/insert_bulk_10k/sqlite [candidate] | 659718.2262 | rows/s |
| compare/insert_bulk_10k/duckdb [candidate] | 4152.5031 | rows/s |
| compare/insert_native_1k/duckdb_appender [candidate] | 364923.3030 | rows/s |
| compare/insert_native_10k/duckdb_appender [candidate] | 535589.3336 | rows/s |
| compare/insert_phase_10k/lin_full [candidate] | 520156.1147 | rows/s |
| compare/insert_phase_10k/lin_no_embed [candidate] | 1101058.3492 | rows/s |
| compare/insert_phase_10k/lin_no_embed_no_scalar_index [candidate] | 1537549.5996 | rows/s |
| compare/insert_phase_10k/lin_no_embed_no_scalar_no_fts [candidate] | 2318053.4123 | rows/s |
| compare/append_log_1k/lin [candidate] | 5396399.0572 | rows/s |
| compare/append_log_1k/sqlite [candidate] | 1648101.5836 | rows/s |
| compare/append_log_1k/duckdb [candidate] | 693481.3070 | rows/s |
| compare/append_log_10k/lin [candidate] | 5336322.5213 | rows/s |
| compare/append_log_10k/sqlite [candidate] | 1363474.1600 | rows/s |
| compare/append_log_10k/duckdb [candidate] | 1083005.8512 | rows/s |
| compare/group_commit_16/lin_sequential_full [candidate] | 5943.7492 | commits/s |
| compare/group_commit_16/lin_grouped_full [candidate] | 58020.9642 | statements/s |
| compare/reopen_phase_5k/rebuild_row_maps [candidate] | 6683600.7749 | rows/s |
| compare/reopen_phase_5k/rebuild_scalar_indexes [candidate] | 5763663.6009 | rows/s |
| compare/reopen_phase_5k/rebuild_fts [candidate] | 4404710.7366 | rows/s |

Derived from positive wall batches and declared units per operation; zero/unavailable durations omitted.

Medians above summarize observations, not pooled operation-latency percentiles. Comparisons aggregate within each process first.

- Raw batches are not independent process replications. Batch averages are not individual-operation latency. CPU frequency and background load are uncontrolled.

- compare/agg_sum_by/duckdb: some samples below half the requested duration; iteration cap or workload drift may limit precision

- compare/agg_count_by/duckdb: some samples below half the requested duration; iteration cap or workload drift may limit precision

