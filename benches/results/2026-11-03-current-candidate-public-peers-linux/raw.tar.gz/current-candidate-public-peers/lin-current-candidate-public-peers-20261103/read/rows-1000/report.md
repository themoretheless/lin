# Validated read API benchmark

Rows: 1000; process repetitions: 3; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.241 | 1.00× | validated |
| point_get | sqlite | 3.592 | 14.88× | validated |
| point_get | duckdb | 469.085 | 1943.52× | validated |
| point_get | postgres | 200.287 | 829.83× | validated |
| point_get | mysql | 255.933 | 1060.39× | validated |
| point_get | mongo | 465.187 | 1927.37× | validated |
| point_get | pandas | 16.831 | 69.74× | validated |
| filter_eq | lin | 0.950 | 1.00× | validated |
| filter_eq | sqlite | 23.290 | 24.52× | validated |
| filter_eq | duckdb | 664.464 | 699.55× | validated |
| filter_eq | postgres | 280.114 | 294.90× | validated |
| filter_eq | mysql | 351.981 | 370.56× | validated |
| filter_eq | mongo | 655.177 | 689.77× | validated |
| filter_eq | pandas | 208.469 | 219.48× | validated |
| text_substr | lin | 3.849 | 1.00× | validated |
| text_substr | sqlite | 73.705 | 19.15× | validated |
| text_substr | duckdb | 544.755 | 141.53× | validated |
| text_substr | postgres | 285.575 | 74.19× | validated |
| text_substr | mysql | 449.788 | 116.86× | validated |
| text_substr | mongo | 1237.733 | 321.57× | validated |
| text_substr | pandas | 252.205 | 65.52× | validated |
| materialize | lin | 109.191 | 1.00× | validated |
| materialize | sqlite | 464.423 | 4.25× | validated |
| materialize | duckdb | 1320.561 | 12.09× | validated |
| materialize | postgres | 571.120 | 5.23× | validated |
| materialize | mysql | 2514.284 | 23.03× | validated |
| materialize | mongo | 1876.451 | 17.18× | validated |
| materialize | pandas | 1273.518 | 11.66× | validated |
| join_inner | lin | 325.516 | 1.00× | validated |
| join_inner | sqlite | 1098.424 | 3.37× | validated |
| join_inner | duckdb | 1481.550 | 4.55× | validated |
| join_inner | postgres | 1089.897 | 3.35× | validated |
| join_inner | mysql | 5343.574 | 16.42× | validated |
| join_inner | mongo | 39530.539 | 121.44× | validated |
| join_inner | pandas | 2439.744 | 7.50× | validated |
| join_filter | lin | 155.418 | 1.00× | validated |
| join_filter | sqlite | 566.811 | 3.65× | validated |
| join_filter | duckdb | 1285.836 | 8.27× | validated |
| join_filter | postgres | 700.788 | 4.51× | validated |
| join_filter | mysql | 2899.086 | 18.65× | validated |
| join_filter | mongo | 20416.286 | 131.36× | validated |
| join_filter | pandas | 2256.009 | 14.52× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
