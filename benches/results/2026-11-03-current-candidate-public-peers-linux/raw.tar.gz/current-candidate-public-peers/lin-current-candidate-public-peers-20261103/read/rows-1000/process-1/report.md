# Validated read API benchmark

Rows: 1000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.241 | 1.00× | validated |
| point_get | sqlite | 3.618 | 14.99× | validated |
| point_get | duckdb | 476.651 | 1974.87× | validated |
| point_get | postgres | 201.776 | 836.00× | validated |
| point_get | mysql | 255.933 | 1060.39× | validated |
| point_get | mongo | 464.949 | 1926.38× | validated |
| point_get | pandas | 17.505 | 72.53× | validated |
| filter_eq | lin | 0.961 | 1.00× | validated |
| filter_eq | sqlite | 23.290 | 24.22× | validated |
| filter_eq | duckdb | 675.538 | 702.64× | validated |
| filter_eq | postgres | 281.068 | 292.34× | validated |
| filter_eq | mysql | 351.981 | 366.10× | validated |
| filter_eq | mongo | 655.177 | 681.46× | validated |
| filter_eq | pandas | 208.469 | 216.83× | validated |
| text_substr | lin | 3.859 | 1.00× | validated |
| text_substr | sqlite | 73.705 | 19.10× | validated |
| text_substr | duckdb | 555.837 | 144.05× | validated |
| text_substr | postgres | 285.575 | 74.01× | validated |
| text_substr | mysql | 449.788 | 116.57× | validated |
| text_substr | mongo | 1249.317 | 323.77× | validated |
| text_substr | pandas | 278.814 | 72.26× | validated |
| materialize | lin | 109.191 | 1.00× | validated |
| materialize | sqlite | 459.255 | 4.21× | validated |
| materialize | duckdb | 1328.903 | 12.17× | validated |
| materialize | postgres | 580.185 | 5.31× | validated |
| materialize | mysql | 2514.284 | 23.03× | validated |
| materialize | mongo | 1888.244 | 17.29× | validated |
| materialize | pandas | 1374.684 | 12.59× | validated |
| join_inner | lin | 324.485 | 1.00× | validated |
| join_inner | sqlite | 1078.378 | 3.32× | validated |
| join_inner | duckdb | 1519.906 | 4.68× | validated |
| join_inner | postgres | 1093.215 | 3.37× | validated |
| join_inner | mysql | 5343.574 | 16.47× | validated |
| join_inner | mongo | 39530.539 | 121.83× | validated |
| join_inner | pandas | 2439.744 | 7.52× | validated |
| join_filter | lin | 155.418 | 1.00× | validated |
| join_filter | sqlite | 558.384 | 3.59× | validated |
| join_filter | duckdb | 1304.858 | 8.40× | validated |
| join_filter | postgres | 699.390 | 4.50× | validated |
| join_filter | mysql | 2904.687 | 18.69× | validated |
| join_filter | mongo | 20416.286 | 131.36× | validated |
| join_filter | pandas | 2256.009 | 14.52× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
