# Validated read API benchmark

Rows: 1000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | duckdb | 469.085 | 1956.95× | validated |
| point_get | postgres | 200.287 | 835.56× | validated |
| point_get | mysql | 241.859 | 1009.00× | validated |
| point_get | mongo | 465.187 | 1940.69× | validated |
| point_get | pandas | 16.831 | 70.22× | validated |
| point_get | lin | 0.240 | 1.00× | validated |
| point_get | sqlite | 3.592 | 14.98× | validated |
| filter_eq | duckdb | 664.464 | 706.29× | validated |
| filter_eq | postgres | 262.042 | 278.54× | validated |
| filter_eq | mysql | 359.512 | 382.14× | validated |
| filter_eq | mongo | 650.681 | 691.64× | validated |
| filter_eq | pandas | 203.102 | 215.89× | validated |
| filter_eq | lin | 0.941 | 1.00× | validated |
| filter_eq | sqlite | 23.791 | 25.29× | validated |
| text_substr | duckdb | 544.755 | 141.93× | validated |
| text_substr | postgres | 270.012 | 70.35× | validated |
| text_substr | mysql | 456.185 | 118.86× | validated |
| text_substr | mongo | 1235.935 | 322.02× | validated |
| text_substr | pandas | 246.507 | 64.23× | validated |
| text_substr | lin | 3.838 | 1.00× | validated |
| text_substr | sqlite | 75.643 | 19.71× | validated |
| materialize | duckdb | 1320.561 | 11.98× | validated |
| materialize | postgres | 551.768 | 5.01× | validated |
| materialize | mysql | 2528.495 | 22.95× | validated |
| materialize | mongo | 1862.396 | 16.90× | validated |
| materialize | pandas | 1235.233 | 11.21× | validated |
| materialize | lin | 110.197 | 1.00× | validated |
| materialize | sqlite | 464.423 | 4.21× | validated |
| join_inner | duckdb | 1481.550 | 4.50× | validated |
| join_inner | postgres | 1079.799 | 3.28× | validated |
| join_inner | mysql | 5283.106 | 16.05× | validated |
| join_inner | mongo | 40571.610 | 123.29× | validated |
| join_inner | pandas | 2437.561 | 7.41× | validated |
| join_inner | lin | 329.064 | 1.00× | validated |
| join_inner | sqlite | 1098.424 | 3.34× | validated |
| join_filter | duckdb | 1280.828 | 8.13× | validated |
| join_filter | postgres | 700.788 | 4.45× | validated |
| join_filter | mysql | 2899.086 | 18.40× | validated |
| join_filter | mongo | 20136.409 | 127.84× | validated |
| join_filter | pandas | 2251.608 | 14.29× | validated |
| join_filter | lin | 157.518 | 1.00× | validated |
| join_filter | sqlite | 566.811 | 3.60× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
