# Validated read API benchmark

Rows: 1000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | sqlite | 3.581 | 14.83× | validated |
| point_get | duckdb | 465.419 | 1928.06× | validated |
| point_get | postgres | 200.204 | 829.37× | validated |
| point_get | mysql | 275.497 | 1141.28× | validated |
| point_get | mongo | 493.452 | 2044.19× | validated |
| point_get | pandas | 16.792 | 69.56× | validated |
| point_get | lin | 0.241 | 1.00× | validated |
| filter_eq | sqlite | 23.202 | 24.43× | validated |
| filter_eq | duckdb | 657.732 | 692.46× | validated |
| filter_eq | postgres | 280.114 | 294.90× | validated |
| filter_eq | mysql | 322.982 | 340.03× | validated |
| filter_eq | mongo | 679.901 | 715.80× | validated |
| filter_eq | pandas | 209.412 | 220.47× | validated |
| filter_eq | lin | 0.950 | 1.00× | validated |
| text_substr | sqlite | 73.512 | 19.10× | validated |
| text_substr | duckdb | 539.077 | 140.05× | validated |
| text_substr | postgres | 285.670 | 74.22× | validated |
| text_substr | mysql | 436.577 | 113.42× | validated |
| text_substr | mongo | 1237.733 | 321.57× | validated |
| text_substr | pandas | 252.205 | 65.52× | validated |
| text_substr | lin | 3.849 | 1.00× | validated |
| materialize | sqlite | 468.015 | 4.30× | validated |
| materialize | duckdb | 1319.631 | 12.13× | validated |
| materialize | postgres | 571.120 | 5.25× | validated |
| materialize | mysql | 2505.041 | 23.02× | validated |
| materialize | mongo | 1876.451 | 17.24× | validated |
| materialize | pandas | 1273.518 | 11.70× | validated |
| materialize | lin | 108.819 | 1.00× | validated |
| join_inner | sqlite | 1099.823 | 3.38× | validated |
| join_inner | duckdb | 1471.531 | 4.52× | validated |
| join_inner | postgres | 1089.897 | 3.35× | validated |
| join_inner | mysql | 5367.819 | 16.49× | validated |
| join_inner | mongo | 39310.014 | 120.76× | validated |
| join_inner | pandas | 2512.510 | 7.72× | validated |
| join_inner | lin | 325.516 | 1.00× | validated |
| join_filter | sqlite | 567.506 | 3.68× | validated |
| join_filter | duckdb | 1285.836 | 8.34× | validated |
| join_filter | postgres | 704.036 | 4.57× | validated |
| join_filter | mysql | 2878.247 | 18.66× | validated |
| join_filter | mongo | 20816.252 | 134.98× | validated |
| join_filter | pandas | 2291.535 | 14.86× | validated |
| join_filter | lin | 154.215 | 1.00× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
