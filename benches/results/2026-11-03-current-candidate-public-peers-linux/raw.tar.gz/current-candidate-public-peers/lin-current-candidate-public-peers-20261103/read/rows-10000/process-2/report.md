# Validated read API benchmark

Rows: 10000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | sqlite | 3.681 | 15.43× | validated |
| point_get | duckdb | 484.346 | 2030.59× | validated |
| point_get | postgres | 199.297 | 835.54× | validated |
| point_get | mysql | 270.951 | 1135.95× | validated |
| point_get | mongo | 476.839 | 1999.12× | validated |
| point_get | pandas | 17.258 | 72.35× | validated |
| point_get | lin | 0.239 | 1.00× | validated |
| filter_eq | sqlite | 209.899 | 191.97× | validated |
| filter_eq | duckdb | 848.396 | 775.94× | validated |
| filter_eq | postgres | 628.978 | 575.26× | validated |
| filter_eq | mysql | 1070.355 | 978.94× | validated |
| filter_eq | mongo | 1474.341 | 1348.42× | validated |
| filter_eq | pandas | 736.749 | 673.83× | validated |
| filter_eq | lin | 1.093 | 1.00× | validated |
| text_substr | sqlite | 726.361 | 15.25× | validated |
| text_substr | duckdb | 733.201 | 15.39× | validated |
| text_substr | postgres | 1063.221 | 22.32× | validated |
| text_substr | mysql | 2214.149 | 46.48× | validated |
| text_substr | mongo | 6796.344 | 142.67× | validated |
| text_substr | pandas | 1244.083 | 26.12× | validated |
| text_substr | lin | 47.636 | 1.00× | validated |
| materialize | sqlite | 4941.149 | 5.45× | validated |
| materialize | duckdb | 3427.997 | 3.78× | validated |
| materialize | postgres | 3911.025 | 4.32× | validated |
| materialize | mysql | 23424.451 | 25.85× | validated |
| materialize | mongo | 11292.608 | 12.46× | validated |
| materialize | pandas | 5283.025 | 5.83× | validated |
| materialize | lin | 906.285 | 1.00× | validated |
| join_inner | sqlite | 12528.383 | 5.21× | validated |
| join_inner | duckdb | 6867.752 | 2.86× | validated |
| join_inner | postgres | 9766.487 | 4.06× | validated |
| join_inner | mysql | 54218.168 | 22.56× | validated |
| join_inner | mongo | 394068.971 | 163.96× | validated |
| join_inner | pandas | 11473.302 | 4.77× | validated |
| join_inner | lin | 2403.436 | 1.00× | validated |
| join_filter | sqlite | 6356.895 | 4.57× | validated |
| join_filter | duckdb | 4081.576 | 2.94× | validated |
| join_filter | postgres | 5315.367 | 3.82× | validated |
| join_filter | mysql | 27897.417 | 20.07× | validated |
| join_filter | mongo | 196769.307 | 141.53× | validated |
| join_filter | pandas | 6947.834 | 5.00× | validated |
| join_filter | lin | 1390.314 | 1.00× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
