# Validated read API benchmark

Rows: 10000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | duckdb | 480.054 | 1980.41× | validated |
| point_get | postgres | 200.239 | 826.06× | validated |
| point_get | mysql | 241.620 | 996.77× | validated |
| point_get | mongo | 472.439 | 1948.99× | validated |
| point_get | pandas | 16.760 | 69.14× | validated |
| point_get | lin | 0.242 | 1.00× | validated |
| point_get | sqlite | 3.626 | 14.96× | validated |
| filter_eq | duckdb | 853.899 | 784.25× | validated |
| filter_eq | postgres | 624.794 | 573.83× | validated |
| filter_eq | mysql | 1028.504 | 944.61× | validated |
| filter_eq | mongo | 1451.321 | 1332.94× | validated |
| filter_eq | pandas | 714.412 | 656.14× | validated |
| filter_eq | lin | 1.089 | 1.00× | validated |
| filter_eq | sqlite | 211.796 | 194.52× | validated |
| text_substr | duckdb | 746.149 | 15.64× | validated |
| text_substr | postgres | 1056.014 | 22.13× | validated |
| text_substr | mysql | 2153.924 | 45.14× | validated |
| text_substr | mongo | 6773.255 | 141.95× | validated |
| text_substr | pandas | 1230.120 | 25.78× | validated |
| text_substr | lin | 47.716 | 1.00× | validated |
| text_substr | sqlite | 718.197 | 15.05× | validated |
| materialize | duckdb | 3413.581 | 3.73× | validated |
| materialize | postgres | 4126.384 | 4.51× | validated |
| materialize | mysql | 23676.901 | 25.85× | validated |
| materialize | mongo | 11360.404 | 12.40× | validated |
| materialize | pandas | 5165.117 | 5.64× | validated |
| materialize | lin | 915.800 | 1.00× | validated |
| materialize | sqlite | 5194.912 | 5.67× | validated |
| join_inner | duckdb | 6802.034 | 2.81× | validated |
| join_inner | postgres | 9803.781 | 4.05× | validated |
| join_inner | mysql | 54232.934 | 22.40× | validated |
| join_inner | mongo | 392506.128 | 162.11× | validated |
| join_inner | pandas | 11400.558 | 4.71× | validated |
| join_inner | lin | 2421.262 | 1.00× | validated |
| join_inner | sqlite | 12826.097 | 5.30× | validated |
| join_filter | duckdb | 4077.579 | 2.93× | validated |
| join_filter | postgres | 5330.921 | 3.83× | validated |
| join_filter | mysql | 27896.920 | 20.04× | validated |
| join_filter | mongo | 197676.250 | 141.99× | validated |
| join_filter | pandas | 6757.711 | 4.85× | validated |
| join_filter | lin | 1392.213 | 1.00× | validated |
| join_filter | sqlite | 6446.305 | 4.63× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
