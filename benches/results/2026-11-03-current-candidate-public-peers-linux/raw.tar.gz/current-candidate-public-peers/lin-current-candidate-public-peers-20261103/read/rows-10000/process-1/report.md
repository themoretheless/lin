# Validated read API benchmark

Rows: 10000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.250 | 1.00× | validated |
| point_get | sqlite | 3.580 | 14.34× | validated |
| point_get | duckdb | 479.906 | 1922.63× | validated |
| point_get | postgres | 199.370 | 798.73× | validated |
| point_get | mysql | 246.855 | 988.97× | validated |
| point_get | mongo | 484.216 | 1939.90× | validated |
| point_get | pandas | 17.152 | 68.71× | validated |
| filter_eq | lin | 1.072 | 1.00× | validated |
| filter_eq | sqlite | 208.352 | 194.32× | validated |
| filter_eq | duckdb | 849.644 | 792.44× | validated |
| filter_eq | postgres | 627.371 | 585.13× | validated |
| filter_eq | mysql | 1022.247 | 953.43× | validated |
| filter_eq | mongo | 1462.410 | 1363.96× | validated |
| filter_eq | pandas | 705.293 | 657.81× | validated |
| text_substr | lin | 47.702 | 1.00× | validated |
| text_substr | sqlite | 725.279 | 15.20× | validated |
| text_substr | duckdb | 733.676 | 15.38× | validated |
| text_substr | postgres | 1067.527 | 22.38× | validated |
| text_substr | mysql | 2171.279 | 45.52× | validated |
| text_substr | mongo | 6767.435 | 141.87× | validated |
| text_substr | pandas | 1293.333 | 27.11× | validated |
| materialize | lin | 905.654 | 1.00× | validated |
| materialize | sqlite | 4940.568 | 5.46× | validated |
| materialize | duckdb | 3466.238 | 3.83× | validated |
| materialize | postgres | 3890.776 | 4.30× | validated |
| materialize | mysql | 23388.759 | 25.83× | validated |
| materialize | mongo | 11146.040 | 12.31× | validated |
| materialize | pandas | 5307.011 | 5.86× | validated |
| join_inner | lin | 2394.112 | 1.00× | validated |
| join_inner | sqlite | 12532.425 | 5.23× | validated |
| join_inner | duckdb | 6834.765 | 2.85× | validated |
| join_inner | postgres | 10052.475 | 4.20× | validated |
| join_inner | mysql | 53928.226 | 22.53× | validated |
| join_inner | mongo | 390846.068 | 163.25× | validated |
| join_inner | pandas | 11440.363 | 4.78× | validated |
| join_filter | lin | 1408.445 | 1.00× | validated |
| join_filter | sqlite | 6348.358 | 4.51× | validated |
| join_filter | duckdb | 4233.374 | 3.01× | validated |
| join_filter | postgres | 5407.153 | 3.84× | validated |
| join_filter | mysql | 27782.247 | 19.73× | validated |
| join_filter | mongo | 196633.906 | 139.61× | validated |
| join_filter | pandas | 6911.864 | 4.91× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
