# Validated read API benchmark

Rows: 10000; process repetitions: 3; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.242 | 1.00× | validated |
| point_get | sqlite | 3.626 | 14.96× | validated |
| point_get | duckdb | 480.054 | 1980.41× | validated |
| point_get | postgres | 199.370 | 822.48× | validated |
| point_get | mysql | 246.855 | 1018.37× | validated |
| point_get | mongo | 476.839 | 1967.14× | validated |
| point_get | pandas | 17.152 | 70.76× | validated |
| filter_eq | lin | 1.089 | 1.00× | validated |
| filter_eq | sqlite | 209.899 | 192.78× | validated |
| filter_eq | duckdb | 849.644 | 780.34× | validated |
| filter_eq | postgres | 627.371 | 576.20× | validated |
| filter_eq | mysql | 1028.504 | 944.61× | validated |
| filter_eq | mongo | 1462.410 | 1343.12× | validated |
| filter_eq | pandas | 714.412 | 656.14× | validated |
| text_substr | lin | 47.702 | 1.00× | validated |
| text_substr | sqlite | 725.279 | 15.20× | validated |
| text_substr | duckdb | 733.676 | 15.38× | validated |
| text_substr | postgres | 1063.221 | 22.29× | validated |
| text_substr | mysql | 2171.279 | 45.52× | validated |
| text_substr | mongo | 6773.255 | 141.99× | validated |
| text_substr | pandas | 1244.083 | 26.08× | validated |
| materialize | lin | 906.285 | 1.00× | validated |
| materialize | sqlite | 4941.149 | 5.45× | validated |
| materialize | duckdb | 3427.997 | 3.78× | validated |
| materialize | postgres | 3911.025 | 4.32× | validated |
| materialize | mysql | 23424.451 | 25.85× | validated |
| materialize | mongo | 11292.608 | 12.46× | validated |
| materialize | pandas | 5283.025 | 5.83× | validated |
| join_inner | lin | 2403.436 | 1.00× | validated |
| join_inner | sqlite | 12532.425 | 5.21× | validated |
| join_inner | duckdb | 6834.765 | 2.84× | validated |
| join_inner | postgres | 9803.781 | 4.08× | validated |
| join_inner | mysql | 54218.168 | 22.56× | validated |
| join_inner | mongo | 392506.128 | 163.31× | validated |
| join_inner | pandas | 11440.363 | 4.76× | validated |
| join_filter | lin | 1392.213 | 1.00× | validated |
| join_filter | sqlite | 6356.895 | 4.57× | validated |
| join_filter | duckdb | 4081.576 | 2.93× | validated |
| join_filter | postgres | 5330.921 | 3.83× | validated |
| join_filter | mysql | 27896.920 | 20.04× | validated |
| join_filter | mongo | 196769.307 | 141.34× | validated |
| join_filter | pandas | 6911.864 | 4.96× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
