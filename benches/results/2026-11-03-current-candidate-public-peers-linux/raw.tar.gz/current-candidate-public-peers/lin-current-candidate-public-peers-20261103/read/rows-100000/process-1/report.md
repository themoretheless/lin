# Validated read API benchmark

Rows: 100000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.241 | 1.00× | validated |
| point_get | sqlite | 3.663 | 15.21× | validated |
| point_get | duckdb | 510.245 | 2118.39× | validated |
| point_get | postgres | 200.473 | 832.30× | validated |
| point_get | mysql | 255.527 | 1060.87× | validated |
| point_get | mongo | 470.272 | 1952.43× | validated |
| point_get | pandas | 16.608 | 68.95× | validated |
| filter_eq | lin | 2.152 | 1.00× | validated |
| filter_eq | sqlite | 2072.430 | 963.16× | validated |
| filter_eq | duckdb | 1022.027 | 474.99× | validated |
| filter_eq | postgres | 4393.974 | 2042.10× | validated |
| filter_eq | mysql | 7807.730 | 3628.64× | validated |
| filter_eq | mongo | 8862.794 | 4118.98× | validated |
| filter_eq | pandas | 5567.977 | 2587.71× | validated |
| text_substr | lin | 549.619 | 1.00× | validated |
| text_substr | sqlite | 7263.675 | 13.22× | validated |
| text_substr | duckdb | 3440.019 | 6.26× | validated |
| text_substr | postgres | 9110.145 | 16.58× | validated |
| text_substr | mysql | 19819.661 | 36.06× | validated |
| text_substr | mongo | 65166.459 | 118.57× | validated |
| text_substr | pandas | 11004.951 | 20.02× | validated |
| materialize | lin | 13129.754 | 1.00× | validated |
| materialize | sqlite | 57665.293 | 4.39× | validated |
| materialize | duckdb | 29446.691 | 2.24× | validated |
| materialize | postgres | 40269.163 | 3.07× | validated |
| materialize | mysql | 227144.524 | 17.30× | validated |
| materialize | mongo | 108766.794 | 8.28× | validated |
| materialize | pandas | 46061.863 | 3.51× | validated |
| join_inner | lin | 42918.535 | 1.00× | validated |
| join_inner | sqlite | 149548.126 | 3.48× | validated |
| join_inner | duckdb | 76986.409 | 1.79× | validated |
| join_inner | postgres | 118061.729 | 2.75× | validated |
| join_inner | mysql | 459690.704 | 10.71× | validated |
| join_inner | mongo | 3983526.171 | 92.82× | validated |
| join_inner | pandas | 105027.151 | 2.45× | validated |
| join_filter | lin | 15462.065 | 1.00× | validated |
| join_filter | sqlite | 67844.755 | 4.39× | validated |
| join_filter | duckdb | 34067.816 | 2.20× | validated |
| join_filter | postgres | 56977.309 | 3.68× | validated |
| join_filter | mysql | 249549.028 | 16.14× | validated |
| join_filter | mongo | 2009786.201 | 129.98× | validated |
| join_filter | pandas | 53667.209 | 3.47× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
