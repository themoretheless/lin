# Validated read API benchmark

Rows: 100000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | sqlite | 3.751 | 14.50× | validated |
| point_get | duckdb | 506.372 | 1957.00× | validated |
| point_get | postgres | 215.510 | 832.89× | validated |
| point_get | mysql | 274.659 | 1061.49× | validated |
| point_get | mongo | 482.801 | 1865.91× | validated |
| point_get | pandas | 16.831 | 65.05× | validated |
| point_get | lin | 0.259 | 1.00× | validated |
| filter_eq | sqlite | 2077.237 | 981.65× | validated |
| filter_eq | duckdb | 1007.182 | 475.97× | validated |
| filter_eq | postgres | 4374.122 | 2067.11× | validated |
| filter_eq | mysql | 7694.136 | 3636.07× | validated |
| filter_eq | mongo | 8875.658 | 4194.43× | validated |
| filter_eq | pandas | 5639.092 | 2664.90× | validated |
| filter_eq | lin | 2.116 | 1.00× | validated |
| text_substr | sqlite | 7222.708 | 13.10× | validated |
| text_substr | duckdb | 3423.572 | 6.21× | validated |
| text_substr | postgres | 8951.162 | 16.23× | validated |
| text_substr | mysql | 19800.709 | 35.91× | validated |
| text_substr | mongo | 64878.446 | 117.66× | validated |
| text_substr | pandas | 10957.159 | 19.87× | validated |
| text_substr | lin | 551.424 | 1.00× | validated |
| materialize | sqlite | 59258.986 | 4.35× | validated |
| materialize | duckdb | 29981.544 | 2.20× | validated |
| materialize | postgres | 41050.616 | 3.01× | validated |
| materialize | mysql | 228360.604 | 16.75× | validated |
| materialize | mongo | 109440.504 | 8.03× | validated |
| materialize | pandas | 47297.103 | 3.47× | validated |
| materialize | lin | 13629.899 | 1.00× | validated |
| join_inner | sqlite | 148504.634 | 3.60× | validated |
| join_inner | duckdb | 77044.594 | 1.87× | validated |
| join_inner | postgres | 120032.924 | 2.91× | validated |
| join_inner | mysql | 461200.142 | 11.18× | validated |
| join_inner | mongo | 4038533.402 | 97.93× | validated |
| join_inner | pandas | 105732.304 | 2.56× | validated |
| join_inner | lin | 41239.147 | 1.00× | validated |
| join_filter | sqlite | 68808.009 | 5.01× | validated |
| join_filter | duckdb | 34669.228 | 2.52× | validated |
| join_filter | postgres | 56133.510 | 4.09× | validated |
| join_filter | mysql | 248829.448 | 18.12× | validated |
| join_filter | mongo | 2017399.527 | 146.88× | validated |
| join_filter | pandas | 55140.253 | 4.01× | validated |
| join_filter | lin | 13734.729 | 1.00× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
