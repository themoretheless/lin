# Validated read API benchmark

Rows: 100000; process repetitions: 3; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.242 | 1.00× | validated |
| point_get | sqlite | 3.748 | 15.51× | validated |
| point_get | duckdb | 506.372 | 2095.51× | validated |
| point_get | postgres | 202.044 | 836.11× | validated |
| point_get | mysql | 255.527 | 1057.44× | validated |
| point_get | mongo | 470.272 | 1946.12× | validated |
| point_get | pandas | 16.831 | 69.65× | validated |
| filter_eq | lin | 2.152 | 1.00× | validated |
| filter_eq | sqlite | 2072.430 | 963.16× | validated |
| filter_eq | duckdb | 1017.120 | 472.71× | validated |
| filter_eq | postgres | 4393.974 | 2042.10× | validated |
| filter_eq | mysql | 7694.136 | 3575.85× | validated |
| filter_eq | mongo | 8875.658 | 4124.96× | validated |
| filter_eq | pandas | 5587.653 | 2596.86× | validated |
| text_substr | lin | 550.022 | 1.00× | validated |
| text_substr | sqlite | 7263.675 | 13.21× | validated |
| text_substr | duckdb | 3423.572 | 6.22× | validated |
| text_substr | postgres | 9074.165 | 16.50× | validated |
| text_substr | mysql | 19800.709 | 36.00× | validated |
| text_substr | mongo | 65166.459 | 118.48× | validated |
| text_substr | pandas | 11004.951 | 20.01× | validated |
| materialize | lin | 13629.899 | 1.00× | validated |
| materialize | sqlite | 57665.293 | 4.23× | validated |
| materialize | duckdb | 29981.544 | 2.20× | validated |
| materialize | postgres | 41050.616 | 3.01× | validated |
| materialize | mysql | 227144.524 | 16.67× | validated |
| materialize | mongo | 108766.794 | 7.98× | validated |
| materialize | pandas | 46061.863 | 3.38× | validated |
| join_inner | lin | 41757.154 | 1.00× | validated |
| join_inner | sqlite | 148504.634 | 3.56× | validated |
| join_inner | duckdb | 77044.594 | 1.85× | validated |
| join_inner | postgres | 120032.924 | 2.87× | validated |
| join_inner | mysql | 461200.142 | 11.04× | validated |
| join_inner | mongo | 3984628.697 | 95.42× | validated |
| join_inner | pandas | 105732.304 | 2.53× | validated |
| join_filter | lin | 13782.744 | 1.00× | validated |
| join_filter | sqlite | 68808.009 | 4.99× | validated |
| join_filter | duckdb | 34309.918 | 2.49× | validated |
| join_filter | postgres | 56977.309 | 4.13× | validated |
| join_filter | mysql | 248829.448 | 18.05× | validated |
| join_filter | mongo | 2015871.070 | 146.26× | validated |
| join_filter | pandas | 54459.545 | 3.95× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
