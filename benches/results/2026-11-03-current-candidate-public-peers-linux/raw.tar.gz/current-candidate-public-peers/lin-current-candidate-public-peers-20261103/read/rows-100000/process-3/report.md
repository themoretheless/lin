# Validated read API benchmark

Rows: 100000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | duckdb | 505.413 | 2091.54× | validated |
| point_get | postgres | 202.044 | 836.11× | validated |
| point_get | mysql | 238.543 | 987.16× | validated |
| point_get | mongo | 456.874 | 1890.68× | validated |
| point_get | pandas | 17.374 | 71.90× | validated |
| point_get | lin | 0.242 | 1.00× | validated |
| point_get | sqlite | 3.748 | 15.51× | validated |
| filter_eq | duckdb | 1017.120 | 471.25× | validated |
| filter_eq | postgres | 4424.181 | 2049.80× | validated |
| filter_eq | mysql | 7663.782 | 3550.76× | validated |
| filter_eq | mongo | 9651.371 | 4471.65× | validated |
| filter_eq | pandas | 5587.653 | 2588.86× | validated |
| filter_eq | lin | 2.158 | 1.00× | validated |
| filter_eq | sqlite | 2059.590 | 954.24× | validated |
| text_substr | duckdb | 3404.539 | 6.19× | validated |
| text_substr | postgres | 9074.165 | 16.50× | validated |
| text_substr | mysql | 19601.091 | 35.64× | validated |
| text_substr | mongo | 65285.628 | 118.70× | validated |
| text_substr | pandas | 11583.287 | 21.06× | validated |
| text_substr | lin | 550.022 | 1.00× | validated |
| text_substr | sqlite | 7359.015 | 13.38× | validated |
| materialize | duckdb | 33416.393 | 2.30× | validated |
| materialize | postgres | 41886.707 | 2.88× | validated |
| materialize | mysql | 222147.310 | 15.28× | validated |
| materialize | mongo | 108181.247 | 7.44× | validated |
| materialize | pandas | 45838.531 | 3.15× | validated |
| materialize | lin | 14534.475 | 1.00× | validated |
| materialize | sqlite | 56205.065 | 3.87× | validated |
| join_inner | duckdb | 78713.785 | 1.89× | validated |
| join_inner | postgres | 120370.244 | 2.88× | validated |
| join_inner | mysql | 463319.577 | 11.10× | validated |
| join_inner | mongo | 3984628.697 | 95.42× | validated |
| join_inner | pandas | 109086.817 | 2.61× | validated |
| join_inner | lin | 41757.154 | 1.00× | validated |
| join_inner | sqlite | 134458.569 | 3.22× | validated |
| join_filter | duckdb | 34309.918 | 2.49× | validated |
| join_filter | postgres | 58371.218 | 4.24× | validated |
| join_filter | mysql | 248697.382 | 18.04× | validated |
| join_filter | mongo | 2015871.070 | 146.26× | validated |
| join_filter | pandas | 54459.545 | 3.95× | validated |
| join_filter | lin | 13782.744 | 1.00× | validated |
| join_filter | sqlite | 68924.041 | 5.00× | validated |

Versions: {"duckdb": "2.0.0", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
