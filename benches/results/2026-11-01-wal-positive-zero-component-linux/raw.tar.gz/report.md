# Full WAL positive-zero component comparison

Linux x86_64, same frozen compare harness; corrected baseline21dcd7d81 versus positive-zero candidate62e14c7eb; only Full UPDATE/DELETE/Batch encoding changes. No RSS claim. Full engine and eight-peer goal remain unqualified.

|Case|Series|Gain %|Absolute A/A %|Positive|Pass|
|---|---|---:|---:|---:|---|
|compare/durable_update_1row_1k/lin|series1|16.209|7.743|6/6|True|
|compare/durable_update_1row_1k/lin|series2|20.562|7.010|6/6|True|
|compare/durable_update_1row_10k/lin|series1|14.134|5.533|6/6|True|
|compare/durable_update_1row_10k/lin|series2|13.727|10.555|6/6|True|
|compare/durable_delete_1row_1k/lin|series1|20.337|3.202|6/6|True|
|compare/durable_delete_1row_1k/lin|series2|17.928|6.392|6/6|True|
|compare/durable_delete_1row_10k/lin|series1|15.555|4.216|6/6|True|
|compare/durable_delete_1row_10k/lin|series2|11.556|5.224|6/6|True|
|compare/durable_commit_1row_10k/lin|series1|15.936|5.582|6/6|True|
|compare/durable_commit_1row_10k/lin|series2|16.322|4.291|6/6|True|
|compare/durable_rollback_1row_10k/lin|series1|0.518|0.889|4/6|True|
|compare/durable_rollback_1row_10k/lin|series2|1.856|1.931|5/6|True|
|compare/wal_scalar_full_update/lin|series1|0.124|2.239|3/6|True|
|compare/wal_scalar_full_update/lin|series2|0.338|4.270|3/6|True|
|compare/wal_scalar_normal_update/lin|series1|1.001|1.315|5/6|True|
|compare/wal_scalar_normal_update/lin|series2|-0.298|2.826|3/6|True|
|compare/update_1row_1k/lin|series1|-3.214|1.096|2/6|False|
|compare/update_1row_1k/lin|series2|-2.323|1.967|1/6|False|
|compare/insert_bulk_10k/lin|series1|0.068|2.097|3/6|True|
|compare/insert_bulk_10k/lin|series2|-1.428|0.968|2/6|True|
|compare/filter_eq/lin|series1|1.502|2.732|6/6|True|
|compare/filter_eq/lin|series2|1.348|1.873|4/6|True|
|compare/durable_update_1row_10k/sqlite_wal|series1|1.472|3.060|3/6|True|
|compare/durable_update_1row_10k/sqlite_wal|series2|-2.017|3.805|1/6|True|

Component gate: False. All 432 processes / 3456 wall observations retained.
