# Rollback FTS synchronization component comparison

Linux x86_64, same frozen compare harness; corrected rollback baseline21dcd7d81 versus candidate2e5146fce; only restore_row_owned FTS maintenance changes. No RSS claim. Full engine and eight-peer goal remain unqualified.

|Case|Series|Gain %|Absolute A/A %|Positive|Pass|
|---|---|---:|---:|---:|---|
|compare/durable_rollback_1row_1k/lin|series1|12.269|2.542|5/6|False|
|compare/durable_rollback_1row_1k/lin|series2|19.156|7.685|6/6|True|
|compare/durable_rollback_1row_10k/lin|series1|14.666|3.169|6/6|True|
|compare/durable_rollback_1row_10k/lin|series2|14.753|1.363|6/6|True|
|compare/durable_update_1row_1k/lin|series1|6.571|4.372|4/6|True|
|compare/durable_update_1row_1k/lin|series2|-5.151|3.329|2/6|False|
|compare/durable_commit_1row_10k/lin|series1|1.411|3.002|3/6|True|
|compare/durable_commit_1row_10k/lin|series2|0.747|3.111|4/6|True|
|compare/durable_delete_1row_1k/lin|series1|3.294|6.226|3/6|True|
|compare/durable_delete_1row_1k/lin|series2|2.592|5.222|4/6|True|
|compare/wal_scalar_full_update/lin|series1|1.495|7.193|4/6|True|
|compare/wal_scalar_full_update/lin|series2|-0.080|5.237|3/6|True|
|compare/wal_scalar_normal_update/lin|series1|1.755|6.608|4/6|True|
|compare/wal_scalar_normal_update/lin|series2|3.123|4.014|4/6|True|
|compare/durable_rollback_1row_1k/sqlite_wal|series1|0.449|3.668|5/6|True|
|compare/durable_rollback_1row_1k/sqlite_wal|series2|1.499|5.101|3/6|True|

Component gate: False. All 288 processes / 2304 wall observations retained.
