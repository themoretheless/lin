# Large builtin hashing batch parallelism component comparison

Linux x86_64, same frozen compare harness; previous COW+CAS baseline versus builtin hashing batch parallel candidate. No RSS claim. Full engine and eight-peer goal remain unqualified.

|Case|Series|Gain %|Absolute A/A %|Positive|Pass|
|---|---|---:|---:|---:|---|
|compare/insert_bulk_10k/lin|series1|-1.343|0.656|0/6|False|
|compare/insert_bulk_10k/lin|series2|-1.566|1.972|1/6|False|
|compare/insert_bulk_1k/lin|series1|-1.501|2.995|1/6|True|
|compare/insert_bulk_1k/lin|series2|-0.580|1.377|2/6|True|
|compare/point_get/lin|series1|6.697|5.828|5/6|True|
|compare/point_get/lin|series2|2.157|1.994|5/6|True|
|compare/filter_eq/lin|series1|-1.024|3.415|2/6|True|
|compare/filter_eq/lin|series2|0.505|3.312|3/6|True|
|compare/update_1row_1k/lin|series1|-0.302|4.657|3/6|True|
|compare/update_1row_1k/lin|series2|-0.288|7.168|2/6|True|
|compare/wal_scalar_full_update/lin|series1|6.408|8.971|4/6|True|
|compare/wal_scalar_full_update/lin|series2|-11.261|4.141|1/6|False|
|compare/wal_scalar_normal_update/lin|series1|-2.903|3.577|3/6|True|
|compare/wal_scalar_normal_update/lin|series2|-1.014|3.723|2/6|True|
|compare/insert_bulk_10k/sqlite|series1|0.411|0.861|5/6|True|
|compare/insert_bulk_10k/sqlite|series2|0.335|0.787|4/6|True|
|compare/filter_eq/duckdb|series1|-0.261|3.930|3/6|True|
|compare/filter_eq/duckdb|series2|0.866|3.481|4/6|True|

Component gate: False. All 324 processes / 2592 wall observations retained.
