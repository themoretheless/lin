# Large builtin hashing batch parallelism component comparison

Linux x86_64, same frozen compare harness; previous COW+CAS baseline versus builtin hashing batch parallel candidate. No RSS claim. Full engine and eight-peer goal remain unqualified.

|Case|Series|Gain %|Absolute A/A %|Positive|Pass|
|---|---|---:|---:|---:|---|
|compare/insert_bulk_10k/lin|series1|7.790|2.081|5/6|False|
|compare/insert_bulk_10k/lin|series2|8.054|1.403|6/6|True|
|compare/insert_bulk_1k/lin|series1|1.469|1.421|5/6|True|
|compare/insert_bulk_1k/lin|series2|2.448|2.273|6/6|True|
|compare/point_get/lin|series1|-2.311|2.795|2/6|True|
|compare/point_get/lin|series2|1.214|1.310|4/6|True|
|compare/filter_eq/lin|series1|4.119|1.768|5/6|True|
|compare/filter_eq/lin|series2|0.195|3.419|3/6|True|
|compare/update_1row_1k/lin|series1|-2.107|2.709|1/6|True|
|compare/update_1row_1k/lin|series2|2.206|4.207|4/6|True|
|compare/wal_scalar_full_update/lin|series1|3.097|2.411|5/6|True|
|compare/wal_scalar_full_update/lin|series2|1.703|2.335|5/6|True|
|compare/wal_scalar_normal_update/lin|series1|1.803|1.246|5/6|True|
|compare/wal_scalar_normal_update/lin|series2|1.507|3.060|3/6|True|
|compare/insert_bulk_10k/sqlite|series1|0.096|0.467|4/6|True|
|compare/insert_bulk_10k/sqlite|series2|0.765|0.851|5/6|True|
|compare/filter_eq/duckdb|series1|5.149|2.714|6/6|True|
|compare/filter_eq/duckdb|series2|-0.431|3.193|3/6|True|

Component gate: False. All 324 processes / 2592 wall observations retained.
