# Validated read API benchmark

Rows: 10000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | sqlite | 3.565 | 16.77× | validated |
| point_get | duckdb | 231.907 | 1091.06× | validated |
| point_get | postgres | 206.026 | 969.29× | validated |
| point_get | mysql | 247.983 | 1166.69× | validated |
| point_get | mongo | 489.867 | 2304.68× | validated |
| point_get | pandas | 16.989 | 79.93× | validated |
| point_get | lin | 0.213 | 1.00× | validated |
| filter_eq | sqlite | 204.541 | 195.35× | validated |
| filter_eq | duckdb | 664.022 | 634.19× | validated |
| filter_eq | postgres | 626.138 | 598.01× | validated |
| filter_eq | mysql | 1095.473 | 1046.26× | validated |
| filter_eq | mongo | 1450.852 | 1385.67× | validated |
| filter_eq | pandas | 656.662 | 627.16× | validated |
| filter_eq | lin | 1.047 | 1.00× | validated |
| text_substr | sqlite | 705.705 | 14.73× | validated |
| text_substr | duckdb | 439.858 | 9.18× | validated |
| text_substr | postgres | 1075.554 | 22.45× | validated |
| text_substr | mysql | 2183.990 | 45.59× | validated |
| text_substr | mongo | 6810.904 | 142.17× | validated |
| text_substr | pandas | 1393.169 | 29.08× | validated |
| text_substr | lin | 47.908 | 1.00× | validated |
| materialize | sqlite | 4791.994 | 4.66× | validated |
| materialize | duckdb | 3485.584 | 3.39× | validated |
| materialize | postgres | 4159.218 | 4.04× | validated |
| materialize | mysql | 24720.467 | 24.02× | validated |
| materialize | mongo | 11392.005 | 11.07× | validated |
| materialize | pandas | 5279.600 | 5.13× | validated |
| materialize | lin | 1029.237 | 1.00× | validated |
| join_inner | sqlite | 12081.195 | 3.29× | validated |
| join_inner | duckdb | 7971.608 | 2.17× | validated |
| join_inner | postgres | 10577.385 | 2.88× | validated |
| join_inner | mysql | 55405.224 | 15.08× | validated |
| join_inner | mongo | 385288.140 | 104.87× | validated |
| join_inner | pandas | 11392.415 | 3.10× | validated |
| join_inner | lin | 3673.943 | 1.00× | validated |
| join_filter | sqlite | 6195.370 | 3.36× | validated |
| join_filter | duckdb | 4589.547 | 2.49× | validated |
| join_filter | postgres | 5921.324 | 3.21× | validated |
| join_filter | mysql | 29155.292 | 15.82× | validated |
| join_filter | mongo | 193943.864 | 105.26× | validated |
| join_filter | pandas | 6972.189 | 3.78× | validated |
| join_filter | lin | 1842.594 | 1.00× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
