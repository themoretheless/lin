# Validated read API benchmark

Rows: 10000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.210 | 1.00× | validated |
| point_get | sqlite | 3.562 | 16.94× | validated |
| point_get | duckdb | 246.152 | 1170.89× | validated |
| point_get | postgres | 207.681 | 987.89× | validated |
| point_get | mysql | 281.288 | 1338.03× | validated |
| point_get | mongo | 474.986 | 2259.41× | validated |
| point_get | pandas | 16.941 | 80.59× | validated |
| filter_eq | lin | 1.036 | 1.00× | validated |
| filter_eq | sqlite | 206.842 | 199.59× | validated |
| filter_eq | duckdb | 691.784 | 667.53× | validated |
| filter_eq | postgres | 631.446 | 609.31× | validated |
| filter_eq | mysql | 1027.841 | 991.80× | validated |
| filter_eq | mongo | 1449.373 | 1398.55× | validated |
| filter_eq | pandas | 657.287 | 634.24× | validated |
| text_substr | lin | 47.758 | 1.00× | validated |
| text_substr | sqlite | 729.855 | 15.28× | validated |
| text_substr | duckdb | 455.782 | 9.54× | validated |
| text_substr | postgres | 1070.596 | 22.42× | validated |
| text_substr | mysql | 2196.036 | 45.98× | validated |
| text_substr | mongo | 6800.823 | 142.40× | validated |
| text_substr | pandas | 1375.419 | 28.80× | validated |
| materialize | lin | 1011.519 | 1.00× | validated |
| materialize | sqlite | 4897.682 | 4.84× | validated |
| materialize | duckdb | 3508.733 | 3.47× | validated |
| materialize | postgres | 3965.348 | 3.92× | validated |
| materialize | mysql | 24791.100 | 24.51× | validated |
| materialize | mongo | 11510.866 | 11.38× | validated |
| materialize | pandas | 5291.550 | 5.23× | validated |
| join_inner | lin | 3667.554 | 1.00× | validated |
| join_inner | sqlite | 12308.626 | 3.36× | validated |
| join_inner | duckdb | 8092.372 | 2.21× | validated |
| join_inner | postgres | 10507.134 | 2.86× | validated |
| join_inner | mysql | 56731.887 | 15.47× | validated |
| join_inner | mongo | 387264.354 | 105.59× | validated |
| join_inner | pandas | 11551.315 | 3.15× | validated |
| join_filter | lin | 1836.700 | 1.00× | validated |
| join_filter | sqlite | 6255.274 | 3.41× | validated |
| join_filter | duckdb | 4590.305 | 2.50× | validated |
| join_filter | postgres | 5935.689 | 3.23× | validated |
| join_filter | mysql | 29464.529 | 16.04× | validated |
| join_filter | mongo | 196115.206 | 106.78× | validated |
| join_filter | pandas | 6892.984 | 3.75× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
