# Validated read API benchmark

Rows: 10000; process repetitions: 3; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.213 | 1.00× | validated |
| point_get | sqlite | 3.565 | 16.77× | validated |
| point_get | duckdb | 244.083 | 1148.34× | validated |
| point_get | postgres | 206.026 | 969.29× | validated |
| point_get | mysql | 281.288 | 1323.38× | validated |
| point_get | mongo | 476.908 | 2243.72× | validated |
| point_get | pandas | 16.989 | 79.93× | validated |
| filter_eq | lin | 1.036 | 1.00× | validated |
| filter_eq | sqlite | 206.631 | 199.39× | validated |
| filter_eq | duckdb | 691.784 | 667.53× | validated |
| filter_eq | postgres | 631.446 | 609.31× | validated |
| filter_eq | mysql | 1056.409 | 1019.37× | validated |
| filter_eq | mongo | 1449.373 | 1398.55× | validated |
| filter_eq | pandas | 657.287 | 634.24× | validated |
| text_substr | lin | 47.821 | 1.00× | validated |
| text_substr | sqlite | 719.632 | 15.05× | validated |
| text_substr | duckdb | 441.344 | 9.23× | validated |
| text_substr | postgres | 1075.554 | 22.49× | validated |
| text_substr | mysql | 2194.535 | 45.89× | validated |
| text_substr | mongo | 6810.904 | 142.42× | validated |
| text_substr | pandas | 1375.419 | 28.76× | validated |
| materialize | lin | 1022.334 | 1.00× | validated |
| materialize | sqlite | 4897.682 | 4.79× | validated |
| materialize | duckdb | 3485.584 | 3.41× | validated |
| materialize | postgres | 4015.649 | 3.93× | validated |
| materialize | mysql | 24720.467 | 24.18× | validated |
| materialize | mongo | 11392.005 | 11.14× | validated |
| materialize | pandas | 5279.600 | 5.16× | validated |
| join_inner | lin | 3667.554 | 1.00× | validated |
| join_inner | sqlite | 12100.719 | 3.30× | validated |
| join_inner | duckdb | 7971.608 | 2.17× | validated |
| join_inner | postgres | 10507.134 | 2.86× | validated |
| join_inner | mysql | 55523.967 | 15.14× | validated |
| join_inner | mongo | 385859.678 | 105.21× | validated |
| join_inner | pandas | 11551.315 | 3.15× | validated |
| join_filter | lin | 1836.700 | 1.00× | validated |
| join_filter | sqlite | 6255.274 | 3.41× | validated |
| join_filter | duckdb | 4589.547 | 2.50× | validated |
| join_filter | postgres | 5921.324 | 3.22× | validated |
| join_filter | mysql | 29155.292 | 15.87× | validated |
| join_filter | mongo | 193943.864 | 105.59× | validated |
| join_filter | pandas | 6936.756 | 3.78× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
