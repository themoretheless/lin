# Validated read API benchmark

Rows: 10000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | duckdb | 244.083 | 1133.66× | validated |
| point_get | postgres | 201.069 | 933.88× | validated |
| point_get | mysql | 283.298 | 1315.80× | validated |
| point_get | mongo | 476.908 | 2215.04× | validated |
| point_get | pandas | 17.106 | 79.45× | validated |
| point_get | lin | 0.215 | 1.00× | validated |
| point_get | sqlite | 3.614 | 16.78× | validated |
| filter_eq | duckdb | 709.583 | 690.31× | validated |
| filter_eq | postgres | 649.111 | 631.48× | validated |
| filter_eq | mysql | 1056.409 | 1027.71× | validated |
| filter_eq | mongo | 1432.416 | 1393.50× | validated |
| filter_eq | pandas | 658.407 | 640.52× | validated |
| filter_eq | lin | 1.028 | 1.00× | validated |
| filter_eq | sqlite | 206.631 | 201.02× | validated |
| text_substr | duckdb | 441.344 | 9.23× | validated |
| text_substr | postgres | 1093.235 | 22.86× | validated |
| text_substr | mysql | 2194.535 | 45.89× | validated |
| text_substr | mongo | 6899.528 | 144.28× | validated |
| text_substr | pandas | 1361.491 | 28.47× | validated |
| text_substr | lin | 47.821 | 1.00× | validated |
| text_substr | sqlite | 719.632 | 15.05× | validated |
| materialize | duckdb | 3425.887 | 3.35× | validated |
| materialize | postgres | 4015.649 | 3.93× | validated |
| materialize | mysql | 24296.213 | 23.77× | validated |
| materialize | mongo | 11283.712 | 11.04× | validated |
| materialize | pandas | 5276.844 | 5.16× | validated |
| materialize | lin | 1022.334 | 1.00× | validated |
| materialize | sqlite | 5096.053 | 4.98× | validated |
| join_inner | duckdb | 7793.116 | 2.14× | validated |
| join_inner | postgres | 10346.595 | 2.84× | validated |
| join_inner | mysql | 55523.967 | 15.22× | validated |
| join_inner | mongo | 385859.678 | 105.80× | validated |
| join_inner | pandas | 11623.461 | 3.19× | validated |
| join_inner | lin | 3647.128 | 1.00× | validated |
| join_inner | sqlite | 12100.719 | 3.32× | validated |
| join_filter | duckdb | 4433.582 | 2.45× | validated |
| join_filter | postgres | 5765.851 | 3.19× | validated |
| join_filter | mysql | 28684.393 | 15.85× | validated |
| join_filter | mongo | 193374.514 | 106.84× | validated |
| join_filter | pandas | 6936.756 | 3.83× | validated |
| join_filter | lin | 1810.014 | 1.00× | validated |
| join_filter | sqlite | 6372.346 | 3.52× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
