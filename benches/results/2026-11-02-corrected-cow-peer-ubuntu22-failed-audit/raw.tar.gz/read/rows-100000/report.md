# Validated read API benchmark

Rows: 100000; process repetitions: 3; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.215 | 1.00× | validated |
| point_get | sqlite | 3.649 | 17.00× | validated |
| point_get | duckdb | 242.181 | 1128.49× | validated |
| point_get | postgres | 204.505 | 952.93× | validated |
| point_get | mysql | 262.255 | 1222.03× | validated |
| point_get | mongo | 463.199 | 2158.36× | validated |
| point_get | pandas | 16.878 | 78.65× | validated |
| filter_eq | lin | 2.080 | 1.00× | validated |
| filter_eq | sqlite | 2040.838 | 981.31× | validated |
| filter_eq | duckdb | 1742.514 | 837.86× | validated |
| filter_eq | postgres | 4389.592 | 2110.68× | validated |
| filter_eq | mysql | 7716.894 | 3710.56× | validated |
| filter_eq | mongo | 8821.184 | 4241.55× | validated |
| filter_eq | pandas | 5075.172 | 2440.33× | validated |
| text_substr | lin | 554.364 | 1.00× | validated |
| text_substr | sqlite | 7278.694 | 13.13× | validated |
| text_substr | duckdb | 1333.503 | 2.41× | validated |
| text_substr | postgres | 9087.861 | 16.39× | validated |
| text_substr | mysql | 19554.346 | 35.27× | validated |
| text_substr | mongo | 66970.175 | 120.81× | validated |
| text_substr | pandas | 11357.826 | 20.49× | validated |
| materialize | lin | 21153.645 | 1.00× | validated |
| materialize | sqlite | 56205.055 | 2.66× | validated |
| materialize | duckdb | 33364.990 | 1.58× | validated |
| materialize | postgres | 41063.666 | 1.94× | validated |
| materialize | mysql | 230254.601 | 10.88× | validated |
| materialize | mongo | 107971.523 | 5.10× | validated |
| materialize | pandas | 46376.490 | 2.19× | validated |
| join_inner | lin | 51526.071 | 1.00× | validated |
| join_inner | sqlite | 144643.439 | 2.81× | validated |
| join_inner | duckdb | 92094.728 | 1.79× | validated |
| join_inner | postgres | 120886.482 | 2.35× | validated |
| join_inner | mysql | 494089.274 | 9.59× | validated |
| join_inner | mongo | 3945287.223 | 76.57× | validated |
| join_inner | pandas | 108506.904 | 2.11× | validated |
| join_filter | lin | 25003.053 | 1.00× | validated |
| join_filter | sqlite | 69030.834 | 2.76× | validated |
| join_filter | duckdb | 41935.401 | 1.68× | validated |
| join_filter | postgres | 60863.096 | 2.43× | validated |
| join_filter | mysql | 265726.741 | 10.63× | validated |
| join_filter | mongo | 1979494.445 | 79.17× | validated |
| join_filter | pandas | 53328.989 | 2.13× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
