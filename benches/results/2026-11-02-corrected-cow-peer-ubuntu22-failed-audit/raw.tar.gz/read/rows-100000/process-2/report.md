# Validated read API benchmark

Rows: 100000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | sqlite | 3.574 | 16.66× | validated |
| point_get | duckdb | 238.597 | 1111.79× | validated |
| point_get | postgres | 203.232 | 947.00× | validated |
| point_get | mysql | 262.255 | 1222.03× | validated |
| point_get | mongo | 463.199 | 2158.36× | validated |
| point_get | pandas | 16.855 | 78.54× | validated |
| point_get | lin | 0.215 | 1.00× | validated |
| filter_eq | sqlite | 2021.998 | 969.56× | validated |
| filter_eq | duckdb | 1741.817 | 835.21× | validated |
| filter_eq | postgres | 4389.592 | 2104.83× | validated |
| filter_eq | mysql | 7716.894 | 3700.29× | validated |
| filter_eq | mongo | 8821.184 | 4229.80× | validated |
| filter_eq | pandas | 5050.588 | 2421.78× | validated |
| filter_eq | lin | 2.085 | 1.00× | validated |
| text_substr | sqlite | 7336.810 | 13.18× | validated |
| text_substr | duckdb | 1630.996 | 2.93× | validated |
| text_substr | postgres | 9087.861 | 16.32× | validated |
| text_substr | mysql | 19554.346 | 35.12× | validated |
| text_substr | mongo | 66970.175 | 120.28× | validated |
| text_substr | pandas | 11357.826 | 20.40× | validated |
| text_substr | lin | 556.793 | 1.00× | validated |
| materialize | sqlite | 59426.003 | 2.81× | validated |
| materialize | duckdb | 33364.990 | 1.58× | validated |
| materialize | postgres | 40159.055 | 1.90× | validated |
| materialize | mysql | 230254.601 | 10.88× | validated |
| materialize | mongo | 107971.523 | 5.10× | validated |
| materialize | pandas | 45158.517 | 2.13× | validated |
| materialize | lin | 21153.645 | 1.00× | validated |
| join_inner | sqlite | 145468.339 | 2.82× | validated |
| join_inner | duckdb | 94311.150 | 1.83× | validated |
| join_inner | postgres | 120886.482 | 2.35× | validated |
| join_inner | mysql | 494089.274 | 9.59× | validated |
| join_inner | mongo | 3945287.223 | 76.57× | validated |
| join_inner | pandas | 108506.904 | 2.11× | validated |
| join_inner | lin | 51526.071 | 1.00× | validated |
| join_filter | sqlite | 69030.834 | 2.76× | validated |
| join_filter | duckdb | 41935.401 | 1.68× | validated |
| join_filter | postgres | 61027.995 | 2.44× | validated |
| join_filter | mysql | 267954.988 | 10.72× | validated |
| join_filter | mongo | 1979494.445 | 79.17× | validated |
| join_filter | pandas | 52720.231 | 2.11× | validated |
| join_filter | lin | 25003.053 | 1.00× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
