# Validated read API benchmark

Rows: 100000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | duckdb | 242.181 | 1123.63× | validated |
| point_get | postgres | 208.401 | 966.90× | validated |
| point_get | mysql | 261.767 | 1214.50× | validated |
| point_get | mongo | 488.017 | 2264.21× | validated |
| point_get | pandas | 16.941 | 78.60× | validated |
| point_get | lin | 0.216 | 1.00× | validated |
| point_get | sqlite | 3.649 | 16.93× | validated |
| filter_eq | duckdb | 1773.792 | 855.57× | validated |
| filter_eq | postgres | 4351.985 | 2099.14× | validated |
| filter_eq | mysql | 7698.628 | 3713.36× | validated |
| filter_eq | mongo | 8800.471 | 4244.83× | validated |
| filter_eq | pandas | 5128.151 | 2473.52× | validated |
| filter_eq | lin | 2.073 | 1.00× | validated |
| filter_eq | sqlite | 2109.180 | 1017.34× | validated |
| text_substr | duckdb | 1333.503 | 2.41× | validated |
| text_substr | postgres | 9006.838 | 16.25× | validated |
| text_substr | mysql | 19498.305 | 35.17× | validated |
| text_substr | mongo | 67453.823 | 121.68× | validated |
| text_substr | pandas | 11328.685 | 20.44× | validated |
| text_substr | lin | 554.364 | 1.00× | validated |
| text_substr | sqlite | 7278.694 | 13.13× | validated |
| materialize | duckdb | 37137.902 | 1.47× | validated |
| materialize | postgres | 41483.704 | 1.64× | validated |
| materialize | mysql | 229744.006 | 9.07× | validated |
| materialize | mongo | 107739.023 | 4.25× | validated |
| materialize | pandas | 46376.490 | 1.83× | validated |
| materialize | lin | 25324.351 | 1.00× | validated |
| materialize | sqlite | 56046.861 | 2.21× | validated |
| join_inner | duckdb | 92094.728 | 1.58× | validated |
| join_inner | postgres | 119886.289 | 2.06× | validated |
| join_inner | mysql | 485665.046 | 8.33× | validated |
| join_inner | mongo | 3916945.922 | 67.18× | validated |
| join_inner | pandas | 106613.442 | 1.83× | validated |
| join_inner | lin | 58303.736 | 1.00× | validated |
| join_inner | sqlite | 139551.108 | 2.39× | validated |
| join_filter | duckdb | 41270.713 | 1.51× | validated |
| join_filter | postgres | 58612.122 | 2.15× | validated |
| join_filter | mysql | 262763.970 | 9.64× | validated |
| join_filter | mongo | 1979335.580 | 72.62× | validated |
| join_filter | pandas | 55670.967 | 2.04× | validated |
| join_filter | lin | 27254.393 | 1.00× | validated |
| join_filter | sqlite | 72012.367 | 2.64× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
