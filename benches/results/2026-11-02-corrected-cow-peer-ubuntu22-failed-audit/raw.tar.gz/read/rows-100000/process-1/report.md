# Validated read API benchmark

Rows: 100000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.214 | 1.00× | validated |
| point_get | sqlite | 3.670 | 17.17× | validated |
| point_get | duckdb | 258.712 | 1210.66× | validated |
| point_get | postgres | 204.505 | 956.99× | validated |
| point_get | mysql | 280.750 | 1313.79× | validated |
| point_get | mongo | 462.464 | 2164.13× | validated |
| point_get | pandas | 16.878 | 78.98× | validated |
| filter_eq | lin | 2.080 | 1.00× | validated |
| filter_eq | sqlite | 2040.838 | 981.31× | validated |
| filter_eq | duckdb | 1742.514 | 837.86× | validated |
| filter_eq | postgres | 4399.233 | 2115.31× | validated |
| filter_eq | mysql | 7734.097 | 3718.84× | validated |
| filter_eq | mongo | 9164.038 | 4406.40× | validated |
| filter_eq | pandas | 5075.172 | 2440.33× | validated |
| text_substr | lin | 554.139 | 1.00× | validated |
| text_substr | sqlite | 7173.011 | 12.94× | validated |
| text_substr | duckdb | 1316.188 | 2.38× | validated |
| text_substr | postgres | 9155.423 | 16.52× | validated |
| text_substr | mysql | 20191.915 | 36.44× | validated |
| text_substr | mongo | 66581.629 | 120.15× | validated |
| text_substr | pandas | 11542.227 | 20.83× | validated |
| materialize | lin | 20709.033 | 1.00× | validated |
| materialize | sqlite | 56205.055 | 2.71× | validated |
| materialize | duckdb | 32874.310 | 1.59× | validated |
| materialize | postgres | 41063.666 | 1.98× | validated |
| materialize | mysql | 231627.378 | 11.18× | validated |
| materialize | mongo | 108428.606 | 5.24× | validated |
| materialize | pandas | 46570.764 | 2.25× | validated |
| join_inner | lin | 50902.797 | 1.00× | validated |
| join_inner | sqlite | 144643.439 | 2.84× | validated |
| join_inner | duckdb | 91400.701 | 1.80× | validated |
| join_inner | postgres | 122536.015 | 2.41× | validated |
| join_inner | mysql | 496016.611 | 9.74× | validated |
| join_inner | mongo | 3957043.258 | 77.74× | validated |
| join_inner | pandas | 108867.709 | 2.14× | validated |
| join_filter | lin | 24384.468 | 1.00× | validated |
| join_filter | sqlite | 67565.629 | 2.77× | validated |
| join_filter | duckdb | 42162.426 | 1.73× | validated |
| join_filter | postgres | 60863.096 | 2.50× | validated |
| join_filter | mysql | 265726.741 | 10.90× | validated |
| join_filter | mongo | 1994856.980 | 81.81× | validated |
| join_filter | pandas | 53328.989 | 2.19× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
