# Validated read API benchmark

Rows: 1000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | duckdb | 236.157 | 1088.43× | validated |
| point_get | postgres | 197.297 | 909.33× | validated |
| point_get | mysql | 253.869 | 1170.06× | validated |
| point_get | mongo | 466.810 | 2151.50× | validated |
| point_get | pandas | 17.387 | 80.13× | validated |
| point_get | lin | 0.217 | 1.00× | validated |
| point_get | sqlite | 3.520 | 16.22× | validated |
| filter_eq | duckdb | 500.237 | 540.62× | validated |
| filter_eq | postgres | 273.233 | 295.29× | validated |
| filter_eq | mysql | 328.679 | 355.21× | validated |
| filter_eq | mongo | 708.969 | 766.20× | validated |
| filter_eq | pandas | 202.420 | 218.76× | validated |
| filter_eq | lin | 0.925 | 1.00× | validated |
| filter_eq | sqlite | 23.681 | 25.59× | validated |
| text_substr | duckdb | 330.886 | 84.56× | validated |
| text_substr | postgres | 263.625 | 67.37× | validated |
| text_substr | mysql | 437.903 | 111.90× | validated |
| text_substr | mongo | 1268.532 | 324.16× | validated |
| text_substr | pandas | 266.855 | 68.19× | validated |
| text_substr | lin | 3.913 | 1.00× | validated |
| text_substr | sqlite | 73.710 | 18.84× | validated |
| materialize | duckdb | 815.963 | 8.45× | validated |
| materialize | postgres | 559.773 | 5.80× | validated |
| materialize | mysql | 2584.338 | 26.77× | validated |
| materialize | mongo | 1931.321 | 20.00× | validated |
| materialize | pandas | 1259.062 | 13.04× | validated |
| materialize | lin | 96.556 | 1.00× | validated |
| materialize | sqlite | 441.139 | 4.57× | validated |
| join_inner | duckdb | 1347.428 | 3.81× | validated |
| join_inner | postgres | 1128.857 | 3.19× | validated |
| join_inner | mysql | 5387.429 | 15.22× | validated |
| join_inner | mongo | 39281.651 | 110.97× | validated |
| join_inner | pandas | 2473.031 | 6.99× | validated |
| join_inner | lin | 353.981 | 1.00× | validated |
| join_inner | sqlite | 1046.036 | 2.96× | validated |
| join_filter | duckdb | 1024.491 | 5.81× | validated |
| join_filter | postgres | 732.524 | 4.16× | validated |
| join_filter | mysql | 2959.186 | 16.79× | validated |
| join_filter | mongo | 20299.082 | 115.20× | validated |
| join_filter | pandas | 2370.655 | 13.45× | validated |
| join_filter | lin | 176.214 | 1.00× | validated |
| join_filter | sqlite | 540.879 | 3.07× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
