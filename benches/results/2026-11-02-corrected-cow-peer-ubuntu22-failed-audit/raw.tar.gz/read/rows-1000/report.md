# Validated read API benchmark

Rows: 1000; process repetitions: 3; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.217 | 1.00× | validated |
| point_get | sqlite | 3.520 | 16.22× | validated |
| point_get | duckdb | 241.007 | 1110.79× | validated |
| point_get | postgres | 199.298 | 918.55× | validated |
| point_get | mysql | 249.172 | 1148.42× | validated |
| point_get | mongo | 467.154 | 2153.09× | validated |
| point_get | pandas | 17.288 | 79.68× | validated |
| filter_eq | lin | 0.908 | 1.00× | validated |
| filter_eq | sqlite | 23.681 | 26.09× | validated |
| filter_eq | duckdb | 500.771 | 551.66× | validated |
| filter_eq | postgres | 273.942 | 301.78× | validated |
| filter_eq | mysql | 332.322 | 366.09× | validated |
| filter_eq | mongo | 683.624 | 753.09× | validated |
| filter_eq | pandas | 202.420 | 222.99× | validated |
| text_substr | lin | 3.905 | 1.00× | validated |
| text_substr | sqlite | 74.855 | 19.17× | validated |
| text_substr | duckdb | 330.886 | 84.73× | validated |
| text_substr | postgres | 273.175 | 69.95× | validated |
| text_substr | mysql | 443.332 | 113.52× | validated |
| text_substr | mongo | 1268.532 | 324.83× | validated |
| text_substr | pandas | 266.855 | 68.33× | validated |
| materialize | lin | 96.556 | 1.00× | validated |
| materialize | sqlite | 441.139 | 4.57× | validated |
| materialize | duckdb | 834.143 | 8.64× | validated |
| materialize | postgres | 559.773 | 5.80× | validated |
| materialize | mysql | 2584.338 | 26.77× | validated |
| materialize | mongo | 1909.130 | 19.77× | validated |
| materialize | pandas | 1242.914 | 12.87× | validated |
| join_inner | lin | 353.981 | 1.00× | validated |
| join_inner | sqlite | 1046.036 | 2.96× | validated |
| join_inner | duckdb | 1347.428 | 3.81× | validated |
| join_inner | postgres | 1123.131 | 3.17× | validated |
| join_inner | mysql | 5387.429 | 15.22× | validated |
| join_inner | mongo | 38764.700 | 109.51× | validated |
| join_inner | pandas | 2425.896 | 6.85× | validated |
| join_filter | lin | 173.889 | 1.00× | validated |
| join_filter | sqlite | 540.879 | 3.11× | validated |
| join_filter | duckdb | 1024.619 | 5.89× | validated |
| join_filter | postgres | 721.286 | 4.15× | validated |
| join_filter | mysql | 2959.186 | 17.02× | validated |
| join_filter | mongo | 20200.816 | 116.17× | validated |
| join_filter | pandas | 2308.207 | 13.27× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
