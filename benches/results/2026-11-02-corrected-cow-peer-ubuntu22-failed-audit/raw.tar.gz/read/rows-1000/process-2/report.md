# Validated read API benchmark

Rows: 1000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | sqlite | 3.515 | 16.16× | validated |
| point_get | duckdb | 241.007 | 1107.97× | validated |
| point_get | postgres | 199.298 | 916.22× | validated |
| point_get | mysql | 246.826 | 1134.72× | validated |
| point_get | mongo | 496.001 | 2280.24× | validated |
| point_get | pandas | 17.199 | 79.07× | validated |
| point_get | lin | 0.218 | 1.00× | validated |
| filter_eq | sqlite | 24.936 | 27.47× | validated |
| filter_eq | duckdb | 511.999 | 564.03× | validated |
| filter_eq | postgres | 276.916 | 305.06× | validated |
| filter_eq | mysql | 355.404 | 391.52× | validated |
| filter_eq | mongo | 683.624 | 753.09× | validated |
| filter_eq | pandas | 199.169 | 219.41× | validated |
| filter_eq | lin | 0.908 | 1.00× | validated |
| text_substr | sqlite | 74.855 | 19.28× | validated |
| text_substr | duckdb | 329.823 | 84.93× | validated |
| text_substr | postgres | 276.728 | 71.26× | validated |
| text_substr | mysql | 443.332 | 114.16× | validated |
| text_substr | mongo | 1281.489 | 330.00× | validated |
| text_substr | pandas | 267.400 | 68.86× | validated |
| text_substr | lin | 3.883 | 1.00× | validated |
| materialize | sqlite | 440.596 | 4.52× | validated |
| materialize | duckdb | 835.369 | 8.58× | validated |
| materialize | postgres | 569.822 | 5.85× | validated |
| materialize | mysql | 2583.311 | 26.53× | validated |
| materialize | mongo | 1909.130 | 19.61× | validated |
| materialize | pandas | 1242.914 | 12.76× | validated |
| materialize | lin | 97.376 | 1.00× | validated |
| join_inner | sqlite | 1035.481 | 2.94× | validated |
| join_inner | duckdb | 1353.028 | 3.84× | validated |
| join_inner | postgres | 1123.131 | 3.19× | validated |
| join_inner | mysql | 5356.058 | 15.20× | validated |
| join_inner | mongo | 38764.700 | 110.03× | validated |
| join_inner | pandas | 2425.896 | 6.89× | validated |
| join_inner | lin | 352.300 | 1.00× | validated |
| join_filter | sqlite | 539.670 | 3.17× | validated |
| join_filter | duckdb | 1040.637 | 6.11× | validated |
| join_filter | postgres | 706.198 | 4.15× | validated |
| join_filter | mysql | 2931.083 | 17.21× | validated |
| join_filter | mongo | 20200.816 | 118.63× | validated |
| join_filter | pandas | 2293.066 | 13.47× | validated |
| join_filter | lin | 170.290 | 1.00× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
