# Validated read API benchmark

Rows: 1000; process repetitions: 1; host: Linux-6.8.0-1070-azure-x86_64-with-glibc2.35

Setup, validation and Lin JSON IPC excluded. Queries return the same materialized columns/values.
Lin: Rust prepared API; Python peers: DBAPI/DataFrame/driver API. Server timings include round-trip and transfer.
Medians are batch averages, not individual latency percentiles. Each process is aggregated first.

| Case | Engine | Median µs/op | Peer / Lin | Status |
|---|---|---:|---:|---|
| point_get | lin | 0.212 | 1.00× | validated |
| point_get | sqlite | 3.562 | 16.83× | validated |
| point_get | duckdb | 242.519 | 1146.04× | validated |
| point_get | postgres | 202.155 | 955.30× | validated |
| point_get | mysql | 249.172 | 1177.49× | validated |
| point_get | mongo | 467.154 | 2207.58× | validated |
| point_get | pandas | 17.288 | 81.70× | validated |
| filter_eq | lin | 0.892 | 1.00× | validated |
| filter_eq | sqlite | 23.188 | 25.98× | validated |
| filter_eq | duckdb | 500.771 | 561.11× | validated |
| filter_eq | postgres | 273.942 | 306.95× | validated |
| filter_eq | mysql | 332.322 | 372.36× | validated |
| filter_eq | mongo | 648.110 | 726.20× | validated |
| filter_eq | pandas | 203.124 | 227.60× | validated |
| text_substr | lin | 3.905 | 1.00× | validated |
| text_substr | sqlite | 75.387 | 19.30× | validated |
| text_substr | duckdb | 331.008 | 84.76× | validated |
| text_substr | postgres | 273.175 | 69.95× | validated |
| text_substr | mysql | 444.987 | 113.95× | validated |
| text_substr | mongo | 1234.545 | 316.12× | validated |
| text_substr | pandas | 266.656 | 68.28× | validated |
| materialize | lin | 95.439 | 1.00× | validated |
| materialize | sqlite | 461.550 | 4.84× | validated |
| materialize | duckdb | 834.143 | 8.74× | validated |
| materialize | postgres | 559.226 | 5.86× | validated |
| materialize | mysql | 2587.805 | 27.11× | validated |
| materialize | mongo | 1893.112 | 19.84× | validated |
| materialize | pandas | 1229.972 | 12.89× | validated |
| join_inner | lin | 354.955 | 1.00× | validated |
| join_inner | sqlite | 1085.028 | 3.06× | validated |
| join_inner | duckdb | 1315.014 | 3.70× | validated |
| join_inner | postgres | 1119.191 | 3.15× | validated |
| join_inner | mysql | 5518.919 | 15.55× | validated |
| join_inner | mongo | 38717.698 | 109.08× | validated |
| join_inner | pandas | 2396.119 | 6.75× | validated |
| join_filter | lin | 173.889 | 1.00× | validated |
| join_filter | sqlite | 559.947 | 3.22× | validated |
| join_filter | duckdb | 1024.619 | 5.89× | validated |
| join_filter | postgres | 721.286 | 4.15× | validated |
| join_filter | mysql | 3002.517 | 17.27× | validated |
| join_filter | mongo | 19969.232 | 114.84× | validated |
| join_filter | pandas | 2308.207 | 13.27× | validated |

Versions: {"duckdb": "1.5.6", "lin": "0.4.0", "mongo": "8.0.34", "mysql": "8.4.13", "pandas": "3.0.6", "postgres": "160015", "sqlite": "3.37.2"}

Missing/failed peers are never counted as wins.
