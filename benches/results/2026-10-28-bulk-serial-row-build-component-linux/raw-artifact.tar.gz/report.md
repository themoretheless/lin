# Large builtin hashing batch parallelism component comparison

Linux x86_64, same frozen compare harness; previous COW+CAS baseline versus builtin hashing batch parallel candidate. No RSS claim. Full engine and eight-peer goal remain unqualified.

|Case|Series|Gain %|Absolute A/A %|Positive|Pass|
|---|---|---:|---:|---:|---|
|compare/insert_bulk_10k/lin|series1|-0.281|1.510|3/6|False|
|compare/insert_bulk_10k/lin|series2|-5.336|2.635|0/6|False|
|compare/insert_bulk_1k/lin|series1|-2.525|1.056|1/6|False|
|compare/insert_bulk_1k/lin|series2|-2.382|4.258|2/6|True|
|compare/point_get/lin|series1|1.022|6.172|4/6|True|
|compare/point_get/lin|series2|-0.711|2.214|3/6|True|
|compare/filter_eq/lin|series1|0.713|1.165|3/6|True|
|compare/filter_eq/lin|series2|-3.895|1.867|1/6|False|
|compare/update_1row_1k/lin|series1|0.865|3.411|3/6|True|
|compare/update_1row_1k/lin|series2|-0.396|1.732|3/6|True|
|compare/wal_scalar_full_update/lin|series1|-1.082|6.605|3/6|True|
|compare/wal_scalar_full_update/lin|series2|4.969|10.917|4/6|True|
|compare/wal_scalar_normal_update/lin|series1|-2.150|5.836|3/6|True|
|compare/wal_scalar_normal_update/lin|series2|1.077|1.298|4/6|True|
|compare/insert_bulk_10k/sqlite|series1|-0.258|1.373|2/6|True|
|compare/insert_bulk_10k/sqlite|series2|-0.029|1.154|3/6|True|
|compare/filter_eq/duckdb|series1|-5.045|9.051|1/6|True|
|compare/filter_eq/duckdb|series2|-4.734|4.739|1/6|True|

Component gate: False. All 324 processes / 2592 wall observations retained.
